# Gizemli404 — KIRILMA otomatik yayın paketi

Bu paket, GitHub Actions üzerinde mevcut YouTube otomasyonunu koruyarak **Gizemli404** kanalının 10 bölümlük, devamlı hikâye anlatan **KIRILMA** animasyon serisini üretir ve yayınlar.

## GitHub deposuna yüklenecekler

1. `.github/workflows/video.yml` dosyasını depodaki eski workflow dosyasıyla değiştirin.
2. `gizemli404-source.zip` dosyasını depo köküne yükleyin. Eski `tuhaf-kasaba-source.zip` dosyasını kaldırın veya yenisiyle değiştirin.
3. GitHub Secrets adlarını değiştirmeyin:
   - `YOUTUBE_CLIENT_ID`
   - `YOUTUBE_CLIENT_SECRET`
   - `YOUTUBE_REFRESH_TOKEN`
4. Actions sekmesinden ilk çalıştırmayı elle başlatabilirsiniz. Sonrasında her gün Türkiye saati **09.00**'da otomatik çalışır.

## Seri

- Kanal: **Gizemli404**
- Dizi: **KIRILMA**
- Tür: gizem, bilim kurgu, macera ve karakter dramı
- Sezon 1: 10 birbirine bağlı bölüm
- Ana karakterler: Batu, Nur, Alperen, Kubilay ve Merco
- Her bölüm önceki olayların devamıdır; bölüm sonları sonraki bölüme merak bırakır.

## Görsel / animasyon düzeni

- Referans kitin doodle / çöp-adam karakter estetiği korunur; karakter renkleri, kıyafetleri ve ayırt edici özellikleri Gizemli404'e özeldir.
- Karakterler sahne boyunca yan yana sabit durmaz. Replik başına belirlenen hareket, görünür karakter listesi, kamera planı ve aksiyon kullanılır.
- Yaklaşık üçte birlik POV planları; takip, yakın plan, geniş plan, karşı açı ve nesne detay çekimleriyle karıştırılır.
- Yürüme, koşma, arama, kapı açma, dinleme, tırmanma, çekme, saklanma ve olay tepkileri animasyon durumlarına bağlanır.
- Her bölüm için ayrı, konuya özel çevre tasarımı bulunur; aynı mekân türü tekrar etse bile bölümün olayına göre arka plan katmanları ve atmosfer değişir.
- İstasyon, kayıp ev, ses arşivi, servis tüneli, sıfırıncı kat, deney kontrol odası, zaman döngüsündeki kasaba, kayıt odası, su kulesi ve finalde parçalanan kasaba birbirinden farklı çevre ayrıntılarıyla kurulur.
- Arka planlar derinlik katmanları, mimari ayrıntılar, uygun ışık ve atmosferle zenginleştirilir; dekor olsun diye rastgele nesne eklenmez.
- Karakterlerin elinde yalnızca bölüm senaryosunda açıkça tanımlanmış ve olayla ilgili nesneler görünür.
- 12 karelik önizleme sayfası render öncesinde oluşturulur ve GitHub artifact'inde saklanır.

## Ses

- Ücretsiz Edge Neural Türkçe sesleri kullanılır. Rol ayrımı hız, perde ve hafif filtrelerle yapılır; bunlar farklı gerçek ses oyuncuları değildir.
- Konuşma klipleri arası duraklamalar, yumuşak giriş/çıkışlar ve kelime zamanlaması korunur.
- Müzik türü bölüm bazında değişir (mystery, tense, epic). Müzik konuşmanın altında tutulur; bölümün aksiyonlarına göre olay sesleri eklenir. Sabit boing/pop ağırlıklı efekt düzeni kaldırılmıştır.

## Video ve süre güvenlikleri

- Dikey çıktı: **1080×1920, 30 FPS, H.264 video / AAC ses**.
- Ses/video süresi: **80–180 saniye**. Bu sınırın dışındaki video yüklenmez.
- Kareler 540×960 çalışma boyutunda render edilir, son MP4 1080×1920'ye yükseltilir.
- Tam render için 190 dakika subprocess sınırı, workflow için 330 dakika job sınırı vardır.
- Yarım kalan render kareleri kaynak sürümü ve bölüm kimliğiyle eşleşen GitHub cache üzerinden devam ettirilebilir. Kaynak veya senaryo değişirse eski kareler kullanılmaz.
- YouTube yüklemesi teknik kontroller başarılı olduktan sonra yapılır.

## YouTube başlık ve açıklamaları

Başlıklar kanal ve dizi adını, bölüm numarasını ve bölüm adını içerir. Açıklamalar olayın merak uyandıran kısa özetini, bir sonraki bölüme teşvik ve hashtag'leri içerir. Açıklamalarda kod, otomatik üretim veya üretim araçlarıyla ilgili ifadeler kullanılmaz. YouTube API metadata'sında sentetik içerik beyanı (`containsSyntheticMedia`) açık tutulur.

## Yayın geçmişi

Yeni geçmiş `data/gizemli404_history.json` içinde tutulur. Eski `data/tuhaf_kasaba_history.json` dosyası varsa okunur; böylece eski yayın kayıtları ve zaman-slot tekrar kontrolü kaybolmaz. Yeni bölümler GitHub `main` dalına yayın geçmişi commit'i olarak gönderilir.

## Kaynak / lisans

`cizgi-short` kiti ve üçüncü taraf dosyaları kaynak ZIP'te olduğu gibi korunur. `cizgi-short/LICENSE.txt` ve `cizgi-short/kit/vendor/THREE-LICENSE.txt` dosyalarını silmeyin. Kaynak kitin kredi bilgileri proje dosyalarında kalır; video açıklamalarına teknik üretim kredisi eklenmez.

> Bu ortamda Edge TTS ve YouTube'a gerçek render/yükleme testi yapılamadı. Kod, JSON, JavaScript, workflow ve paket yapısı statik olarak kontrol edilecek; ilk gerçek GitHub Actions çalışması dış servisleri doğrular.


## KIRILMA görsel/senaryo revizyonu
- Ev ve arşiv iç mekânlarında masa/sandalye ana oyunculuk koridorunun dışına alındı.
- POV kamera konuşmacı/eylem hattını takip edecek şekilde ayarlandı.
- Karakter rotaları ev ve arşivde mobilya çakışmalarından kaçınan yan koridorlara taşındı.
- 1–10. bölüm diyalogları daha doğal, karşılıklı ve sahne içinde oynanabilir film anlatımına göre yenilendi; ana gizem ve sezon sürekliliği korundu.
