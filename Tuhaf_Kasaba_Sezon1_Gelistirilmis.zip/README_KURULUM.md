# Tuhaf Kasaba — GitHub Actions kurulum paketi

Bu paket, mevcut `masal-video` deposundaki `video.yml` otomasyon düzenini Tuhaf Kasaba'ya uyarlar.

## GitHub'a eklenecek iki dosya

1. Bu paketteki `.github/workflows/video.yml` dosyasını depodaki aynı konumda bulunan eski `video.yml` ile değiştirin.
2. `tuhaf-kasaba-source.zip` dosyasını deponun kök dizinine yükleyin.

GitHub Actions çalışırken bu ZIP'i açar. ZIP'in içinde:
- `cizgi-short/kit/` — gönderdiğiniz çizgi-short animasyon motoru ve araçları
- `tuhaf-kasaba/run_episode.py` — ses, render, kalite kontrol ve YouTube yükleme otomasyonu
- `tuhaf-kasaba/story.js` — Poyraz, Ece, Piko ve Profesör Fikri animasyon sahnesi
- `tuhaf-kasaba/episodes/episode_01.json` ... `episode_10.json` — 10 bölümün diyalogları

## Gerekli GitHub Secrets

Mevcut YouTube OAuth anahtarlarını aynı isimlerle koruyun:
- `YOUTUBE_CLIENT_ID`
- `YOUTUBE_CLIENT_SECRET`
- `YOUTUBE_REFRESH_TOKEN`

Cloudflare anahtarları bu yeni çizgi film sisteminde kullanılmaz.

## Çalışma düzeni

- `workflow_dispatch`: GitHub Actions ekranından elle çalıştırma
- `0 6 * * *`: her gün Türkiye saati 09:00 (UTC 06:00). Türkiye yıl boyunca UTC+3 kullanır.
- 1. sezon 'Kayıp Zamanın Şehri' tek ana hikâyeden oluşan 10 devam bölümüdür; bölümler sırayla seçilir ve daha önce yüklenen bölüm tekrar seçilmez.
- Sezon tamamlandığında sistem yeni sezon dosyaları eklenene kadar durur; aynı karakterler yeni sezonlarda devam eder.
- Bölüm ses hedefi 80–165 saniye aralığında tutulur (Shorts için 3 dakikalık sınırın altında); dışına çıkarsa yayın öncesi durur. Video 1080×1920, 30 FPS H.264/AAC MP4 hazırlanır.
- Her karakterin repliği ayrı Edge TTS karakter sesiyle üretilir; sonra konuşma sırasıyla birleştirilir.
- Ağız hareketi, sesin kelime zamanlamasına göre animasyon motorunda çalışır.
- Video yüklemesi yalnızca render ve teknik kontroller başarılı olursa yapılır.
- Yükleme geçmişi `data/tuhaf_kasaba_history.json` dosyasına kaydedilir ve `main` dalına gönderilir.

## Karakter sesleri

- Poyraz: tr-TR-AhmetNeural, hafif yavaşlatılmış doğal ton
- Ece: tr-TR-EmelNeural, daha naif ve yumuşak tempo
- Piko: AhmetNeural, hafif hız/perde farkı ve çok hafif EQ
- Profesör Fikri / Aras: AhmetNeural, karaktere göre daha ağır tempo ve hafif ton ayrımı
- Mira: EmelNeural, sakin tempo
- Robot sesleri: Neural sesler ve çok hafif filtrelerle ayrıştırılır

Bunlar farklı ses karakterleri oluşturmak için kullanılan TTS ayarlarıdır; gerçek insan ses sanatçısı kaydı değildir.

## Önemli teknik not

Kaynak kitin dokümantasyonu kare başına render süresinin makineye göre değişebileceğini belirtiyor. GitHub runner üzerinde 60 saniyelik, 30 FPS animasyonun render işlemi uzun sürebilir. İş akışının zaman aşımı 300 dakikadır. Çalışma kareleri performans için 0.67 ölçeğinde üretilir ve son MP4 1080×1920'ye yükseltilir.

Bu dosyalar sözdizimi ve statik kontrollerden geçirilmiştir. Gerçek GitHub Actions çalıştırması, Edge TTS erişimi ve YouTube yüklemesi bu ortamda test edilmemiştir.

## Kaynak kredisi ve lisans

Animasyon kiti kaynak dosyalarıyla birlikte korunmuştur. Kaynak hazırlayıcı kredisi: **Burak Özer (@burakozerweb)**. `cizgi-short/LICENSE.txt` ve `cizgi-short/kit/vendor/THREE-LICENSE.txt` bildirimlerini silmeyin.


## Geliştirilmiş sürüm notları
- Bölüm senaryoları, çocuklara yönelik basit tekrarlar yerine gizem, karakter motivasyonu, duygusal kararlar ve sezon boyunca devam eden ana hikâye ile yeniden yazıldı.
- Karakter hareketleri konuşma satırındaki aksiyon sözcüklerine göre yürüme/koşma, sahne içi konum değişimi ve farklı kamera ölçekleriyle desteklenir. Bölümün merkez nesnesi de olay sırasında hareket eder.
- Seslerde ücretsiz Türkçe Edge Neural seçenekleri kullanılır. Ece için Emel Neural; erkek roller için Ahmet Neural; karakterler için farklı hız, ton ve hafif EQ ayarları uygulanır. Bu ücretsiz motorun Türkçe doğal ses seçeneği sınırlı olduğundan, ücretli gerçek oyuncu sesleriyle aynı çeşitlilik garanti edilemez.
- Diyalog araları karakter değişiminde uzatıldı; WAV kliplerinin başı/sonu kısa fade ile yumuşatılarak kesilme hissi azaltıldı.

## Sezon 1: Kayıp Zamanın Şehri

Bu sürüm, Ece, Poyraz, Piko ve Profesör Fikri'nin 10 bölümlük devam hikâyesini içerir. 1. sezon finalinde ana döngü kapanır; final mesajı yeni sezon/başka macera için açık kapı bırakır. Günlük 09:00 Türkiye saati yayınlanır.

## Otomasyon süre güvenlikleri

- Toplam GitHub Actions job timeout: 300 dakika.
- Tam render adımı için subprocess timeout: 120 dakika; render dosyaları `--resume` ile mevcut karelerden devam edebilir.
- Bölüm ses süresi 80–165 saniye dışında ise video yüklenmez.
- Bu sınırlar, runner hızına göre her bölümün kesin bitiş süresini garanti etmez; işin takılı kalmasını önlemek ve başarısız üretimde yayın yapmamak içindir.
