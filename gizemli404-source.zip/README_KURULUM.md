# Gizemli404 — KIRILMA: KAYIP ADA otomatik yayın paketi

Bu paket, mevcut Gizemli404 YouTube yayın otomasyonunu koruyarak yeni **KIRILMA – KAYIP ADA** serisinin hazır bölümlerini üretir. İlk hedef yalnızca 1. bölüm **Son Rota**'dır. Henüz yazılmamış bölümler otomatik olarak üretilmez veya yayınlanmaz.

## GitHub deposuna yerleştirme

1. `.github/workflows/video.yml` dosyasını depodaki mevcut workflow dosyasıyla değiştirin.
2. `gizemli404-source.zip` dosyasını depo köküne yükleyin.
3. Aşağıdaki GitHub Secrets adlarını aynen koruyun:
   - `YOUTUBE_CLIENT_ID`
   - `YOUTUBE_CLIENT_SECRET`
   - `YOUTUBE_REFRESH_TOKEN`
4. Actions sekmesinden `workflow_dispatch` ile elle çalıştırabilir veya günlük Türkiye saati 09.00 planını kullanabilirsiniz.

## Hikâye ve karakterler

- Kanal: **Gizemli404**
- Seri: **KIRILMA – KAYIP ADA**
- Slogan: **Bir ada. Beş arkadaş. Saklanan büyük bir sır.**
- 1. bölüm: **Son Rota**
- Batu, Nur, Alperen, Kubilay ve küçük köpekleri Merco; fırtınada tekneleri hasar görünce haritalarda bulunmayan bir adaya sürüklenir.
- Eski kasaba/istasyon KIRILMA senaryoları aktif bölüm seçicisinden çıkarıldı. Yayın seçicisi yalnızca `g404-kayip-ada-s01-` kimlikli yeni bölümleri kabul eder.

## Görsel ve animasyon

- Mevcut cizgi-short motoru ve karakter kimlikleri korunmuştur.
- 1. bölüm için ayrı ada kıyısı çevresi eklendi: kum, deniz, kıyı kayaları, tropik bitki örtüsü, hasarlı tekne, eski kamp alanı ve radyo.
- Merco için küçük köpek biçiminde ayrı 2D karakter çizimi eklendi.
- POV, geniş, takip, yakın plan ve nesne detay çekimleri mevcut kamera sisteminden yararlanır.
- Bu, mevcut motorun geliştirilmiş stilize 2D karakter + 3D çevre yaklaşımıdır; tam anlamıyla yeni bir fotogerçekçi 3D animasyon sistemi değildir.

## Ses ve bölüm süresi

- Ücretsiz Edge Neural Türkçe sesleri kullanılır; karakter rolleri mevcut ses/ton ayarlarıyla ayrılır.
- Merco köpek olduğu için konuşan karakter değildir.
- Diyaloglar tek konuşmacılıdır; müzik ve ses efektleri konuşmanın altında tutulur.
- İlk bölüm senaryosu 780–900 kelime kontrolünden geçer.
- Yükleme öncesi hedef süre **300–480 saniye (5–8 dakika)** olarak denetlenir. Süre sınırı tutmazsa video yüklenmez.

## Render güvenliği ve devam etme

- Çıktı: 1080×1920, 30 FPS, H.264 video / AAC ses.
- Render, 450 karelik parçalar halinde yürütülür. Her kare yazıldıktan sonra diskte kalır.
- GitHub Actions cache, bölüm kimliği ve kaynak dosyalarının hash'i ile eşleştirilir; sonraki çalıştırma tamamlanmış kareleri `--resume` ile atlar.
- Tek çalıştırmada toplam render bütçesi 190 dakika; tek parça subprocess sınırı 35 dakikadır. Bir parça zaman aşımına uğrarsa tamamlanan kareler korunur ve sonraki çalıştırmada devam eder.
- Workflow job sınırı 350 dakikadır. Cache anahtarı yeni run kimliğiyle oluşturulur, önceki aynı bölüm/kaynak önbelleği geri yüklenir.
- Önizleme sayfası, ses zamanlaması ve üretim dosyaları GitHub artifact'inde saklanır.

## Yayın güvenliği

- YouTube OAuth Secrets üretimden önce kontrol edilir.
- Yükleme yalnızca render, çözünürlük, FPS, codec ve ses/süre kontrolleri geçerse başlar.
- Bölüm kimliği ve zaman-slot yayın geçmişi tekrar yayınlamayı önler.
- Yayın geçmişi `data/gizemli404_history.json` içinde tutulur; eski geçmiş dosyası okunmaya devam eder.
- Sentetik içerik beyanı YouTube metadata'sında açık tutulur.

## Lisans ve sınırlar

`cizgi-short/LICENSE.txt` ve `cizgi-short/kit/vendor/THREE-LICENSE.txt` korunmuştur. Ücretsiz araçlar tercih edilir; YouTube gerçek yükleme ve Edge TTS üretimi GitHub Actions ortamında, gerekli Secrets ve ağ erişimiyle doğrulanmalıdır.

> Bu çalışma alanında gerçek Edge TTS, tam video renderı ve YouTube yüklemesi çalıştırılmadı. Bu nedenle bunlar başarılı olarak raporlanmayacaktır. Paket statik kod/veri kontrollerinden geçirilecektir.
