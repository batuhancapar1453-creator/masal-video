// Tuhaf Kasaba — hikâyeye bağlı, hareketli 3D sahne yönetimi
// Karakter tasarımları ve animasyon motoru API'si korunur.
const epResponse = await fetch(new URL("./episode.json", import.meta.url));
if (!epResponse.ok) throw new Error("episode.json yüklenemedi");
const EP = await epResponse.json();
export const meta = { fps: 30, tail: 0.55 };

let R = {};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const mix=(a,b,t)=>a+(b-a)*t;
const smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
const actorState=(E,f,seed,face="neutral",arms="hang",talk=0,extra={})=>({
  blink:E.blink(f,seed), ...E.idle(f,seed), face, arms, talk, ...extra
});

function makeEpisodeProp(E,S,T,center,variant=0) {
  const wood=E.mat("#8a5835",{map:T.wood("#8a5835")});
  const gold=E.mat("#e8b84f"), red=E.mat("#c94d4d"), blue=E.mat("#4d91c9");
  const g=E.group(null,[center,0,-2]);
  const box=(w,h,d,m,p,o={})=>E.box(w,h,d,m,p,{...o,parent:g});
  const sphere=(r,m,p,o={})=>E.sphere(r,m,p,{...o,parent:g});
  const label=(txt,w,h,p,bg="#f7e8c5",fg="#713a32")=>E.label(T.sign(txt,{bg,fg,size:100}),w,h,[center+p[0],p[1],p[2]]);
  switch(EP.kind){
    case "mailbox":
      box(1.5,1.8,1,red,[0,1,0]); box(1.7,.18,1.12,red,[0,1.95,0]);
      box(1.05,.14,.08,gold,[0,1.35,.57]); label("POSTA",.9,.28,[0,2.35,-.56]); break;
    case "shadows":
      for(let i=0;i<3;i++){sphere(.42,E.mat("#34324a"),[-1.1+i*1.1,1,0],{scale:[1,1.5,.3]});box(.16,.9,.12,E.mat("#34324a"),[-1.1+i*1.1,.35,0]);}
      break;
    case "vending":
      box(2.1,3.1,1,blue,[0,1.55,0]);box(1.45,1.05,.06,E.mat("#bfe9ed"),[0,1.8,.55]);
      for(let i=0;i<3;i++)sphere(.12,gold,[-.55+i*.55,.9,.58]);
      label("DİLEK",1,.3,[0,2.85,.56],"#f8d65c","#26364d");break;
    case "dinosaur":
      sphere(.85,E.mat("#65a95c"),[0,1,0],{scale:[1.2,.8,.8]});
      sphere(.48,E.mat("#75bd68"),[.72,1.7,0]);
      for(let i=0;i<3;i++)E.cone(.22,.42,E.mat("#e7c45e"),[-.2+i*.4,2.2,0],{parent:g});
      sphere(.08,E.mat("#fff"),[.9,1.8,.36]);sphere(.035,E.mat("#1d1622"),[.93,1.8,.43]);break;
    case "upside_house":
      box(2.8,2.2,2.3,E.mat("#e9c78c"),[0,1.1,0]);E.cone(2.2,1.4,red,[0,2.9,0],{parent:g});
      box(.55,1,.12,wood,[0,.5,1.18]);break;
    case "robots":
      for(let i=0;i<3;i++){box(.75,.85,.55,E.mat(["#63c8bd","#e4b85d","#8b83c7"][i]),[-1+i,.65,0]);
        sphere(.48,E.mat("#bfe9e4"),[-1+i,1.35,0]);sphere(.08,E.mat("#26364d"),[-1.15+i,1.4,.43]);sphere(.08,E.mat("#26364d"),[-.85+i,1.4,.43]);}
      break;
    case "tree_door":
      S.tree(center,-3,{type:"round",s:2.2});box(1,1.8,.16,wood,[0,1.1,-.1]);sphere(.09,gold,[.32,1.1,.02]);break;
    case "time":
    case "clocktower":
      E.cyl(1.15,1.15,.55,wood,[0,2.1,0],{parent:g,rot:[Math.PI/2,0,0]});
      E.cyl(.08,.08,.62,gold,[0,2.1,.34],{parent:g,rot:[Math.PI/2,0,0]});
      box(.12,.95,.12,gold,[0,2.55,.4]);box(.75,.12,.12,gold,[.35,2.1,.4]);break;
    case "sky_island":
      sphere(2.2,E.mat("#8b9c73"),[0,3.2,0],{scale:[1.5,.55,1]});
      box(1.2,1.1,1.2,E.mat("#e9c78c"),[0,4.05,0]);E.cone(1,1.1,red,[0,5.1,0],{parent:g});
      sphere(.45,E.mat("#5d9c68"),[-1.2,4.1,0]);break;
    default:
      E.cyl(1.4,1.8,5,wood,[0,2.5,0],{parent:g});E.cone(1.9,1.4,red,[0,5.7,0],{parent:g});
  }
  g.userData.kind=EP.kind; return g;
}

export function build(E) {
  const {S,T}=E;
  // Üç ayrı sahne bölgesi: meydan, bölümün özel mekânı ve final/keşif alanı.
  E.ground(T.grass("#8fbd70"),240,.22,[30,0,0]);
  S.hills({z:-90,col:"#86b96d",n:9});S.clouds({n:11,z:-75,y:25,spread:230});
  // 1) Kasaba meydanı
  S.street({x:0,len:46,width:13,z:-5});
  S.row(-20,20,-13,{seed:11});S.row(-20,20,13,{seed:29,rot:Math.PI});
  S.building(-16,-18,{w:8,d:8,floors:2,wall:"#f0c98b",roof:"#b85c48",cols:3});
  S.building(16,-18,{w:8,d:8,floors:2,wall:"#9fc7d9",roof:"#5d6f9a",cols:3});
  S.bench(-5,3,Math.PI/2);S.bench(5,3,-Math.PI/2);
  E.label(T.sign("TUHAF KASABA",{bg:"#2b314b",fg:"#fff3c4",border:"#e8b85a",size:150}),5.2,.8,[0,4.1,-9.2]);
  // 2) Bölüme göre değişen özel mekân
  const c1=32;
  if(["vending","robots","upside_house"].includes(EP.kind)){
    S.building(c1,-8,{w:16,d:12,floors:1,flatRoof:true,wall:"#c9b7a0",roof:"#6b7184",cols:4});
    S.room({x:c1,w:13,d:8,h:4,wall:T.wallpaper("#b9c8c8","#839b9b","stripe"),
      floor:T.tiles("#d9d2c0","#8a8478",10),window:false,door:true,sideWalls:false});
    S.shelf(c1-4,-2,{seed:8});S.crate(c1+4,-3,.9);
    S.hangLamp(c1,3.7,-2,{col:"#e4bd62",i:8});
  } else if(["dinosaur","tree_door","shadows","sky_island"].includes(EP.kind)){
    S.tree(c1-5,-4,{type:"round",s:2});S.tree(c1+5,-5,{type:"pine",s:1.8});
    S.bush(c1-2,-2,1.3);S.bush(c1+3,-1,1.2);S.fence(c1-8,c1+8,-8,{col:"#eee5d4"});
    if(EP.kind==="sky_island") S.clouds({n:8,z:-22,y:10,spread:45,seed:22});
  } else {
    S.street({x:c1,len:34,width:10,z:-5,col:"#b9aa8c"});
    S.row(c1-15,c1+15,-11,{seed:44});
    S.lamp(c1-7,-2,{on:true});S.lamp(c1+7,-2,{on:false});
  }
  // 3) Son keşif alanı: bölümün olayına göre farklı arka plan
  const c2=64;
  if(EP.kind==="mailbox"||EP.kind==="clocktower"||EP.kind==="time"){
    S.building(c2-5,-10,{w:9,d:8,floors:3,wall:"#d8c69c",roof:"#8c5547",cols:3});
    S.lamp(c2+5,-2,{on:true});S.bench(c2,3,0);
  } else if(EP.kind==="dinosaur"||EP.kind==="tree_door"||EP.kind==="shadows"){
    S.tree(c2-5,-5,{type:"pine",s:2.2});S.tree(c2+5,-6,{type:"round",s:2.4});
    S.hills({z:-18,col:"#719b63",n:5,seed:14});
  } else {
    S.building(c2,-10,{w:16,d:10,floors:2,wall:"#b9c9d8",roof:"#596d8c",cols:4});
    S.street({x:c2,len:28,width:9,z:-4,col:"#c4b69c"});
  }
  R.props=[makeEpisodeProp(E,S,T,0),makeEpisodeProp(E,S,T,c1),makeEpisodeProp(E,S,T,c2)];
  // Ana karakterlerin görünüşleri bütün bölümlerde sabit.
  E.actor("poyraz",{skin:"#f6dcc0",shirt:"#36a6b8",jacket:"#26788a",pants:"#283a57",shoes:"#f0a84a",hair:"spiky",hairCol:"#39271f",seed:17,build:"kid"});
  E.actor("ece",{skin:"#fbf5ea",shirt:"#e66d65",jacket:"#c84e59",pants:"#7651a0",shoes:"#f4d16a",hair:"long",hairCol:"#3a2521",seed:29,build:"kid"});
  E.actor("piko",{skin:"#d8f3e8",shirt:"#45bda9",jacket:"#258d82",pants:"#344b58",shoes:"#d8f3e8",hat:"helmet",hatCol:"#45bda9",glasses:true,seed:41,build:"kid"});
  E.actor("prof",{skin:"#f0d0b0",shirt:"#65946b",jacket:"#3d704e",pants:"#51413a",shoes:"#40352f",hair:"part",hairCol:"#d8d6ce",moustache:"#e7e2d7",glasses:true,seed:53,build:"stout"});
}

export function frame(f,E) {
  const fps=30, words=E.words||[], lines=EP.lines||[];
  const lastEnd=words.length?words[words.length-1].e:58;
  const totalFrames=Math.max(1,Math.ceil(lastEnd*fps)+18);
  const timed=lines.map((ln,i)=>({
    ...ln,
    from:Math.max(0,E.W(ln.start_word)-2),
    to:ln.end_word+1<words.length?E.W(ln.end_word+1)+2:totalFrames
  }));
  let li=timed.findIndex(x=>f>=x.from&&f<=x.to);
  if(li<0) li=Math.max(0,timed.length-1);
  const active=timed[li]||{speaker:"Poyraz",text:""};
  const speaker=active.speaker;
  const progress=clamp(f/totalFrames,0,1);
  const stage=progress<.34?0:progress<.69?1:2;
  const centers=[0,32,64];
  const center=32*smooth((progress-.29)/.10)+32*smooth((progress-.64)/.10);
  const local=stage===0?progress/.34:stage===1?(progress-.34)/.35:(progress-.69)/.31;
  const stageStart=stage===0?0:stage===1?.34:.69;
  const stageEnd=stage===0?.34:stage===1?.69:1;
  const walkIn=smooth((progress-stageStart)/.055);
  const walkOut=1-smooth((progress-(stageEnd-.055))/.055);
  const travel=clamp(Math.min(walkIn,walkOut),0,1);
  const speakerIndex={Poyraz:0,Ece:1,Piko:2,"Profesör Fikri":3}[speaker]??0;
  const speakerX=[-1.35,1.25,.1,2.55][speakerIndex];
  const lineSpan=Math.max(1,active.to-active.from);
  const lineT=clamp((f-active.from)/lineSpan,0,1);
  const move=Math.sin(lineT*Math.PI*2);
  const talk=(name)=>speaker===name?E.talk(f,active.from,active.to):0;
  const lineNo=Math.max(0,li);
  const gestures=["present","point","shrug","think","wave","cheer","hold","reach"];
  const gesture=gestures[lineNo%gestures.length];
  // Konuşan karakter jest yapar; diğerleri konuşana döner, bakış ve beden tepkisi verir.
  const actor=(id,baseX,baseZ,seed,name)=>{
    const isSpeaking=speaker===name;
    const targetX=center+baseX+(isSpeaking?.12*move:0);
    const walkPhase=(f/18+seed*.071)%1;
    const walking=travel>.05;
    const face=isSpeaking?(active.text.includes("?")?"think":active.text.includes("!")?"wow":"happy"):
      (name==="Ece"?"think":"neutral");
    const arms=isSpeaking?gesture:(name==="Piko"?"chin":"hang");
    const look=isSpeaking?0.05:(speakerIndex===0?-.3:speakerIndex===1?.3:0);
    return {id,pos:[targetX,0,baseZ],st:actorState(E,f,seed,face,arms,talk(name),{
      legs:walking?"walk":"stand",phase:walkPhase,look,headTilt:isSpeaking?2*move:0,
      lean:isSpeaking?.025:0
    })};
  };
  const actors=[
    actor("poyraz",-1.35,.6,7,"Poyraz"),
    actor("ece",1.25,.35,13,"Ece"),
    actor("piko",.15,1.85,19,"Piko")
  ];
  if(lines.some(x=>x.speaker==="Profesör Fikri"))
    actors.push(actor("prof",2.55,-.45,23,"Profesör Fikri"));
  // Kamera: her replikte açı değişir, sahne geçişlerinde yeni mekâna doğru akar.
  const cameraCenterAt=p=>32*smooth((p-.29)/.10)+32*smooth((p-.64)/.10);
  const keys=[{f:0,pos:[-1.5,3.4,13],look:[0,1.3,-1],fov:48}];
  timed.forEach((ln,i)=>{
    const p=clamp(ln.from/totalFrames,0,1), cx=cameraCenterAt(p);
    const who=ln.speaker, offset=who==="Poyraz"?-1.25:who==="Ece"?1.2:who==="Piko"?0:2.0;
    const shot=i%4, z=shot===0?12:shot===1?9:shot===2?10.5:8.5;
    const y=shot===2?2.0:shot===3?2.35:3.0;
    keys.push({f:Math.max(1,ln.from),pos:[cx+offset,y,z],look:[cx,1.35,-1],fov:shot===3?39:shot===1?43:47});
  });
  keys.push({f:totalFrames,pos:[64,2.5,8],look:[64,1.45,-1],fov:42});
  keys.sort((a,b)=>a.f-b.f);
  const uniqueKeys=keys.filter((k,i)=>i===0||k.f>keys[i-1].f);
  const cam=E.camAt(f,uniqueKeys,{creep:.18});
  const fx=[];
  if(active.text.includes("?"))fx.push({kind:"question",pos:[center+speakerX*.35,3.0,.2],size:.48,t:lineT});
  if(active.text.includes("!"))fx.push({kind:"exclaim",pos:[center+speakerX*.35,3.0,.2],size:.5,t:lineT});
  if(EP.kind==="mailbox"&&f>totalFrames*.45&&f<totalFrames*.78)
    fx.push({kind:"sparkle",pos:[center,2.8,-1.5],size:.6,t:lineT});
  // Nesneye küçük, sürekli ve hikâyeye bağlı hareketler.
  R.props.forEach((p,i)=>{
    p.visible=i===stage;
    if(i===stage){
      p.rotation.y=.05*Math.sin(f/32);
      if(EP.kind==="sky_island")p.position.y=.16*Math.sin(f/22);
      if(EP.kind==="time"||EP.kind==="clocktower")p.rotation.y=.12*Math.sin(f/28);
      if(EP.kind==="mailbox"&&stage===1)p.position.y=.05*Math.sin(f/8);
    }
  });
  return {
    cam,light:stage===2?"golden":"day",
    dof:{focus:[center,1.4,-1],amount:4,range:9},
    actors,fx
  };
}
