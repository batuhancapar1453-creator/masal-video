#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tuhaf Kasaba: GitHub Actions için 10 bölümlük otomatik üretim ve YouTube yükleme."""
import asyncio, json, os, re, shutil, subprocess, sys, time, wave, random
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

import edge_tts
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError

ROOT = Path(__file__).resolve().parents[1]
KIT = ROOT / "cizgi-short" / "kit"
SERIES = ROOT / "tuhaf-kasaba"
EPISODES = SERIES / "episodes"
DATA = ROOT / "data" / "tuhaf_kasaba_history.json"
OUT = ROOT / "output"
PROJECT = ROOT / "work_tuhaf_kasaba"
FPS = 30
RENDER_SCALE = "0.67"
YOUTUBE_PRIVACY = os.getenv("YOUTUBE_PRIVACY", "public").strip()
YOUTUBE_CLIENT_ID = os.getenv("YOUTUBE_CLIENT_ID", "").strip()
YOUTUBE_CLIENT_SECRET = os.getenv("YOUTUBE_CLIENT_SECRET", "").strip()
YOUTUBE_REFRESH_TOKEN = os.getenv("YOUTUBE_REFRESH_TOKEN", "").strip()

VOICE_MAP = {
    "Poyraz": {"voice": "tr-TR-AhmetNeural", "rate": "+2%", "pitch": "+3Hz"},
    "Ece": {"voice": "tr-TR-EmelNeural", "rate": "+1%", "pitch": "+0Hz"},
    "Piko": {"voice": "tr-TR-AhmetNeural", "rate": "+9%", "pitch": "+18Hz"},
    "Profesör Fikri": {"voice": "tr-TR-AhmetNeural", "rate": "-8%", "pitch": "-12Hz"},
}

def run(cmd, cwd=None, timeout=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), cwd=str(cwd) if cwd else None, check=True, timeout=timeout)

def require_secrets():
    missing = [k for k,v in {
        "YOUTUBE_CLIENT_ID": YOUTUBE_CLIENT_ID,
        "YOUTUBE_CLIENT_SECRET": YOUTUBE_CLIENT_SECRET,
        "YOUTUBE_REFRESH_TOKEN": YOUTUBE_REFRESH_TOKEN,
    }.items() if not v]
    if missing:
        raise RuntimeError("GitHub Secrets eksik: " + ", ".join(missing))
    if YOUTUBE_PRIVACY not in ("public","private","unlisted"):
        raise RuntimeError("YOUTUBE_PRIVACY public/private/unlisted olmalı.")

def current_slot():
    now = datetime.now(ZoneInfo("Europe/Istanbul"))
    event = os.getenv("GITHUB_EVENT_NAME", "workflow_dispatch")
    run_id = os.getenv("GITHUB_RUN_ID", "local")
    slot = (f"{now:%Y-%m-%d}-" + ("sabah" if now.hour < 15 else "aksam")
            if event == "schedule" else f"manuel-{run_id}")
    return slot

def load_history():
    DATA.parent.mkdir(parents=True, exist_ok=True)
    if not DATA.exists():
        return []
    data = json.loads(DATA.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise RuntimeError("data/tuhaf_kasaba_history.json bir JSON listesi olmalı.")
    return data

def choose_episode(history):
    used = {x.get("episode_id") for x in history}
    for path in sorted(EPISODES.glob("episode_*.json")):
        ep = json.loads(path.read_text(encoding="utf-8"))
        if ep["id"] not in used:
            return ep
    print("10 bölümün tamamı yayımlandı. Yeni bölüm eklenene kadar işlem tamamlandı.")
    return None

async def make_tts(text, speaker, destination):
    spec = VOICE_MAP.get(speaker, VOICE_MAP["Poyraz"])
    last = None
    for attempt in range(1,4):
        try:
            await edge_tts.Communicate(
                text=text, voice=spec["voice"],
                rate=spec["rate"], pitch=spec["pitch"]
            ).save(str(destination))
            if destination.exists() and destination.stat().st_size > 1500:
                return
            raise RuntimeError("TTS çıktısı boş veya çok küçük.")
        except Exception as exc:
            last = exc
            print(f"TTS tekrar denemesi {attempt}/3 ({speaker}): {str(exc)[:180]}")
            await asyncio.sleep(attempt * 2)
    raise RuntimeError(f"{speaker} seslendirmesi üretilemedi: {last}")

async def build_voice(episode):
    work = PROJECT / "work"
    voice_dir = work / "dialogue"
    voice_dir.mkdir(parents=True, exist_ok=True)
    script_lines = []
    word_cursor = 0
    timed_lines = []
    for i, line in enumerate(episode["lines"]):
        text = line["text"].strip()
        speaker = line["speaker"]
        words = text.split()
        timed_lines.append({
            "speaker": speaker, "text": text,
            "start_word": word_cursor,
            "end_word": word_cursor + len(words) - 1
        })
        word_cursor += len(words)
        script_lines.append(text)
        mp3 = voice_dir / f"line_{i:03d}.mp3"
        wav = voice_dir / f"line_{i:03d}.wav"
        await make_tts(text, speaker, mp3)
        run(["ffmpeg","-hide_banner","-loglevel","error","-y","-i",mp3,
             "-ac","2","-ar","48000","-c:a","pcm_s16le",wav])
    (PROJECT/"script.txt").write_text("\n".join(script_lines)+"\n",encoding="utf-8")
    (PROJECT/"episode.json").write_text(json.dumps({
        **episode, "lines": timed_lines
    },ensure_ascii=False,indent=2),encoding="utf-8")

    wavs = sorted(voice_dir.glob("line_*.wav"))
    if not wavs:
        raise RuntimeError("Ses dosyaları oluşturulamadı.")
    params = None
    chunks = []
    with wave.open(str(wavs[0]),"rb") as first:
        params = first.getparams()
    silence_frames = int(params.framerate * 0.14)
    silence = b"\x00" * silence_frames * params.nchannels * params.sampwidth
    for wav in wavs:
        with wave.open(str(wav),"rb") as src:
            if (src.getnchannels(),src.getsampwidth(),src.getframerate()) != (params.nchannels,params.sampwidth,params.framerate):
                raise RuntimeError("Diyalog seslerinin WAV biçimleri birbiriyle uyuşmuyor.")
            chunks.append(src.readframes(src.getnframes()))
    voice_path = work / "voice.wav"
    with wave.open(str(voice_path),"wb") as dst:
        dst.setnchannels(params.nchannels)
        dst.setsampwidth(params.sampwidth)
        dst.setframerate(params.framerate)
        for i, chunk in enumerate(chunks):
            dst.writeframesraw(chunk)
            if i < len(chunks)-1:
                dst.writeframesraw(silence)
    with wave.open(str(voice_path),"rb") as vf:
        duration = vf.getnframes()/vf.getframerate()
    print(f"Karakter sesleri birleştirildi: {duration:.1f} saniye · {word_cursor} kelime")
    return duration

def setup_project():
    if PROJECT.exists():
        shutil.rmtree(PROJECT)
    PROJECT.mkdir(parents=True)
    for folder in ("engine","vendor","fonts","tools"):
        shutil.copytree(KIT/folder, PROJECT/folder)
    for folder in ("work","frames","stills","out"):
        (PROJECT/folder).mkdir(parents=True,exist_ok=True)
    shutil.copy2(SERIES/"story.js",PROJECT/"story.js")
    # Finish aracı 810x1440 çalışma karelerini 1080x1920 Shorts çıktısına büyütür.
    finish = PROJECT/"tools"/"finish.py"
    txt = finish.read_text(encoding="utf-8")
    old = '"-framerate", "30", "-i", os.path.join(proj, "frames", "f%05d.jpg"), "-i", mix,'
    new = '"-framerate", "30", "-i", os.path.join(proj, "frames", "f%05d.jpg"), "-i", mix, "-vf", "scale=1080:1920:flags=lanczos",'
    if old not in txt:
        raise RuntimeError("finish.py beklenen sürümde değil; güvenli çözünürlük düzenlemesi yapılamadı.")
    finish.write_text(txt.replace(old,new),encoding="utf-8")

def build_sound_json(duration):
    obj = {
        "voice":"work/voice.wav",
        "music":{"style":"mischief","bpm":110,"start":0.0,"stop":round(duration,2),"sting":True,"level_db":-16},
        "sfx":[
            {"t":0.15,"kind":"whoosh","gain_db":-7},
            {"t":max(5.0,duration*0.22),"kind":"pop","gain_db":-7},
            {"t":max(12.0,duration*0.48),"kind":"boing","gain_db":-8},
            {"t":max(20.0,duration*0.72),"kind":"magic","gain_db":-8},
            {"t":max(25.0,duration-1.2),"kind":"sting","gain_db":-8}
        ]
    }
    (PROJECT/"sound.json").write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")

def youtube_upload(path, episode):
    import unicodedata
    from google.auth.exceptions import RefreshError

    title = f"Tuhaf Kasaba - Bölüm {episode['number']:02d}: {episode['title']} #Shorts"
    title = unicodedata.normalize("NFC", title)[:100]

    def clean_description(value, limit=4400):
        value = unicodedata.normalize("NFC", str(value or ""))
        chars = []
        for ch in value:
            cat = unicodedata.category(ch)
            if ch in "\n\r\t":
                chars.append(ch)
            elif cat[0] != "C":
                chars.append(ch)
            else:
                chars.append(" ")
        value = "".join(chars).replace("\r\n","\n").replace("\r","\n")
        value = re.sub(r"[ \t]+"," ",value)
        value = re.sub(r"\n{3,}","\n\n",value).strip()
        out, units = [], 0
        for ch in value:
            cost = 2 if ord(ch)>0xFFFF else 1
            if units+cost>limit: break
            out.append(ch); units += cost
        return "".join(out).rstrip()

    story_description = str(episode.get("description", "")).strip()
    if not story_description:
        story_description = (
            f"Tuhaf Kasaba'nın {episode['number']}. bölümünde Poyraz, Ece ve Piko "
            f"'{episode['title']}' macerasında beklenmedik bir gizemle karşılaşıyor. "
            "Üç arkadaşımızın bu tuhaf olayın sırrını nasıl çözeceğini öğrenmek için bölümü sonuna kadar izle!"
        )
    intro = (
        f"{title}\n\n"
        f"{story_description}\n\n"
        "Yeni maceraları kaçırmamak için kanala abone olmayı ve videoyu beğenmeyi unutma!\n\n"
        "#TuhafKasaba #ÇizgiFilm #TürkçeAnimasyon #Macera #Shorts"
    )
    description = clean_description(intro, 4400)
    fallback_description = clean_description(
        f"{title}\n\n{story_description}\n\n#TuhafKasaba #ÇizgiFilm #Shorts", 1800)
    minimal_description = clean_description(
        f"Tuhaf Kasaba - {episode['title']} #Shorts", 500)

    tags = ["Tuhaf Kasaba","Çizgi Film","Animasyon","Türkçe Animasyon",
            "Komedi","Macera","Poyraz","Ece","Piko","YouTube Shorts"]
    body = {
        "snippet":{"title":title,"description":description,
                   "tags":tags,"categoryId":"24","defaultLanguage":"tr",
                   "defaultAudioLanguage":"tr"},
        "status":{"privacyStatus":YOUTUBE_PRIVACY,
                  "selfDeclaredMadeForKids":False,
                  "containsSyntheticMedia":True}
    }
    creds = Credentials(token=None,refresh_token=YOUTUBE_REFRESH_TOKEN,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=YOUTUBE_CLIENT_ID,client_secret=YOUTUBE_CLIENT_SECRET,
        scopes=["https://www.googleapis.com/auth/youtube.upload"])
    try:
        creds.refresh(Request())
    except RefreshError as exc:
        raise RuntimeError("YouTube OAuth yenilenemedi: "+str(exc)[:260]) from exc
    youtube = build("youtube","v3",credentials=creds,cache_discovery=False)

    def new_request():
        media = MediaFileUpload(str(path),mimetype="video/mp4",
                                chunksize=8*1024*1024,resumable=True)
        return youtube.videos().insert(part="snippet,status",body=body,media_body=media)

    request = new_request()
    result = None
    retry = 0
    fallback_stage = 0
    max_retries = 6
    while result is None:
        try:
            _,result = request.next_chunk(num_retries=3)
            retry = 0
        except HttpError as exc:
            status = getattr(exc.resp,"status",0)
            raw = getattr(exc,"content",b"")
            try:
                payload = json.loads(raw.decode("utf-8","replace"))
                api_error = payload.get("error",{})
                reasons = [x.get("reason","") for x in api_error.get("errors",[])]
                message = api_error.get("message","")
            except Exception:
                reasons, message = [], str(exc)
            reason_text = " ".join(reasons)
            raw_text = raw.decode("utf-8","replace")

            if status==400 and "invalidDescription" in raw_text:
                fallbacks=[fallback_description,minimal_description]
                if fallback_stage<len(fallbacks):
                    body["snippet"]["description"]=fallbacks[fallback_stage]
                    fallback_stage+=1
                    print(f"YouTube açıklamayı reddetti; güvenli açıklama yedeği {fallback_stage}/2 deneniyor.")
                    request=new_request()
                    retry=0
                    continue

            transient = (status in (408,429,500,502,503,504) or
                (status==403 and any(x in reason_text for x in
                ("rateLimitExceeded","userRateLimitExceeded","backendError"))))
            if transient and retry<max_retries:
                retry+=1
                delay=min(60,2**retry)+random.uniform(0,1.5)
                print(f"YouTube geçici HTTP {status} hatası ({retry}/{max_retries}); {delay:.1f} sn sonra tekrar denenecek.")
                time.sleep(delay)
                continue
            if status==403 and "quotaExceeded" in reason_text:
                raise RuntimeError("YouTube API günlük kotası dolmuş. Video hazır; kota sıfırlanınca yeniden deneyin.") from exc
            if status in (401,403):
                raise RuntimeError(f"YouTube yetki/izin hatası HTTP {status} ({reason_text or 'unknown'}): {message[:300]}") from exc
            raise RuntimeError(f"YouTube yükleme hatası HTTP {status} ({reason_text or 'unknown'}): {message[:350]}") from exc
        except (OSError,ConnectionError,TimeoutError) as exc:
            if retry>=max_retries:
                raise RuntimeError("YouTube ağ hatası; tekrar deneme sınırı aşıldı: "+str(exc)[:250]) from exc
            retry+=1
            delay=min(60,2**retry)+random.uniform(0,1.5)
            print(f"Yükleme bağlantısı kesildi ({retry}/{max_retries}); {delay:.1f} sn sonra tekrar denenecek.")
            time.sleep(delay)

    video_id = result.get("id") if isinstance(result,dict) else None
    if not video_id:
        raise RuntimeError("YouTube yanıtında video ID bulunamadı.")
    return video_id, title

def main():
    require_secrets()
    history = load_history()
    slot = current_slot()
    if any(x.get("slot")==slot for x in history):
        print("Bu zaman aralığında video zaten yayımlanmış:",slot)
        return
    episode = choose_episode(history)
    if episode is None:
        return
    print(f"Seçilen bölüm: {episode['number']:02d} — {episode['title']}")
    setup_project()
    duration = asyncio.run(build_voice(episode))
    if duration < 42 or duration > 120:
        raise RuntimeError(f"Bölüm ses süresi hedef dışı: {duration:.1f} sn (beklenen 42–120 sn). Video yüklenmeyecek.")
    build_sound_json(duration)

    print("1/5 Ses zamanlaması hazırlanıyor...")
    run([sys.executable,"tools/timing.py","."],cwd=PROJECT,timeout=900)
    print("2/5 Müzik ve efektler oluşturuluyor...")
    run([sys.executable,"tools/audio.py","."],cwd=PROJECT,timeout=900)

    # Önizleme kareleri ve ardından tam render.
    print("3/5 Animasyon önizlemesi hazırlanıyor...")
    words = json.loads((PROJECT/"work"/"words.json").read_text(encoding="utf-8"))
    frame_count = max(2, int(words[-1]["e"] * FPS) + 18)
    preview_frames = ",".join(str(int((frame_count-1)*i/11)) for i in range(12))
    run([sys.executable,"tools/render.py",".","stills",preview_frames,
         "--scale",RENDER_SCALE,"--cpu"],cwd=PROJECT,timeout=1800)
    run([sys.executable,"tools/sheet.py","stills","stills/preview_sheet.jpg"],cwd=PROJECT,timeout=300)
    print("4/5 Tam animasyon render ediliyor (bu adım uzun sürebilir)...")
    run([sys.executable,"tools/render.py",".","frames","--scale",RENDER_SCALE,"--cpu","--resume"],
        cwd=PROJECT,timeout=150*60)
    run([sys.executable,"tools/finish.py",".",f"Tuhaf_Kasaba_{episode['number']:02d}"],cwd=PROJECT,timeout=1800)

    final_src = next((PROJECT/"out").glob("Tuhaf_Kasaba_*.mp4"),None)
    if not final_src or not final_src.exists():
        raise RuntimeError("Animasyon MP4 dosyası oluşturulamadı.")
    OUT.mkdir(exist_ok=True)
    final = OUT/f"Tuhaf_Kasaba_{episode['number']:02d}_{re.sub(r'[^A-Za-z0-9]+','_',episode['title']).strip('_')}.mp4"
    shutil.copy2(final_src,final)

    probe = json.loads(subprocess.check_output([
        "ffprobe","-v","error","-show_streams","-show_format","-of","json",str(final)
    ],text=True))
    streams=probe.get("streams",[])
    video=next((x for x in streams if x.get("codec_type")=="video"),{})
    audio=next((x for x in streams if x.get("codec_type")=="audio"),{})
    dur=float(probe.get("format",{}).get("duration",0))
    if (video.get("width"),video.get("height")) != (1080,1920):
        raise RuntimeError(f"Çıktı çözünürlüğü 1080x1920 değil: {video.get('width')}x{video.get('height')}")
    if video.get("r_frame_rate")!="30/1" or video.get("codec_name")!="h264":
        raise RuntimeError("Video 30 FPS H.264 biçiminde değil.")
    if audio.get("codec_name")!="aac" or not (42<=dur<=120):
        raise RuntimeError(f"Ses/uzunluk kontrolü başarısız: {dur:.1f}s (beklenen 42–120s), audio={audio.get('codec_name')}")
    print(f"Kalite kontrolü tamamlandı: {dur:.1f} sn, 1080x1920, 30 FPS.")

    print("5/5 YouTube'a yükleniyor...")
    video_id, title = youtube_upload(final,episode)
    record={
        "slot":slot,"episode_id":episode["id"],"episode_number":episode["number"],
        "title":episode["title"],"youtube_title":title,
        "youtube_id":video_id,"url":f"https://www.youtube.com/watch?v={video_id}",
        "duration_seconds":round(dur,2),
        "uploaded_at":datetime.now(ZoneInfo("Europe/Istanbul")).isoformat()
    }
    history.append(record)
    DATA.write_text(json.dumps(history,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (OUT/"upload-result.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
    run(["git","config","user.name","github-actions[bot]"])
    run(["git","config","user.email","41898282+github-actions[bot]@users.noreply.github.com"])
    run(["git","add",str(DATA.relative_to(ROOT))])
    run(["git","commit","-m",f"Tuhaf Kasaba bölüm {episode['number']:02d} yayın geçmişi"])
    try:
        run(["git","push","origin","HEAD:main"])
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            "Video YouTube'a yüklendi fakat yayın geçmişi GitHub'a gönderilemedi. "
            "output/upload-result.json kaydını data/tuhaf_kasaba_history.json dosyasına ekleyin."
        ) from exc
    print("BAŞARILI:",record["url"])

if __name__=="__main__":
    main()
