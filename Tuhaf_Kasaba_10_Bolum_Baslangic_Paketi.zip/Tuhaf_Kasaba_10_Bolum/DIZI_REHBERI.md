# TUHAF KASABA — Dizi Rehberi

## Format
- 10 bölüm, her biri yaklaşık 60 saniye.
- YouTube Shorts için dikey 9:16, 1080×1920, 30 FPS.
- Diyaloglar karakterlerin kendi sesleriyle duyulur; tek anlatıcı kullanılmaz.
- Her bölümde hızlı açılış, yükselen komedi/gizem, küçük çözüm ve bölüm sonu esprisi bulunur.

## Görsel dil (yüklenen cizgi-short paketine dayanır)
- Büyük yuvarlak kafalı, basit ve okunaklı 2D karton karakterler.
- İnce çizgi kol ve bacaklar, belirgin siyah mürekkep konturları.
- Karakterler renkli, dokulu 3D çevrenin içinde görünür.
- Yumuşak gölgeler, alan derinliği, süzülen kamera.
- Tek kelimelik altyazı varsayılanı ve sesin altında kalan müzik.
- Karakter, hikâye ve çekimler özgün olmalı; başka bir videonun sahne sahne kopyası yapılmamalı.

## Ana karakterler
- **Poyraz:** Turkuaz-mavi üst, koyu lacivert pantolon, dağınık kısa saç. Meraklı, cesur, aceleci; çoğu zaman önce harekete geçer.
- **Ece:** Mercan-kırmızı üst, mor etek/pantolon, koyu renk atkuyruğu. Zeki, dikkatli, çözüm odaklı; tehlikeli düğmelere basılmasını engellemeye çalışır.
- **Piko:** Küçük yuvarlak robot; mint yeşili gövde, tek anten, parlak gözler. Bilgili görünür ama komik yanlış yorumlar yapar.
- **Profesör Fikri:** Kısa, tombul yapılı, beyaz bıyıklı, yeşil laboratuvar ceketi ve yuvarlak gözlük. Az görünür; ana gizemin bağını kurar.

## Ses kimlikleri
- **Poyraz:** Genç erkek sesi; enerjik, meraklı, hızlı ama anlaşılır.
- **Ece:** Genç kadın sesi; canlı, net, kendinden emin ve esprili.
- **Piko:** Hafif metalik/robotik tını; kısa, ölçülü cümleler, komik duraksamalar.
- **Profesör Fikri:** Orta yaşlı erkek sesi; sıcak, hafif çatallı, sakin.

Her karakterin replikleri ayrı ses dosyası olarak üretilebilir/kaydedilebilir. Sıralı diyaloglar tek bir `work/voice.mp3` dosyasında birleştirilir. Paket zamanlama aracına bu birleşik ses ve `script.txt` verilir. Seslendirme kesilmez veya hızlandırılmaz.

## Süre ve metin
60 saniyelik hedef, Türkçe konuşma hızına göre yaklaşık 130–150 kelimedir. Buradaki senaryolar ilk taslaktır; gerçek ses kaydı süresine göre doğal duraklarla ayarlanmalıdır.

## Bölüm sürekliliği
Bölümler 1–9'da bulunan nesne/semboller 10. bölümde saat kulesindeki dokuz işarette birleşir. Her bölüm kendi içinde anlaşılır, 10. bölüm sezon finali görevi görür.

## Paket lisansı ve kredi
Kaynak paketteki LICENSE.txt koşullarını inceleyerek dağıtımda gerekli krediyi koruyun. Kaynak kitin hazırlayıcı kredisi: **Burak Özer (@burakozerweb)**. Three.js lisans bildirimini de kaynak paketindeki dosyayla birlikte tutun.
