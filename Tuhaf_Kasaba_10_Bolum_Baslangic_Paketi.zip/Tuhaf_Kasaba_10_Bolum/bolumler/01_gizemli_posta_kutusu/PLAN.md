# Bölüm 01: Gizemli Posta Kutusu

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Poyraz, Piko
Diyalog: Kasabanın ortasındaki posta kutusu az önce kendi kendine konuştu! Okuyorum: Saat üçte kasaba meydanından uzak durun. Notta şöyle yazıyor: Ördeğe ekmeği vermeyin.

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Ece
Diyalog: Posta kutuları konuşmaz. En fazla mektup yutar. Saat üç olmak üzere. Bu bir şaka olabilir. Bence bugün meydandan uzak durmak yerine oraya gitmeliyiz.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko, Poyraz
Diyalog: Düzeltme: Bu kutu mektup yutmuyor. Mektup üretiyor. Şakaysa neden zarfın içinden meydanın fotoğrafı çıktı? Haklısın. Gizemi çözmeden hiçbir yere gitmiyoruz!

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Poyraz, Piko, Ece
Diyalog: Üzerinde benim adım yazan bir zarf var. Ama ben göndermedim. Fotoğrafta meydan boş. Ama gökyüzünde kocaman bir ördek var. Önce meydanın çevresine güvenli bir işaret koyalım. Kimse yaklaşmasın.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Ece, Poyraz
Diyalog: Açmadan önce tarihine bak. Burada yarın yazıyor. Ördek mi? Şimdi daha da merak ettim. Şu zarfın üzerinde küçük bir saat resmi var. Akrep tam üçü gösteriyor.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Poyraz, Piko
Diyalog: Yarın mı? İçinde ne yazıyor? Bekleyin! Fotoğrafın arkasında bir not daha var. Saat üçte ördek göründü. Fotoğraftakiyle aynı şapka onda da var!

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
