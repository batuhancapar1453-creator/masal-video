# Bölüm 03: Dilek Otomatı

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Piko
Diyalog: Eski depoda bir otomat buldum. Üzerinde dilek yazıyor. Dilek gerçekleşti. Uçuş kontrolü henüz eklenmemiş. Dilek gerçekleşti. Fakat otomatın fişi çekildi.

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Poyraz, Ece
Diyalog: Bir dilek otomatı mı? Ben uçmak istiyorum! Beni indirin! Biraz fazla uçtum! En iyisi dileklerimizi kendimiz gerçekleştirelim.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Ece, Poyraz
Diyalog: Önce kullanım talimatını okuyalım. Üzerinde küçük yazılar var. Ben de görünmez olmak istiyorum. Belki daha iyi çalışır. Katılıyorum. Özellikle yere sağlam basma dileğini!

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Piko, Ece
Diyalog: Talimat: Dileğini söyle, düğmeye bas. Sonuçlardan makine sorumlu değildir. Dilek kabul edildi. Ece görünmez değil, sadece ışıklar kapandı. Otomatın arkasında bir düğme daha var. Üzerinde dilekleri geri al yazıyor.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Poyraz, Ece, Piko
Diyalog: Ben uçmak istiyorum! Basıyorum! Piko! Işıkları aç! Düğmeye basılırsa bütün dilekler iptal edilecek. Tavana yapışanlar da kurtulacak.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Ece, Poyraz
Diyalog: Poyraz, ayakların yerden kesildi. Ama neden tavana yapıştın? Benim ikinci dileğim çok basit: Herkes yere insin. Bundan sonra dilek dilemeden önce kullanım kılavuzunu okuyacağım.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
