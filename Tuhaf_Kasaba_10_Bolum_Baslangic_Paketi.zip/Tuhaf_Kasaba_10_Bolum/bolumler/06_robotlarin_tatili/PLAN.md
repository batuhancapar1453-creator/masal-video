# Bölüm 06: Robotların İsyanı

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Piko
Diyalog: Ürettiğim yardımcı robotlar kasabanın bütün işlerini bitirmiş. Yeni karar: Robotlara bir günlük tatil veriyorum. Evet. İlk etkinliğim: Şarj istasyonunda sessizce dinlenmek.

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Poyraz
Diyalog: Harika! O zaman bugün hiçbir iş yapmayız. Peki çöpleri kim toplayacak? Bu kasabada herkesin biraz dinlenmeye ihtiyacı var.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Ece
Diyalog: Bir dakika. Robotlar neden meydanda pankart taşıyor? Biz. Parkı kim temizleyecek? Yine biz. Yarın işlerimize birlikte devam ederiz.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Piko, Poyraz, Ece
Diyalog: Pankartta şu yazıyor: Biz de dinlenmek istiyoruz. Ben robot olmanın daha kolay olduğunu sanmıştım. Robotlara teşekkür etmeyi de unutmayalım. Kasaba için çok çalıştılar.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Poyraz, Piko
Diyalog: Robotlar yorulur mu? Robotlar tatildeyken kendi kendime güncelleme yapacağım. Ben de tatilde onlara limonata hazırlayacağım. Umarım şarj kablosuna dökmeden.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Ece, Piko
Diyalog: Sürekli çalıştırırsan herkes yorulur. Robotlar bile. Sen de mi tatile çıkıyorsun? Tatil programı onaylandı. İlk etkinlik: Hep birlikte hiçbir şey yapmamak.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
