# Bölüm 07: Ağacın İçindeki Kapı

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Ece
Diyalog: Bu ağacın gövdesinde küçük bir kapı var. Daha önce görmüş müydünüz? Şu küçük meydanda bizim gibi üç minik karakter var. Anahtar ağacın dalında. Bunu kim düşünmüş olabilir?

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Poyraz
Diyalog: Üzerinde bizim kasabanın sembolü bulunuyor. Bizi görüyorlar! Biri el sallıyor. Belki de bu ağacın kendisi.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko
Diyalog: Kapının arkasında boşluk değil, başka bir yer tespit ediyorum. Boyutlar arası iletişim kuruldu. Sesleri çok ince geliyor. Ağaç az önce göz kırptı. Ben hiçbir şey görmedim.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Ece
Diyalog: Açalım ama birbirimizden ayrılmayalım. Onlar da kendi dünyalarında bizim kapımızı arıyor olabilir. Kapının kenarında dokuz küçük işaret var. Bir gün bunların ne anlama geldiğini bulacağız.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Poyraz
Diyalog: Vay canına! İçeride kasabamızın aynısı var. Kapıyı açık bırakırsak iki dünya karışabilir. Şimdilik minik dostlarımıza el sallayalım. Onları yeniden görmek istiyorum.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Piko
Diyalog: Düzeltme: Burası kasabanın minyatür bir kopyası. Öneri: Kapıyı kapatıp anahtarı güvenli yere saklayalım. Kapı kapandı. Fakat ağacın içinden hafif bir zil sesi geliyor.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
