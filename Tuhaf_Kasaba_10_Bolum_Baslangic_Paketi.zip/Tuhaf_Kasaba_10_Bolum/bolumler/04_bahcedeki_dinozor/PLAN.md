# Bölüm 04: Bahçedeki Minik Dinozor

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Ece
Diyalog: Profesörün bahçesinden tuhaf bir hapşırma sesi geliyor. Ona su verelim ama hortumu değil. Ayakkabıyı bırak! O profesörün en sevdiği çift!

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Poyraz
Diyalog: Çalıların arkasında yeşil, pullu ve minicik bir şey var! Bir dakika... Bizi takip ediyor. Sanırım bizi annesi sanıyor. Sanırım bu kasabada sıradan bir gün hiç yaşanmayacak.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko, Ece
Diyalog: Canlı türü tanımlanamadı. Tahminim: Çok büyük bir kertenkele değil. Profesörün notunu buldum. Deneyin adı: Geçmişten Minik Misafir. Yavrunun boynundaki etikette bir adres var. Profesörün laboratuvarını gösteriyor.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Ece, Piko
Diyalog: Bu bir dinozor yavrusu olabilir mi? Demek profesör bunu yanlışlıkla canlandırmış. Laboratuvara götürürsek onu güvenli biçimde ailesine ulaştırabiliriz.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Poyraz
Diyalog: Merhaba küçük dostum. Acıktın mı? Onu güvenli bir yere götürmeliyiz. Tamam küçük dostum. Ama lütfen ayakkabıları yemeyi bırak.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Piko
Diyalog: Dikkat! Yavru, bütün bahçe hortumunu yutmak üzere. Yeni bilgi: Dinozor yavrusu profesörün ayakkabısını tercih etti.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
