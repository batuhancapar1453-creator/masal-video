# Bölüm 02: Kaybolan Gölgeler

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Ece
Diyalog: Bir dakika... Güneş tepede ama kimsenin gölgesi yok! Benimki de şapka takmış. Üstelik benden daha iyi dans ediyor. İşe yaradı! Hepsi sahiplerine geri dönüyor.

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Poyraz, Piko
Diyalog: Benimki de kaybolmuş. Acaba gölgeler tatile mi çıktı? Gölge topluluğu bir gösteri hazırlıyor olabilir. Sonuç: Gölgeler özgürlük istedi. Ama elektrik faturasını görünce vazgeçti.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko, Poyraz, Ece
Diyalog: Tarama tamamlandı. Gölgeler kasabanın arka sokağında toplanıyor. Geri dönün! Güneş batınca hepimiz karanlıkta kalacağız. Belki de gölgeler her gün bizim peşimizden gelmekten sıkılmıştır.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Ece, Poyraz
Diyalog: Gölge nasıl yürür? Belki de gölgeler sadece biraz eğlenmek istiyor. Benim gölgem bana el sallıyor. Sanırım benden daha sosyal.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Piko
Diyalog: Bilimsel açıklama: Şu an açıklayamıyorum. Yeni bilgi: Gölgeler geri dönmek için ışık kaynağı arıyor. Gölge toplantısının gündemi: Dans, dinlenme ve sahiplerine geri dönme.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Poyraz
Diyalog: Şuraya bakın! Benim gölgem dans ediyor. Kasaba fenerlerini açalım. Herkes kendi gölgesini bulsun.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
