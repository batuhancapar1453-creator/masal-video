# Bölüm 05: Ters Dönen Ev

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Poyraz
Diyalog: Ece! Komşunun evi baş aşağı durmuş! Sakın basma! Geçen sefer ne olduğunu gördük. Peki tavandaki halı neden hâlâ orada?

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Ece
Diyalog: Ev ters değil. İçindeki her şey tavana yapışmış. Belki düğmeyi kapatınca her şey normale döner. Çünkü o halı zaten tavana asılıydı.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko
Diyalog: Yerçekimi ölçümü normal. Sorun yalnızca evin içinde. Uyarı: Düğmenin iki tarafı da ters. Hangi tarafı kapalı? Sonuç: Ev düzeldi. Ama dekorasyon hâlâ kararsız.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Poyraz
Diyalog: Kapıdan girince ben de tavana çıktım! Bunu anlamanın tek yolu var. Birlikte çevirelim. İçerideki saat bile ters dönmüş. Akrep ve yelkovan birbirini kovalıyor.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Ece
Diyalog: Dikkatli ol. Masanın üstünde yürüyen bir sandalye var. Üç, iki, bir! Düğmeye dokunmadan önce etrafı sabitleyelim. Yoksa yine tavana uçarız.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Piko
Diyalog: Evin ortasında küçük bir düğme buldum. Üzerinde ters yazıyor. Yerçekimi normale döndü. Eşyalar güvenli şekilde yere indi. Sabitleme tamamlandı. Bu evde artık hiçbir eşya izinsiz havalanamaz.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
