# Bölüm 08: Duran Zaman

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Poyraz, Piko, Ece
Diyalog: Ece! Herkes olduğu yerde donup kaldı! Hayır. Ben yalnızca alarm kurmuştum. Düğmeye basıyorum. Üç, iki, bir!

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Ece, Poyraz
Diyalog: Kuşlar havada, su damlası havada. Zaman durmuş olmalı. Alarm mı? Ne kadar güçlü olabilir ki? Herkes yeniden hareket ediyor!

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko
Diyalog: Saatler çalışıyor ama çevremizdeki hareket sıfır. Kasabanın bütün saatleri aynı alarmı çalıyor. Sistem bekleme moduna geçti. Güzel haber: Zaman düzeldi. Kötü haber: Alarmı yarına da kurmuşum.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Poyraz, Ece
Diyalog: Biz neden hareket edebiliyoruz? Alarmı kapatmalıyız. Kumanda nerede? Saat kulesinin ibreleri yeniden dönüyor. Herkes kaldığı yerden devam ediyor.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Piko, Poyraz
Diyalog: Muhtemel sebep: İçimdeki saat pili ters takılmış. Şu dev saatin tepesinde! Şu havada asılı kalan su damlası da yere düştü. Tam zamanında kenara çekildim.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Ece, Piko
Diyalog: Piko, zaman makinesi yaptığını söylemiştin. Bu onun denemesi mi? Dikkat. Geri sayım başladı. Alarm ayarları silindi. En azından bir sonraki sürprize kadar.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
