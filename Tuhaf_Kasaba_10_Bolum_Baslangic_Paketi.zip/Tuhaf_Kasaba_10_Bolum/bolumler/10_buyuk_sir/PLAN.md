# Bölüm 10: Büyük Sır

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Piko
Diyalog: Bulduğumuz harita, kasabanın tam merkezini gösteriyor. Kulenin içindeki kayıt cihazını buldum. Açıyorum. Sonuç: Kasaba yaşayan bir macera laboratuvarı.

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Ece, Profesör Fikri
Diyalog: Bütün tuhaf olayların başladığı eski saat kulesi! Merhaba çocuklar. Eğer bunu izliyorsanız, kasabanın sırrını çözmüşsünüz demektir. O zaman sıradaki gizemi birlikte bulalım.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Poyraz, Ece
Diyalog: Kapının üzerinde dokuz küçük sembol var. Hepsi önceki maceralarımızdan. Profesör! Bütün bu olayları siz mi başlattınız? Çünkü Tuhaf Kasaba'da macera hiçbir zaman bitmez!

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Piko, Profesör Fikri, Ece
Diyalog: Posta kutusu, gölgeler, otomat, dinozor, ev, robotlar, ağaç, saat ve ada. Hayır. Ben yalnızca kasabanın merakını uyandıracak küçük deneyler hazırladım. Dokuz işaretin hepsi parlıyor. Demek ki maceralarımız boşuna yaşanmamış.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Ece, Poyraz
Diyalog: Demek bütün olaylar birbirine bağlıymış. Peki gökyüzündeki ada ve konuşan gölgeler? Kasabamızın sırrı bir makine değilmiş. Merakımız ve birlikte çalışmamızmış.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Poyraz, Profesör Fikri
Diyalog: Ama bunları kim düzenledi? Onlar benim planımda yoktu. Kasaba kendi sürprizlerini üretmiş. Unutmayın çocuklar, en büyük keşif bazen doğru soruyu sormaktır.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
