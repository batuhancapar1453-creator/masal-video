# Bölüm 09: Gökyüzündeki Kasaba

Hedef: yaklaşık 60 saniye · 9:16 · 30 FPS

## Çekim planı (ses kaydı geldikten sonra kare aralıkları kesinleştirilecek)
### Sahne 1
Kanca: olağan dışı nesne/olay ilk karede görünür; yakın plan ve hızlı kamera yaklaşması.
Karakterler: Ece
Diyalog: Gökyüzünde yüzen bir ada var. Üzerinde evler görüyorum! Peki neden aşağıya iniyor? Haritada bizim kasabanın altında başka bir işaret var.

### Sahne 2
Karakterler mekâna girer; ikili kadraj ve kısa tepki planları.
Karakterler: Poyraz
Diyalog: Kasabamızın üstünde başka bir kasaba mı var? Şu büyük pervane durmuş. Onu yeniden çevirmeliyiz. Demek macera henüz bitmedi.

### Sahne 3
İlk deneme ters gider; geniş açı, hareketli obje ve belirgin yüz ifadeleri.
Karakterler: Piko
Diyalog: Ada yavaşça alçalıyor. Bir iniş planı yapmalıyız. Rüzgâr yönünü hesapladım. Tepedeki yel değirmenini çalıştırın. Haritanın arkasında tek kelime yazıyor: Merkez.

### Sahne 4
Sorun büyür; kamera takip hareketi ve komik görsel aksiyon.
Karakterler: Ece
Diyalog: Oradakiler bize el sallıyor. Korkmuş görünmüyorlar. Hep birlikte itelim! Haritayı dikkatlice saklayalım. Üzerindeki işaret daha önce hiç görmediğimiz bir yere ait.

### Sahne 5
Karakterler birlikte çözüm dener; ışık/efekt vurgusu.
Karakterler: Poyraz
Diyalog: Belki yardıma ihtiyaçları vardır. Başardı! Ada yeniden yükseliyor. Belki de kasabamızın altında başka bir dünya vardır. Bunu öğrenmeliyiz.

### Sahne 6
Ters köşe ve final esprisi; kısa kamera itişi, müzik kesilmesi ve düşük vurgu efekti.
Karakterler: Piko
Diyalog: İletişim kuruldu. Adanın motoru rüzgârla çalışıyormuş. Gökyüzü kasabası teşekkür olarak bize küçük bir harita gönderdi. Yeni hedef kaydedildi. Merkez konumu sezon finalinde araştırılacak.

## Ses
Karakter repliklerini ayrı karakter sesleriyle üret/kaydet; sonra konuşma sırasına göre tek voice.mp3 dosyasında birleştir.
Müzik ve efektler konuşmanın altında kalmalı. Ses kaydı kesilmemeli veya hızlandırılmamalı.
