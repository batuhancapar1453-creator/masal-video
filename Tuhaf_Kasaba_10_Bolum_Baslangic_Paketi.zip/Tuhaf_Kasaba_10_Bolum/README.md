# Tuhaf Kasaba — 10 Bölümlük Başlangıç Paketi

Bu klasör, gönderdiğiniz `cizgi-short.zip` paketinin kaynak kitini ve ona göre hazırlanmış 10 özgün bölümün senaryo/çekim hazırlık dosyalarını içerir.

## Seçilen üretim ayarları
- 10 bölüm
- Bölüm hedefi: yaklaşık 60 saniye
- Dikey 9:16, 1080×1920, 30 FPS
- Karakterlerin kendi sesleri (tek anlatıcı yok)
- Paket görünümü: büyük yuvarlak kafalı karton karakterler, ince uzuvlar, siyah mürekkep konturlar ve dokulu 3D çevre

## Karakterler
Poyraz, Ece, Piko ve Profesör Fikri. Her bölümde aynı tasarım/renk/kişilik korunmalı.

## Klasörler
- `kaynak_paket/cizgi-short/kit/`: gönderdiğiniz özgün motor ve araçlar
- `DIZI_REHBERI.md`: karakter, ses ve süreklilik rehberi
- `bolumler/`: 10 bölümün script.txt, diyalog.csv, PLAN.md ve sound.json dosyaları

## Önemli: Henüz bitmiş MP4 değildir
Bu teslimat, 10 bölümlük senaryo ve üretim hazırlık paketidir. Gerçek MP4 render'ı için her karakterin ayrı replikleri seslendirilip konuşma sırasına göre birleştirilerek ilgili bölüm klasöründeki `work/voice.mp3` dosyasına konmalıdır. Son okunan metin `script.txt` ile aynı olmalıdır. Ardından kaynak paketin SKILL.md dosyasındaki render adımları izlenir.

Paketin örnek iş akışı kullanıcı sesini ve son okunan metni ister; kendi başına karakterlere ayrı TTS sesleri üretmez. Bu nedenle karakter seslerinin üretimi/kaydı ayrıca yapılmalıdır.

## Kaynak ve kredi
Paketin `LICENSE.txt` ve `kit/vendor/THREE-LICENSE.txt` dosyalarını koruyun. Kaynak paket hazırlayıcısı: Burak Özer (@burakozerweb).
