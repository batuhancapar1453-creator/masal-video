# Tuhaf Kasaba — GitHub Actions kurulum paketi

Bu paket, mevcut `masal-video` deposundaki `video.yml` otomasyon düzenini Tuhaf Kasaba'ya uyarlar.

## GitHub'a eklenecek iki dosya

1. Bu paketteki `.github/workflows/video.yml` dosyasını depodaki aynı konumda bulunan eski `video.yml` ile değiştirin.
2. `tuhaf-kasaba-source.zip` dosyasını deponun kök dizinine yükleyin.

GitHub Actions çalışırken bu ZIP'i açar. ZIP'in içinde:
- `cizgi-short/kit/` — gönderdiğiniz çizgi-short animasyon motoru ve araçları
- `tuhaf-kasaba/run_episode.py` — ses, render, kalite kontrol ve YouTube yükleme otomasyonu
- `tuhaf-kasaba/story.js` — Poyraz, Ece, Piko ve Profesör Fikri animasyon sahnesi
- `tuhaf-kasaba/episodes/episode_01.json` ... `episode_10.json` — 10 bölümün diyalogları

## Gerekli GitHub Secrets

Mevcut YouTube OAuth anahtarlarını aynı isimlerle koruyun:
- `YOUTUBE_CLIENT_ID`
- `YOUTUBE_CLIENT_SECRET`
- `YOUTUBE_REFRESH_TOKEN`

Cloudflare anahtarları bu yeni çizgi film sisteminde kullanılmaz.

## Çalışma düzeni

- `workflow_dispatch`: GitHub Actions ekranından elle çalıştırma
- `23 6,17 * * *`: önceki düzende bulunan günde iki zamanlı çalıştırma (UTC)
- Bölümler sırayla seçilir; daha önce yüklenen bölüm tekrar seçilmez.
- On bölüm tamamlandığında iş akışı yeni bölüm eklenene kadar durur.
- Video, 1080×1920, 30 FPS H.264/AAC MP4 olarak hazırlanır.
- Her karakterin repliği ayrı Edge TTS karakter sesiyle üretilir; sonra konuşma sırasıyla birleştirilir.
- Ağız hareketi, sesin kelime zamanlamasına göre animasyon motorunda çalışır.
- Video yüklemesi yalnızca render ve teknik kontroller başarılı olursa yapılır.
- Yükleme geçmişi `data/tuhaf_kasaba_history.json` dosyasına kaydedilir ve `main` dalına gönderilir.

## Karakter sesleri

- Poyraz: tr-TR-AhmetNeural
- Ece: tr-TR-EmelNeural
- Piko: AhmetNeural, daha hızlı ve yüksek perde
- Profesör Fikri: AhmetNeural, daha yavaş ve düşük perde

Bunlar farklı ses karakterleri oluşturmak için kullanılan TTS ayarlarıdır; gerçek insan ses sanatçısı kaydı değildir.

## Önemli teknik not

Kaynak kitin dokümantasyonu kare başına render süresinin makineye göre değişebileceğini belirtiyor. GitHub runner üzerinde 60 saniyelik, 30 FPS animasyonun render işlemi uzun sürebilir. İş akışının zaman aşımı 300 dakikadır. Çalışma kareleri performans için 0.67 ölçeğinde üretilir ve son MP4 1080×1920'ye yükseltilir.

Animasyon güncellemesi:
- Poyraz, Ece ve Piko replik sırasına göre jest yapar; konuşmayan karakterler konuşmacıya bakar ve tepki verir.
- Karakterler bölüm ilerledikçe meydandan bölüme özgü ikinci mekâna, ardından final alanına yürür.
- Kamera replikler arasında yakın/orta/geniş açıları değiştirir ve sahne geçişlerinde karakterleri takip eder.
- Bölümün ana nesnesi sahneye göre görünür; bazı nesneler olay anında hafif hareket eder.
- YouTube açıklaması artık her bölümün kendi hikâye özetini kullanır; kod, animasyon motoru veya kaynak kredisi açıklamaya eklenmez.

JavaScript/Python sözdizimi ve bölüm JSON kontrolleri yapılmıştır. Bu çalışma ortamında Chromium çalıştırıcısı kurulu olmadığından gerçek kare render önizlemesi alınamamıştır. Gerçek GitHub Actions çalıştırması, Edge TTS erişimi ve YouTube yüklemesi bu ortamda test edilmemiştir.

## Kaynak kredisi ve lisans

Animasyon kiti kaynak dosyalarıyla birlikte korunmuştur. Kaynak hazırlayıcı kredisi: **Burak Özer (@burakozerweb)**. `cizgi-short/LICENSE.txt` ve `cizgi-short/kit/vendor/THREE-LICENSE.txt` bildirimlerini silmeyin.
