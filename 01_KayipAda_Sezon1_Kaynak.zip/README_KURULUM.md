# GizemliStüdyo — KIRILMA: KAYIP ADA / 1. Sezon

Bu paket, mevcut `cizgi-short` motorunu ve YouTube yayın akışını koruyarak 10 bölümlük Kayıp Ada sezonunu günlük sırayla üretmek için hazırlanmıştır.

## GitHub'a kurulum

1. GitHub deposunda `.github/workflows/video.yml` dosyasını oluşturun ve teslim edilen YAML içeriğini bu dosyaya koyun.
2. `GizemliStudyo_KayipAda_Sezon1.zip` dosyasını GitHub deposunun kök dizinine yükleyin.
3. Aşağıdaki GitHub Secrets değerlerinin mevcut olduğunu doğrulayın:
   - `YOUTUBE_CLIENT_ID`
   - `YOUTUBE_CLIENT_SECRET`
   - `YOUTUBE_REFRESH_TOKEN`
4. Actions sekmesinden ilk çalıştırmayı elle başlatabilirsiniz. Zamanlanmış çalışma her gün Türkiye saati 09.00'da (UTC 06.00) bir sonraki yayınlanmamış bölümü seçer.

## Sezon 1

1. Son Rota
2. İlk Gece
3. Ormandaki İzler
4. Şelalenin Ardında
5. Terk Edilmiş Yerleşke
6. Fırtınadan Sonra
7. Yeraltındaki Geçit
8. Dağın Zirvesi
9. Son Kayıt
10. Kıyıdaki Tekne

Ana karakterler Batu, Nur, Alperen, Kubilay ve küçük köpekleri Merco'dur. Her bölüm bir önceki bölümün ipuçlarını sürdürür. Bölüm sırası `data/gizemli404_history.json` geçmişiyle takip edilir; aynı bölüm ikinci kez otomatik yayınlanmaz.

## Video süresi ve çalışma sınırları

- Hedef: her bölüm 60–120 saniye, dikey YouTube Shorts.
- Senaryo ön kontrolü: 80–190 kelime; 15–22 kısa görsel vuruş.
- Üretilen gerçek ses 60–119 saniye aralığına doğal TTS hız ayarıyla sığmazsa render/yükleme durur; diyalog kesilmez.
- Dikey çıktı: 1080×1920, 30 FPS, H.264 video ve AAC ses.
- Render kareleri 540×960 çalışma boyutunda oluşturulur, son aşamada 1080×1920'ye ölçeklenir.
- Render subprocess sınırı 240 dakika, GitHub Actions job sınırı 355 dakikadır. Kısa videoların bile render süresi runner performansına bağlıdır.
- Kalan kareler `.render_cache` üzerinden yeniden kullanılabilir. Kaynak dosyalar değiştiğinde cache anahtarı da değişir.

**Önemli:** Gerçek TTS, tam kare render ve YouTube yüklemesi GitHub Actions ortamında doğrulanmalıdır. Render hızı runner performansına bağlıdır; statik kontroller tek başına başarılı video üretimini garanti etmez.

## Görsel ve ses sistemi

- Karakterler Canvas 2D mürekkep konturlu çöp adam çizimleri; her anlatım vuruşu için ayrı elle çizilmiş 2D arka plan kullanılır.
- Kayıp Ada'ya özel tekne, fırtınalı deniz, kıyı, kamp, orman, nehir, şelale, yerleşke, tünel, araştırma odası ve zirve sahneleri bulunur.
- POV, geniş, yakın, takip ve tepki planları senaryo satırları üzerinden çeşitlendirilir.
- Türkçe Edge Neural sesleri kullanılır. Rol ayrımı aynı motorun ses hızı/perde ayarlarıyla yapılır; farklı gerçek ses oyuncuları değildir.
- Her kısa sahne kendi müzik stili ve temposunu alır; geçişler yumuşatılır ve müzik diyalogların altında mikslenir. Türkçe seslere hafif kompresyon ve loudness normalizasyonu uygulanır.

Mevcut motorun görsel dili stilize 3D/çizgi karakter estetiğidir; bu paket tam uzun metraj fotogerçekçi animasyon üretim motoru değildir. Sahne/çevre ayrıntıları ve kamera düzeni iyileştirilmiştir, ancak gerçek sinema stüdyosu kalitesine ulaşıldığı iddia edilmez.

## Yayın ve hata güvenliği

- YouTube OAuth, yükleme, tekrar deneme ve yayın geçmişi akışı korunur.
- Video, çözünürlük, kare hızı, codec ve ses süresi kontrollerinden geçmeden yüklenmez.
- OAuth ön kontrolü render başlamadan önce yapılır.
- Yayın geçmişi başarılı yüklemeden sonra `main` dalına gönderilir.
- Gerçek YouTube yüklemesi bu çalışma ortamında denenemez; GitHub Secrets ve kanal yetkileri ilk Actions çalışmasında doğrulanır.
