# GizemliStüdyo — KIRILMA / Kayıp Ada Shorts

- Sezon 1: 10 bölüm; günlük otomatik yayın sırası korunur.
- Her bölüm 9:16 dikey, 60–120 saniye aralığında Shorts olarak üretilir.
- Her bölüm 15–20 kısa görsel vuruşa ayrılır; yaklaşık 4 saniyelik ritimle her replik kendi sahnesine ve elle çizilmiş 2D arka planına bağlanır.
- Karakterler Canvas 2D mürekkep konturlu çöp adam stilindedir. Nur uzun koyu saçlı; Batu, Alperen ve Kubilay kısa/erkek saç stilleriyle çizilir.
- Türkçe Edge Neural seslendirme ve mevcut konuşmacı sesleri korunur; hafif kompresyon ve loudness normalizasyonu eklenmiştir.
- Her sahne için ayrı tempo/tarzda müzik yatağı üretilir; müzik konuşmanın altında mikslenir.
- 1080x1920, 30 FPS H.264/AAC çıktı ve 60–120 saniye Shorts kontrolü yükleme öncesi yapılır.

Gerçek render ve YouTube yüklemesi, GitHub Actions ortamında ve gerekli YouTube Secrets tanımlıyken doğrulanabilir.
