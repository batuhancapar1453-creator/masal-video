#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GizemliStüdyo: KIRILMA – KAYIP ADA, 10 bölümlük sezon üretim/yayın motoru."""
import asyncio, json, os, re, shutil, subprocess, sys, time, wave, random, unicodedata
import numpy as np
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

import edge_tts
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError

ROOT = Path(__file__).resolve().parents[1]
KIT = ROOT / "cizgi-short" / "kit"
SERIES = ROOT / "gizemli404"
EPISODES = SERIES / "episodes"
DATA = ROOT / "data" / "gizemli404_history.json"
LEGACY_DATA = ROOT / "data" / "tuhaf_kasaba_history.json"
OUT = ROOT / "output"
PROJECT = ROOT / "work_gizemli404"
FRAME_CACHE_ROOT = ROOT / ".render_cache"
FPS = 30
# 540x960 render, sonra 1080x1920; CPU maliyetini sınırlarken çizgi kenarlarını korur.
RENDER_SCALE = "0.50"
VOICE_MIN_SECONDS = 300
VOICE_MAX_SECONDS = 480
RENDER_TIMEOUT_SECONDS = 300 * 60
YOUTUBE_PRIVACY = os.getenv("YOUTUBE_PRIVACY", "public").strip()
YOUTUBE_CLIENT_ID = os.getenv("YOUTUBE_CLIENT_ID", "").strip()
YOUTUBE_CLIENT_SECRET = os.getenv("YOUTUBE_CLIENT_SECRET", "").strip()
YOUTUBE_REFRESH_TOKEN = os.getenv("YOUTUBE_REFRESH_TOKEN", "").strip()

VOICE_MAP = {
    # Edge Neural ücretsiz Türkçe seçenekleri sınırlı. Hız/perde ve hafif EQ ile rol ayrımı yapılır.
    "Batu": {"voice":"tr-TR-AhmetNeural","rate":"-2%","pitch":"+0Hz","filter":"highpass=f=65,lowpass=f=11500"},
    "Nur": {"voice":"tr-TR-EmelNeural","rate":"-3%","pitch":"+0Hz","filter":"highpass=f=65,lowpass=f=11500"},
    "Alperen": {"voice":"tr-TR-AhmetNeural","rate":"-7%","pitch":"-3Hz","filter":"highpass=f=60,lowpass=f=10500"},
    "Kubilay": {"voice":"tr-TR-AhmetNeural","rate":"+1%","pitch":"+2Hz","filter":"highpass=f=70,lowpass=f=11500"},
    "Merco": {"voice":"tr-TR-AhmetNeural","rate":"+3%","pitch":"+4Hz","filter":"highpass=f=100,equalizer=f=1800:t=q:w=1:g=0.5,lowpass=f=10500"},
}


def run(cmd, cwd=None, timeout=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), cwd=str(cwd) if cwd else None, check=True, timeout=timeout)


def require_secrets():
    missing = [k for k,v in {"YOUTUBE_CLIENT_ID":YOUTUBE_CLIENT_ID,"YOUTUBE_CLIENT_SECRET":YOUTUBE_CLIENT_SECRET,"YOUTUBE_REFRESH_TOKEN":YOUTUBE_REFRESH_TOKEN}.items() if not v]
    if missing: raise RuntimeError("GitHub Secrets eksik: " + ", ".join(missing))
    if YOUTUBE_PRIVACY not in ("public","private","unlisted"):
        raise RuntimeError("YOUTUBE_PRIVACY public/private/unlisted olmalı.")


def current_slot():
    now=datetime.now(ZoneInfo("Europe/Istanbul")); event=os.getenv("GITHUB_EVENT_NAME","workflow_dispatch"); run_id=os.getenv("GITHUB_RUN_ID","local")
    return f"{now:%Y-%m-%d}-09:00" if event=="schedule" else f"manuel-{run_id}"


def _read_history(path):
    if not path.exists(): return []
    data=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data,list): raise RuntimeError(f"{path.relative_to(ROOT)} bir JSON listesi olmalı.")
    return data


def load_history():
    DATA.parent.mkdir(parents=True,exist_ok=True)
    combined=_read_history(DATA)+_read_history(LEGACY_DATA)
    seen=set(); out=[]
    for rec in combined:
        key=(rec.get("slot"),rec.get("episode_id"),rec.get("youtube_id"))
        if key not in seen: seen.add(key); out.append(rec)
    return out


def choose_episode(history):
    used={x.get("episode_id") for x in history}
    for path in sorted(EPISODES.glob("episode_*.json")):
        ep=json.loads(path.read_text(encoding="utf-8"))
        if ep["id"] not in used: return ep
    print("KIRILMA – KAYIP ADA 1. sezonun 10 bölümü tamamlandı. Yeni sezon eklenene kadar yayın durdu.")
    return None


async def make_tts(text,speaker,destination):
    spec=VOICE_MAP.get(speaker,VOICE_MAP["Batu"]); last=None
    for attempt in range(1,4):
        try:
            await asyncio.wait_for(edge_tts.Communicate(text=text,voice=spec["voice"],rate=spec["rate"],pitch=spec["pitch"]).save(str(destination)),timeout=45)
            if destination.exists() and destination.stat().st_size>1500: return
            raise RuntimeError("TTS çıktısı boş veya çok küçük.")
        except Exception as exc:
            last=exc; print(f"TTS tekrar denemesi {attempt}/3 ({speaker}): {str(exc)[:180]}"); await asyncio.sleep(attempt*2)
    raise RuntimeError(f"{speaker} seslendirmesi üretilemedi: {last}")


def _line_gap(line,next_line):
    text=line["text"].strip(); gap=0.28 if line["speaker"]==next_line["speaker"] else 0.42
    if text.endswith(("?","!","…")): gap+=0.14
    elif text.endswith((".",",")): gap+=0.06
    if len(text.split())>=18: gap+=0.06
    return gap


async def build_voice(episode):
    work=PROJECT/"work"; voice_dir=work/"dialogue"; voice_dir.mkdir(parents=True,exist_ok=True)
    timed_lines=[]; word_cursor=0; script_lines=[]; wavs=[]
    for i,line in enumerate(episode["lines"]):
        text=line["text"].strip(); speaker=line["speaker"]; words=text.split()
        timed_lines.append({**line,"start_word":word_cursor,"end_word":word_cursor+len(words)-1})
        word_cursor+=len(words); script_lines.append(text)
        mp3=voice_dir/f"line_{i:03d}.mp3"; wav=voice_dir/f"line_{i:03d}.wav"
        await make_tts(text,speaker,mp3)
        af=VOICE_MAP.get(speaker,VOICE_MAP["Batu"]).get("filter","anull")
        run(["ffmpeg","-hide_banner","-loglevel","error","-y","-i",mp3,"-af",af,"-ac","2","-ar","48000","-c:a","pcm_s16le",wav])
        wavs.append(wav)
    (PROJECT/"script.txt").write_text("\n".join(script_lines)+"\n",encoding="utf-8")
    if not wavs: raise RuntimeError("Ses dosyaları oluşturulamadı.")
    with wave.open(str(wavs[0]),"rb") as first: params=first.getparams()
    chunks=[]; gaps=[]; cursor=0.0
    for i,wav in enumerate(wavs):
        with wave.open(str(wav),"rb") as src:
            if (src.getnchannels(),src.getsampwidth(),src.getframerate())!=(params.nchannels,params.sampwidth,params.framerate):
                raise RuntimeError("Diyalog seslerinin WAV biçimleri uyuşmuyor.")
            raw=src.readframes(src.getnframes()); clip_dur=src.getnframes()/src.getframerate()
        arr=np.frombuffer(raw,dtype=np.int16).copy().reshape(-1,params.nchannels)
        fade=min(int(params.framerate*0.012),len(arr)//2)
        if fade:
            arr[:fade]=(arr[:fade].astype(np.float32)*np.linspace(0,1,fade)[:,None]).astype(np.int16)
            arr[-fade:]=(arr[-fade:].astype(np.float32)*np.linspace(1,0,fade)[:,None]).astype(np.int16)
        chunks.append(arr.tobytes())
        timed_lines[i]["start_seconds"]=round(cursor,3); timed_lines[i]["end_seconds"]=round(cursor+clip_dur,3)
        cursor+=clip_dur
        if i<len(wavs)-1:
            gap=_line_gap(episode["lines"][i],episode["lines"][i+1]); gaps.append(b"\x00"*int(params.framerate*gap)*params.nchannels*params.sampwidth)
            timed_lines[i]["gap_after_seconds"]=round(gap,3); cursor+=gap
    voice_path=work/"voice.wav"
    with wave.open(str(voice_path),"wb") as dst:
        dst.setnchannels(params.nchannels); dst.setsampwidth(params.sampwidth); dst.setframerate(params.framerate)
        for i,chunk in enumerate(chunks):
            dst.writeframesraw(chunk)
            if i<len(chunks)-1: dst.writeframesraw(gaps[i])
    with wave.open(str(voice_path),"rb") as vf: duration=vf.getnframes()/vf.getframerate()
    episode_timed={**episode,"lines":timed_lines,"actual_voice_seconds":round(duration,2)}
    (PROJECT/"episode.json").write_text(json.dumps(episode_timed,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Diyalog birleştirildi: {duration:.1f} sn · {word_cursor} kelime · {len(timed_lines)} replik")
    return duration


def setup_project(episode):
    if PROJECT.exists(): shutil.rmtree(PROJECT)
    PROJECT.mkdir(parents=True)
    for folder in ("engine","vendor","fonts","tools"): shutil.copytree(KIT/folder,PROJECT/folder)
    for folder in ("work","stills","out"): (PROJECT/folder).mkdir(parents=True,exist_ok=True)
    frame_cache=FRAME_CACHE_ROOT/episode["id"]/"frames"; frame_cache.mkdir(parents=True,exist_ok=True)
    (PROJECT/"frames").symlink_to(frame_cache,target_is_directory=True)
    shutil.copy2(SERIES/"story.js",PROJECT/"story.js")
    finish=PROJECT/"tools"/"finish.py"; txt=finish.read_text(encoding="utf-8")
    needle='"-framerate", "30", "-i", os.path.join(proj, "frames", "f%05d.jpg"), "-i", mix,'
    if needle not in txt: raise RuntimeError("finish.py beklenen sürümde değil; 1080x1920 ölçek düzenlemesi güvenli şekilde yapılamadı.")
    txt=txt.replace(needle,needle+' "-vf", "scale=1080:1920:flags=lanczos",')
    finish.write_text(txt,encoding="utf-8")
    print(f"Kare önbelleği: {frame_cache} ({len(list(frame_cache.glob('f*.jpg')))} hazır kare)")


def build_sound_json(duration,episode):
    music=episode.get("music",{})
    start=0.0; stop=max(1.0,duration-1.0)
    obj={"voice":"work/voice.wav","music":{"style":music.get("style","mystery"),"bpm":music.get("bpm",72),"start":start,"stop":round(stop,2),"sting":False,"level_db":music.get("level_db",-24)},"sfx":[]}
    for i,line in enumerate(episode.get("lines",[])):
        kind=line.get("sfx")
        if kind:
            t=float(line.get("start_seconds",0.0))+0.03
            obj["sfx"].append({"t":round(min(max(0,t),duration-0.25),2),"kind":kind,"gain_db":float(line.get("sfx_gain_db",-2))})
    # Bölüm başında küçük geçiş, finalde dramatik vurgu; konuşmanın üstüne binmemesi için düşük seviyede.
    obj["sfx"].insert(0,{"t":0.12,"kind":"whoosh","gain_db":-4})
    obj["sfx"].append({"t":round(max(1.0,duration-1.6),2),"kind":"sting","gain_db":-3})
    (PROJECT/"sound.json").write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")


def youtube_upload(path,episode):
    from google.auth.exceptions import RefreshError
    title=f"GizemliStüdyo | KIRILMA – KAYIP ADA - {episode['number']:02d}: {episode['title']}"
    title=unicodedata.normalize("NFC",title)[:100]
    def clean_description(value,limit=4400):
        value=unicodedata.normalize("NFC",str(value or "")); chars=[]
        for ch in value:
            cat=unicodedata.category(ch); chars.append(ch if ch in "\n\r\t" or cat[0]!="C" else " ")
        value="".join(chars).replace("\r\n","\n").replace("\r","\n")
        value=re.sub(r"[ \t]+"," ",value); value=re.sub(r"\n{3,}","\n\n",value).strip()
        out=[];units=0
        for ch in value:
            cost=2 if ord(ch)>0xFFFF else 1
            if units+cost>limit:break
            out.append(ch);units+=cost
        return "".join(out).rstrip()
    desc=episode.get("youtube_description") or episode.get("description","")
    next_hook=episode.get("next_hook") or episode.get("hook","")
    description=clean_description(
        f"{title}\n\n{desc}\n\n{next_hook}\n\nKayıp Ada'nın devamı için GizemliStüdyo kanalına abone ol ve yeni bölümü kaçırma.\n\n#GizemliStüdyo #KayıpAda #Kırılma #Macera #TürkçeAnimasyon"
    )
    fallback=clean_description(f"{title}\n\n{desc}\n\n#GizemliStüdyo #KayıpAda #Macera")
    minimal=clean_description(f"{title}\n\n#GizemliStüdyo #KayıpAda")
    tags=["GizemliStüdyo","Kayıp Ada","KIRILMA","Türkçe animasyon","animasyon dizi","gizem","bilim kurgu","macera","Batu","Nur","Alperen","Kubilay","Merco","devam eden hikaye","çizgi film","Türkçe dizi"]
    body={"snippet":{"title":title,"description":description,"tags":tags,"categoryId":"1","defaultLanguage":"tr","defaultAudioLanguage":"tr"},"status":{"privacyStatus":YOUTUBE_PRIVACY,"selfDeclaredMadeForKids":False,"containsSyntheticMedia":True}}
    creds=Credentials(token=None,refresh_token=YOUTUBE_REFRESH_TOKEN,token_uri="https://oauth2.googleapis.com/token",client_id=YOUTUBE_CLIENT_ID,client_secret=YOUTUBE_CLIENT_SECRET,scopes=["https://www.googleapis.com/auth/youtube.upload"])
    try:creds.refresh(Request())
    except RefreshError as exc:raise RuntimeError("YouTube OAuth yenilenemedi: "+str(exc)[:260]) from exc
    youtube=build("youtube","v3",credentials=creds,cache_discovery=False)
    def new_request():
        media=MediaFileUpload(str(path),mimetype="video/mp4",chunksize=8*1024*1024,resumable=True)
        return youtube.videos().insert(part="snippet,status",body=body,media_body=media)
    request=new_request();result=None;retry=0;fallback_stage=0;max_retries=6
    while result is None:
        try:_,result=request.next_chunk(num_retries=3);retry=0
        except HttpError as exc:
            status=getattr(exc.resp,"status",0);raw=getattr(exc,"content",b"")
            try:
                payload=json.loads(raw.decode("utf-8","replace"));api_error=payload.get("error",{});reasons=[x.get("reason","") for x in api_error.get("errors",[])];message=api_error.get("message","")
            except Exception:reasons,message=[],str(exc)
            reason_text=" ".join(reasons);raw_text=raw.decode("utf-8","replace")
            if status==400 and "invalidDescription" in raw_text:
                fb=[fallback,minimal]
                if fallback_stage<len(fb):body["snippet"]["description"]=fb[fallback_stage];fallback_stage+=1;print(f"YouTube açıklaması reddedildi; güvenli yedek {fallback_stage}/2.");request=new_request();retry=0;continue
            transient=status in (408,429,500,502,503,504) or (status==403 and any(x in reason_text for x in ("rateLimitExceeded","userRateLimitExceeded","backendError")))
            if transient and retry<max_retries:
                retry+=1;delay=min(60,2**retry)+random.uniform(0,1.5);print(f"YouTube HTTP {status} geçici ({retry}/{max_retries}); {delay:.1f} sn bekleniyor.");time.sleep(delay);continue
            if status==403 and "quotaExceeded" in reason_text:raise RuntimeError("YouTube API günlük kotası doldu. Video hazır; kota yenilenince yeniden deneyin.") from exc
            if status in (401,403):raise RuntimeError(f"YouTube yetki hatası HTTP {status} ({reason_text or 'unknown'}): {message[:300]}") from exc
            raise RuntimeError(f"YouTube yükleme hatası HTTP {status} ({reason_text or 'unknown'}): {message[:350]}") from exc
        except (OSError,ConnectionError,TimeoutError) as exc:
            if retry>=max_retries:raise RuntimeError("YouTube ağ hatası; tekrar sınırı aşıldı: "+str(exc)[:250]) from exc
            retry+=1;delay=min(60,2**retry)+random.uniform(0,1.5);print(f"Yükleme bağlantısı kesildi ({retry}/{max_retries}); {delay:.1f} sn sonra.");time.sleep(delay)
    video_id=result.get("id") if isinstance(result,dict) else None
    if not video_id:raise RuntimeError("YouTube yanıtında video ID bulunamadı.")
    return video_id,title


def select_episode_id():
    history=load_history();episode=choose_episode(history)
    return episode["id"] if episode else "season-complete"


def main():
    require_secrets();history=load_history();slot=current_slot()
    if any(x.get("slot")==slot for x in history):print("Bu zaman aralığında yayın zaten tamamlanmış:",slot);return
    episode=choose_episode(history)
    if episode is None:return
    script_words=sum(len(line["text"].split()) for line in episode["lines"])
    if not 600 <= script_words <= 1000:
        raise RuntimeError(f"Senaryo kelime sayısı hedef dışı: {script_words} (600–1000 kelime; yaklaşık 5–8 dakika). Render başlatılmadı.")
    if episode.get("word_count") != script_words:
        print(f"UYARI: JSON word_count {episode.get('word_count')} fakat metin {script_words} kelime; gerçek sayı kullanılacak.")
    print(f"GizemliStüdyo / KIRILMA – KAYIP ADA: {episode['number']:02d} — {episode['title']} | {script_words} kelime")
    setup_project(episode)
    duration=asyncio.run(build_voice(episode))
    if not VOICE_MIN_SECONDS<=duration<=VOICE_MAX_SECONDS:
        raise RuntimeError(f"Bölüm ses süresi hedef dışı: {duration:.1f} sn (izin verilen {VOICE_MIN_SECONDS}–{VOICE_MAX_SECONDS} sn). Video yüklenmeyecek.")
    build_sound_json(duration,json.loads((PROJECT/"episode.json").read_text(encoding="utf-8")))
    print("1/5 Ses zamanlaması...");run([sys.executable,"tools/timing.py","."],cwd=PROJECT,timeout=900)
    print("2/5 Bölüme özel müzik ve ses efektleri...");run([sys.executable,"tools/audio.py","."],cwd=PROJECT,timeout=1200)
    words=json.loads((PROJECT/"work"/"words.json").read_text(encoding="utf-8"));frame_count=max(2,int(words[-1]["e"]*FPS)+20)
    preview_frames=",".join(str(int((frame_count-1)*i/11)) for i in range(12))
    print("3/5 12 karelik sahne önizlemesi...");run([sys.executable,"tools/render.py",".","stills",preview_frames,"--scale",RENDER_SCALE,"--cpu"],cwd=PROJECT,timeout=1800)
    run([sys.executable,"tools/sheet.py","stills","stills/preview_sheet.jpg"],cwd=PROJECT,timeout=300)
    print("4/5 Tam render. Önceki çalıştırmadan kalan kareler --resume ile kullanılıyor...")
    run([sys.executable,"tools/render.py",".","frames","--scale",RENDER_SCALE,"--cpu","--resume"],cwd=PROJECT,timeout=RENDER_TIMEOUT_SECONDS)
    run([sys.executable,"tools/finish.py",".",f"GizemliStüdyo_KAYIP_ADA_{episode['number']:02d}"],cwd=PROJECT,timeout=1800)
    final_src=next((PROJECT/"out").glob("GizemliStüdyo_KAYIP_ADA_*.mp4"),None)
    if not final_src or not final_src.exists():raise RuntimeError("Animasyon MP4 dosyası oluşturulamadı.")
    OUT.mkdir(exist_ok=True);slug=re.sub(r"[^A-Za-z0-9]+","_",episode["title"]).strip("_")
    final=OUT/f"GizemliStüdyo_KAYIP_ADA_{episode['number']:02d}_{slug}.mp4";shutil.copy2(final_src,final)
    probe=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_streams","-show_format","-of","json",str(final)],text=True))
    streams=probe.get("streams",[]);video=next((x for x in streams if x.get("codec_type")=="video"),{});audio=next((x for x in streams if x.get("codec_type")=="audio"),{})
    dur=float(probe.get("format",{}).get("duration",0))
    if (video.get("width"),video.get("height"))!=(1080,1920):raise RuntimeError(f"Çıktı çözünürlüğü 1080x1920 değil: {video.get('width')}x{video.get('height')}")
    if video.get("r_frame_rate")!="30/1" or video.get("codec_name")!="h264":raise RuntimeError("Video 30 FPS H.264 biçiminde değil.")
    if audio.get("codec_name")!="aac" or not VOICE_MIN_SECONDS<=dur<=VOICE_MAX_SECONDS:raise RuntimeError(f"Ses/uzunluk kontrolü başarısız: {dur:.1f}s (beklenen {VOICE_MIN_SECONDS}–{VOICE_MAX_SECONDS}s), audio={audio.get('codec_name')}")
    print(f"Teknik kalite kontrolü: {dur:.1f} sn, 1080x1920, 30 FPS H.264/AAC.")
    print("5/5 YouTube'a yükleniyor...");video_id,title=youtube_upload(final,episode)
    record={"slot":slot,"episode_id":episode["id"],"episode_number":episode["number"],"title":episode["title"],"youtube_title":title,"youtube_id":video_id,"url":f"https://www.youtube.com/watch?v={video_id}","duration_seconds":round(dur,2),"uploaded_at":datetime.now(ZoneInfo("Europe/Istanbul")).isoformat()}
    history.append(record);DATA.write_text(json.dumps(history,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");(OUT/"upload-result.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
    run(["git","config","user.name","github-actions[bot]"]);run(["git","config","user.email","41898282+github-actions[bot]@users.noreply.github.com"]);run(["git","add",str(DATA.relative_to(ROOT))]);run(["git","commit","-m",f"GizemliStüdyo KIRILMA bölüm {episode['number']:02d} yayın geçmişi"])
    push_ok=False
    for attempt in range(1,4):
        try:run(["git","push","origin","HEAD:main"],timeout=180);push_ok=True;break
        except subprocess.CalledProcessError:
            if attempt<3:
                print(f"Yayın geçmişi push başarısız; rebase/yeniden deneme {attempt}/2")
                try:run(["git","pull","--rebase","origin","main"],timeout=180)
                except subprocess.CalledProcessError:time.sleep(5*attempt)
    if not push_ok:raise RuntimeError("Video YouTube'a yüklendi, fakat yayın geçmişi GitHub'a gönderilemedi. output/upload-result.json kaydını koruyun.")
    print("BAŞARILI:",record["url"])
    # Başarılı işten sonra kare önbelleğini temizle; cache action başarısız işlerdeki kareleri saklar.
    cache_dir=FRAME_CACHE_ROOT/episode["id"]
    if cache_dir.exists():shutil.rmtree(cache_dir,ignore_errors=True)

if __name__=="__main__":main()
