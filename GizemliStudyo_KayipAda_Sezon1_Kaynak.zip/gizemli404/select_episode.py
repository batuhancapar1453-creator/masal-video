#!/usr/bin/env python3
"""GitHub Actions cache anahtarı için sıradaki bölüm kimliğini bulur; yayın yapmaz."""
import json, os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EPISODES=ROOT/"gizemli404"/"episodes"
HISTORY_FILES=(ROOT/"data"/"gizemli404_history.json",ROOT/"data"/"tuhaf_kasaba_history.json")
history=[]
for path in HISTORY_FILES:
    if path.exists():
        data=json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data,list):raise SystemExit(f"{path.name} JSON listesi olmalı")
        history.extend(data)
used={x.get("episode_id") for x in history}
selected=next((json.loads(p.read_text(encoding="utf-8")) for p in sorted(EPISODES.glob("episode_*.json")) if json.loads(p.read_text(encoding="utf-8")).get("id") not in used),None)
episode_id=selected["id"] if selected else "season-complete"
print("Cache için bölüm:",episode_id)
if os.getenv("GITHUB_OUTPUT"):
    with open(os.environ["GITHUB_OUTPUT"],"a",encoding="utf-8") as f:f.write(f"episode_id={episode_id}\n")
