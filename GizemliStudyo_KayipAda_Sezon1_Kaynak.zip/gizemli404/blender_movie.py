#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GizemliStüdyo / Kayıp Ada — gerçek Blender 3D render motoru.
Blender background içinde çalışır; episode.json içindeki replik zamanlarını
kamera kesmeleri, oyunculuk, kol hareketleri ve ağız animasyonu için kullanır.
"""
import bpy, math, json, os, sys, argparse, random
from mathutils import Vector

def args_after_dashes():
    raw = sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else []
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=".")
    ap.add_argument("--fps", type=int, default=8)
    ap.add_argument("--width", type=int, default=360)
    ap.add_argument("--height", type=int, default=640)
    return ap.parse_args(raw)

A = args_after_dashes()
PROJECT = os.path.abspath(A.project)
EP_PATH = os.path.join(PROJECT, "episode.json")
FRAMES = os.path.join(PROJECT, "frames")
os.makedirs(FRAMES, exist_ok=True)
with open(EP_PATH, encoding="utf-8") as f:
    EP = json.load(f)
LINES = EP.get("lines", [])
DURATION = float(EP.get("actual_voice_seconds") or max((x.get("end_seconds",0) for x in LINES), default=180))
FPS = A.fps
FRAME_END = max(2, int(math.ceil(DURATION * FPS)))

# Start from a clean Blender scene and clean old frame cache.
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for p in list(bpy.data.materials):
    if p.users == 0: bpy.data.materials.remove(p)
# Mevcut kareleri koru: GitHub Actions cache, yarım kalan Blender renderinden devam edebilir.

def material(name, color, rough=0.72, metallic=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get("Principled BSDF")
    if bs:
        bs.inputs["Base Color"].default_value = (*color, 1)
        bs.inputs["Roughness"].default_value = rough
        bs.inputs["Metallic"].default_value = metallic
    return m

MAT = {
    "sea": material("Derin turkuaz deniz", (0.025,0.23,0.34),0.28),
    "sand": material("Sıcak ada kumu", (0.78,0.61,0.37)),
    "grass": material("Ada yeşili", (0.18,0.37,0.20)),
    "wood": material("Eskimiş ahşap", (0.28,0.13,0.065)),
    "leaf": material("Palmiye yaprağı", (0.12,0.32,0.13)),
    "rock": material("Ada kayası", (0.25,0.30,0.31)),
    "white": material("Göz beyazı", (0.96,0.94,0.86),0.35),
    "black": material("Göz ve ağız", (0.025,0.018,0.025),0.3),
    "gold": material("Sıcak metal", (0.72,0.43,0.12),0.3,0.45),
}
SKIN = {
    "Batu":(0.78,0.55,0.39), "Nur":(0.88,0.68,0.54),
    "Alperen":(0.68,0.45,0.31), "Kubilay":(0.79,0.58,0.43),
    "Merco":(0.48,0.25,0.12)
}
CLOTH = {
    "Batu":(0.04,0.48,0.53), "Nur":(0.72,0.19,0.25),
    "Alperen":(0.25,0.38,0.23), "Kubilay":(0.31,0.24,0.53),
    "Merco":(0.55,0.30,0.12)
}
HAIR = {
    "Batu":(0.08,0.045,0.03), "Nur":(0.09,0.045,0.035),
    "Alperen":(0.24,0.22,0.20), "Kubilay":(0.035,0.03,0.04),
    "Merco":(0.34,0.16,0.07)
}

def assign(obj, mat):
    if mat: obj.data.materials.append(mat)
    return obj

def smooth(obj):
    if obj.type == "MESH":
        for poly in obj.data.polygons: poly.use_smooth = True
    return obj

def uv(name, loc, scale, mat, segments=24, rings=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale; assign(o,mat); smooth(o)
    return o

def cube(name, loc, scale, mat, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o=bpy.context.object; o.name=name; o.dimensions=scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    assign(o,mat)
    if bevel:
        mod=o.modifiers.new("Yumuşak kenarlar","BEVEL"); mod.width=bevel; mod.segments=3
        o.modifiers.new("Köşe normalleri","WEIGHTED_NORMAL")
    return o

def cylinder(name, loc, radius, depth, mat, vertices=16):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    o=bpy.context.object; o.name=name; assign(o,mat); smooth(o); return o

def parent_keep(obj, parent):
    mw=obj.matrix_world.copy()
    obj.parent=parent
    obj.matrix_world=mw

def key(obj, data_path, frame, index=None):
    if index is None: obj.keyframe_insert(data_path=data_path, frame=frame)
    else: obj.keyframe_insert(data_path=data_path, index=index, frame=frame)

# Ocean and island set: fully modelled 3D meshes, not a background image.
cube("Okyanus tabanı",(0,0,-1.35),(200,200,0.5),MAT["sea"])
island=uv("Ada kıyı kütlesi",(0,0,-0.82),(23,17,1.15),MAT["sand"],48,24)
grass=uv("Ada iç çimenliği",(0,3,-0.18),(17,11,0.75),MAT["grass"],40,20)
for i in range(18):
    random.seed(900+i)
    x=random.uniform(-18,18); y=random.uniform(-11,14)
    if abs(x)<5 and -3<y<5: continue
    r=random.uniform(.5,1.3)
    uv("Kıyı kayası",(x,y,-.15),(r,r*.8,r*.65),MAT["rock"],16,10)
# Palm trees with curved-looking angled fronds.
for idx,(x,y,h) in enumerate([(-12,7,5),(-9,10,4.4),(12,8,5.4),(15,3,4.6),(-15,-2,4.2)]):
    cylinder("Palmiye gövdesi",(x,y,h/2),.22,h,MAT["wood"],12)
    for j in range(7):
        a=2*math.pi*j/7
        leaf=uv("Palmiye yaprağı",(x+math.cos(a)*1.35,y+math.sin(a)*1.35,h+.15),(1.65,.22,.12),MAT["leaf"],16,8)
        leaf.rotation_euler[2]=a
        leaf.rotation_euler[1]=-.22
# A small weathered boat near the shore.
hull=cube("Kayıp tekne gövdesi",(5,-8,.25),(5.8,1.35,.7),MAT["wood"],.22)
hull.rotation_euler[2]=-.18
cube("Tekne oturma tahtası",(5,-8, .72),(4.4,.22,.15),MAT["gold"],.04)
# A few distant clouds.
cloudmat=material("Bulut kremi",(0.92,0.94,0.92))
for i,(x,y,z) in enumerate([(-16,22,14),(3,26,16),(17,20,13)]):
    for j in range(3):
        uv("Yumuşak bulut",(x+j*1.1,y,z+(j%2)*.35),(1.5,.75,.65),cloudmat,16,10)

# Character construction. Distinct 3D body, head, hair, eyes, mouth, limbs.
ACTORS={}
POSITIONS={"Batu":-3.25,"Nur":-1.65,"Alperen":0.0,"Kubilay":1.65,"Merco":3.25}
def make_actor(name):
    before=set(bpy.data.objects)
    x=POSITIONS.get(name,0)
    skin=material(name+" ten",SKIN.get(name,(.7,.5,.4)))
    cloth=material(name+" kıyafet",CLOTH.get(name,(.3,.4,.5)))
    hair=material(name+" saç/tüy",HAIR.get(name,(.1,.1,.1)))
    shoe=material(name+" ayakkabı",(0.10,0.10,0.13))
    root=bpy.data.objects.new(name+" ROOT",None); bpy.context.collection.objects.link(root); root.location=(x,0,0)
    torso=uv(name+" gövde",(x,0,1.75),(.63,.42,.92),cloth)
    head=uv(name+" kafa",(x,-.02,3.05),(.72,.62,.78),skin)
    # Neck and hair cap.
    cylinder(name+" boyun",(x,0,2.43),.23,.42,skin)
    if name=="Merco":
        uv(name+" kulak sol",(x-.62,-.02,3.42),(.25,.22,.55),hair)
        uv(name+" kulak sağ",(x+.62,-.02,3.42),(.25,.22,.55),hair)
        uv(name+" burun",(x,-.59,2.91),(.22,.13,.17),material(name+" burun",(0.16,.07,.035)))
    else:
        cap=uv(name+" saç",(x,.02,3.55),(.76,.64,.38),hair)
        if name=="Nur":
            uv(name+" saç tutamı",(x-.62,.0,3.08),(.19,.25,.72),hair)
            uv(name+" saç tutamı",(x+.62,.0,3.08),(.19,.25,.72),hair)
    # Eyes are placed on the front (-Y) of the head.
    for ex in (-.25,.25):
        uv(name+" göz akı",(x+ex,-.565,3.16),(.145,.085,.18),MAT["white"],20,12)
        uv(name+" göz bebeği",(x+ex,-.642,3.15),(.073,.045,.105),MAT["black"],16,10)
        uv(name+" kaş",(x+ex,-.58,3.40),(.18,.055,.055),hair,16,8)
    mouth=uv(name+" ağız",(x,-.635,2.82),(.17,.055,.035),MAT["black"],16,10)
    # Nose and clothing details.
    uv(name+" burun",(x,-.61,2.96),(.09,.08,.075),skin,16,10)
    if name=="Alperen" or name=="Kubilay":
        for ex in (-.25,.25):
            bpy.ops.mesh.primitive_torus_add(major_radius=.17,minor_radius=.025,major_segments=20,minor_segments=8,location=(x+ex,-.66,3.16),rotation=(math.pi/2,0,0))
            assign(bpy.context.object, MAT["gold"])
    # Arm pivots and rounded sleeves.
    arms=[]
    for side in (-1,1):
        pivot=bpy.data.objects.new(name+(" sol kol pivot" if side<0 else " sağ kol pivot"),None)
        bpy.context.collection.objects.link(pivot); pivot.location=(x+side*.58,0,2.28)
        arm=uv(name+" kol",(x+side*.92,-.01,1.86),(.25,.28,.62),cloth)
        parent_keep(arm,pivot); arms.append(pivot)
        hand=uv(name+" el",(x+side*1.02,-.07,1.48),(.22,.20,.22),skin)
        parent_keep(hand,pivot)
    legs=[]
    for side in (-1,1):
        leg=uv(name+" bacak",(x+side*.25,0,.62),(.25,.31,.72),cloth)
        foot=uv(name+" ayak",(x+side*.25,-.20,.16),(.32,.48,.18),shoe)
        legs.append((leg,foot))
    # Small fixed identity accessory.
    if name=="Batu": cube("Batu ceket fermuarı",(x,-.43,1.95),(.055,.035,.72),MAT["gold"],.02)
    if name=="Nur": uv("Nur kolye",(x,-.49,2.22),(.10,.06,.13),MAT["gold"],16,8)
    ACTORS[name]={"root":root,"head":head,"torso":torso,"mouth":mouth,"arms":arms,"legs":legs,"skin":skin,"objects":list(set(bpy.data.objects)-before),"base_x":x}
for n in ("Batu","Nur","Alperen","Kubilay","Merco"): make_actor(n)

# Lighting, world and camera.
world=bpy.context.scene.world
world.color=(.20,.24,.32)
world.use_nodes=True
world.node_tree.nodes["Background"].inputs[0].default_value=(.23,.39,.55,1)
world.node_tree.nodes["Background"].inputs[1].default_value=.45
def area(name,loc,power,color,size,target):
    bpy.ops.object.light_add(type="AREA",location=loc)
    o=bpy.context.object; o.name=name; o.data.energy=power; o.data.color=color; o.data.shape="DISK"; o.data.size=size
    o.rotation_euler=(Vector(target)-o.location).to_track_quat("-Z","Y").to_euler()
area("Güneş ana ışık",(-8,-10,15),1700,(1.0,.78,.57),9,(0,0,1))
area("Gökyüzü dolgu",(8,-4,10),1100,(.55,.75,1.0),10,(0,0,2))
area("Arka kenar ışığı",(0,10,12),1800,(1.0,.55,.30),8,(0,0,2))
bpy.ops.object.camera_add(location=(0,-18,5.8))
CAM=bpy.context.object; CAM.name="Sinematik Kamera"
target=bpy.data.objects.new("Kamera hedefi",None); bpy.context.collection.objects.link(target)
con=CAM.constraints.new(type="TRACK_TO"); con.target=target; con.track_axis="TRACK_NEGATIVE_Z"; con.up_axis="UP_Y"
scene=bpy.context.scene; scene.camera=CAM
# Render configuration.
scene.render.resolution_x=A.width; scene.render.resolution_y=A.height; scene.render.resolution_percentage=100
scene.render.fps=FPS; scene.frame_start=1; scene.frame_end=FRAME_END
scene.render.image_settings.file_format="JPEG"; scene.render.image_settings.quality=88
scene.render.filepath=os.path.join(FRAMES,"render_tmp")
scene.render.use_file_extension=True
scene.render.film_transparent=False
scene.render.image_settings.color_mode="RGB"
scene.render.resolution_percentage=100
scene.view_settings.view_transform="Standard"
scene.view_settings.look="Medium High Contrast"
scene.view_settings.exposure=0
scene.view_settings.gamma=1
scene.render.image_settings.color_depth="8"
# Blender 3.x compatibility.
try:
    scene.render.engine="BLENDER_EEVEE_NEXT"
except Exception:
    scene.render.engine="BLENDER_EEVEE"
# GitHub CPU runner optimizations: fewer temporal samples and reuse render data.
try:
    scene.eevee.taa_render_samples = 4
except Exception:
    pass
try:
    scene.render.use_persistent_data = True
except Exception:
    pass
try:
    scene.render.threads_mode = "AUTO"
except Exception:
    pass
# GitHub CPU runner: keep the stylized scene lightweight while preserving real 3D geometry.
try:
    scene.eevee.use_gtao = True
    scene.eevee.gtao_distance = 2.0
    scene.eevee.gtao_factor = 1.0
except Exception:
    pass
try:
    scene.render.use_simplify = True
    scene.render.simplify_subdivision = 0
    scene.render.simplify_child_particles = 0.5
except Exception:
    pass
scene.camera.data.lens=48

def frame_at(t): return max(1,min(FRAME_END,int(round(t*FPS))+1))
# Story-driven acting: characters enter/leave frame according to each line's visible list.
# The scene is staged as a sequence of real shots, not a permanent group portrait.
intervals={n:[] for n in ACTORS}
for li,line in enumerate(LINES):
    st=float(line.get("start_seconds",li*2.5)); en=float(line.get("end_seconds",st+2.0))
    visible=line.get("visible") or [line.get("speaker","Batu")]
    for n in visible:
        if n in intervals: intervals[n].append((st,en))

for name,data in ACTORS.items():
    objs=data["objects"]
    # Hidden until the story explicitly brings the character into the shot.
    for obj in objs:
        obj.hide_render=True; obj.keyframe_insert(data_path="hide_render",frame=1)
        for st,en in intervals[name]:
            obj.hide_render=False; obj.keyframe_insert(data_path="hide_render",frame=frame_at(st))
            obj.hide_render=True; obj.keyframe_insert(data_path="hide_render",frame=min(FRAME_END,frame_at(en)+1))
    # Subtle breathing and attentive head movement throughout their appearances.
    torso=data["torso"]
    for st,en in intervals[name]:
        f0=frame_at(st); fm=max(f0+1,(f0+frame_at(en))//2); f1=max(fm+1,frame_at(en))
        torso.location.z=1.75; torso.keyframe_insert("location",frame=f0)
        torso.location.z=1.79; torso.keyframe_insert("location",frame=fm)
        torso.location.z=1.75; torso.keyframe_insert("location",frame=f1)

# Physical environment motion: wind-swept palms, moving boat and rolling ocean surface.
# An animated Ocean modifier gives the water actual changing geometry.
bpy.ops.mesh.primitive_plane_add(size=200, location=(0,0,-.02))
water=bpy.context.object; water.name="Canlı dalgalı deniz"; assign(water,MAT["sea"])
try:
    ocean=water.modifiers.new("Gerçek dalga hareketi","OCEAN")
    ocean.resolution=7; ocean.wave_scale=1.15; ocean.choppiness=1.15
    ocean.keyframe_insert(data_path="time",frame=1)
    ocean.time=8.0; ocean.keyframe_insert(data_path="time",frame=FRAME_END)
except Exception as exc: print("Ocean modifier uyarısı:",exc,flush=True)
# Boat is animated independently so passengers can feel its rocking.
for f,ang,z in [(1,0,.22),(max(2,FRAME_END//4),.035,.38),(max(3,FRAME_END//2),-.045,.12),(max(4,3*FRAME_END//4),.04,.34),(FRAME_END,0,.22)]:
    hull.rotation_euler[1]=ang; hull.keyframe_insert("rotation_euler",index=1,frame=f)
    hull.location.z=z; hull.keyframe_insert("location",index=2,frame=f)
# Palm fronds sway in the wind; cloud drift adds depth to the island atmosphere.
for obj in list(bpy.data.objects):
    if "Palmiye yaprağı" in obj.name:
        base=obj.rotation_euler[1]
        for f,delta in [(1,-.10),(max(2,FRAME_END//3),.12),(max(3,2*FRAME_END//3),-.08),(FRAME_END,.10)]:
            obj.rotation_euler[1]=base+delta; obj.keyframe_insert("rotation_euler",index=1,frame=f)

# Rehearse every line as an action, not just a talking pose.
for li,line in enumerate(LINES):
    name=line.get("speaker","Batu")
    if name not in ACTORS: name="Batu"
    start=float(line.get("start_seconds",li*2.5)); end=float(line.get("end_seconds",start+2.0))
    f0=frame_at(start); f1=max(f0+2,frame_at(end)); fm=(f0+f1)//2
    actor=ACTORS[name]; action=str(line.get("action","talk")).lower()
    words_text=line.get("text","").lower()
    if any(k in words_text for k in ("barınak kur","kampı kur","siper kur","çatı kur","inşa et","yerleştir")): action="build"
    elif any(k in words_text for k in ("odun topla","dal topla","dalları topla","malzeme topla")): action="collect"
    elif any(k in words_text for k in ("taşıyacağım","taşıdım","taşıyoruz","taşıyıp","yükü taşı")): action="carry"
    elif any(k in words_text for k in ("kazmaya","kazıyorum","toprağı kaz")): action="dig"
    # Head, torso and hands communicate emotion and intention.
    actor["head"].rotation_euler[1]=-.08 if action in ("inspect","listen","reaction") else .05
    actor["head"].keyframe_insert("rotation_euler",index=1,frame=f0)
    actor["head"].rotation_euler[1]=.08 if action in ("point","reveal","talk") else -.03
    actor["head"].keyframe_insert("rotation_euler",index=1,frame=fm)
    actor["head"].rotation_euler[1]=0; actor["head"].keyframe_insert("rotation_euler",index=1,frame=f1)
    for side,piv in zip((-1,1),actor["arms"]):
        piv.rotation_euler[1]=side*.08; piv.keyframe_insert("rotation_euler",index=1,frame=f0)
        swing={"talk":-.28,"point":-.82,"inspect":-.48,"listen":-.12,"walk":-.32,"carry":-.72,"build":-.88,"react":-.65,"reaction":-.65,"reveal":-.8}.get(action,-.25)
        piv.rotation_euler[1]=side*swing; piv.keyframe_insert("rotation_euler",index=1,frame=fm)
        piv.rotation_euler[1]=side*.08; piv.keyframe_insert("rotation_euler",index=1,frame=f1)
    # Walking/carrying/building visibly changes the character's position and posture.
    if action in ("walk","carry","build","collect","run","dig"):
        direction=1 if li%2==0 else -1
        step=1.35 if action!="run" else 2.0
        for obj in actor["objects"]:
            x0=obj.location.x; y0=obj.location.y
            obj.location.x=x0; obj.keyframe_insert("location",index=0,frame=f0)
            obj.location.x=x0+direction*step; obj.keyframe_insert("location",index=0,frame=f1)
        for leg,foot in actor["legs"]:
            leg.rotation_euler[1]=-.32; leg.keyframe_insert("rotation_euler",index=1,frame=f0)
            leg.rotation_euler[1]=.32; leg.keyframe_insert("rotation_euler",index=1,frame=fm)
            leg.rotation_euler[1]=-.12; leg.keyframe_insert("rotation_euler",index=1,frame=f1)
    # Lip movement follows the actual recorded line duration.
    mouth=actor["mouth"]; mouth.scale=(.17,.055,.018); mouth.keyframe_insert("scale",frame=f0)
    words=max(1,len(line.get("text","").split()))
    for k in range(words):
        t=start+(end-start)*(k+.35)/words; ff=frame_at(t)
        mouth.scale=(.17,.055,.12 if k%3 else .075); mouth.keyframe_insert("scale",frame=ff)
        mouth.scale=(.17,.055,.018); mouth.keyframe_insert("scale",frame=min(FRAME_END,ff+max(1,int(FPS*.075))))
    mouth.scale=(.17,.055,.018); mouth.keyframe_insert("scale",frame=f1)
    # Camera follows the visible cast for this beat; it never insists on showing everyone.
    vis=[v for v in (line.get("visible") or [name]) if v in POSITIONS]
    if not vis: vis=[name]
    center=sum(POSITIONS[v] for v in vis)/len(vis)
    shot=line.get("shot","medium"); wide=shot in ("wide","tracking")
    insert=shot in ("insert","over","close")
    cam_x=center; cam_y=-22 if wide else (-14.5 if insert else -17.5)
    cam_z=6.4 if wide else (4.8 if insert else 5.5)
    target.location=(center,0,2.25 if not insert else 2.75); target.keyframe_insert("location",frame=f0)
    CAM.location=(cam_x,cam_y,cam_z); CAM.keyframe_insert("location",frame=f0)
    CAM.data.lens=36 if wide else (58 if insert else 48); CAM.data.keyframe_insert("lens",frame=f0)
    CAM.location=(cam_x,cam_y+.45,cam_z-.05); CAM.keyframe_insert("location",frame=f1)

# Story props: narrated tasks become visible, persistent set pieces.
# Logs are gathered and carried; shelter components appear progressively as construction happens.
prop_mat=MAT["wood"]
for li,line in enumerate(LINES):
    txt=(line.get("text","")+" "+str(line.get("action",""))).lower()
    st=float(line.get("start_seconds",li*2.5)); en=float(line.get("end_seconds",st+2.0))
    f0=frame_at(st); f1=max(f0+2,frame_at(en)); speaker=line.get("speaker","Batu")
    if speaker not in ACTORS: speaker="Batu"
    sx=POSITIONS[speaker]
    if any(k in txt for k in ("odun","dal","kütük","yakacak","dallar")):
        log=cylinder("Hikâye odunu %02d"%li,(sx+1.6,1.2,.28),.16,1.5,prop_mat,12)
        log.rotation_euler[1]=math.pi/2
        log.hide_render=True; log.keyframe_insert("hide_render",frame=1)
        log.hide_render=False; log.keyframe_insert("hide_render",frame=f0)
        log.location=(sx+1.6,1.2,.28); log.keyframe_insert("location",frame=f0)
        log.location=(sx+.45,.15,.28); log.keyframe_insert("location",frame=f1)
    if any(k in txt for k in ("barınak","kulübe","çatı","direkleri","duvarı","siper","kampı kur")):
        # Construction is cumulative: each narrated building beat adds a real 3D piece.
        piece=li%4
        if piece<2:
            beam=cube("Barınak taşıyıcı %02d"%li,(2.8+piece*.9,2.0,1.0),( .16,.16,2.0),prop_mat,.04)
        else:
            beam=cube("Barınak çatı %02d"%li,(3.25,2.0,2.0), (2.1,.18,.16),prop_mat,.04)
            beam.rotation_euler[1]=-.18 if piece==2 else .18
        beam.hide_render=True; beam.keyframe_insert("hide_render",frame=1)
        beam.hide_render=False; beam.keyframe_insert("hide_render",frame=f0)
    if any(k in txt for k in ("ateş yak","kamp ateşi","ateşi yakt","ateşi küçük tut","ateşin")):
        flame=uv("Canlı kamp ateşi %02d"%li,(3.0,1.0,.45),(.25,.25,.48),material("Alev %02d"%li,(1.0,.25,.025),.35),16,10)
        flame.hide_render=True; flame.keyframe_insert("hide_render",frame=1)
        flame.hide_render=False; flame.keyframe_insert("hide_render",frame=f0)
        for ff,sz in ((f0,.8),(min(FRAME_END,f0+max(1,FPS//3)),1.15),(f1,.9)):
            flame.scale=(sz,sz,sz); flame.keyframe_insert("scale",frame=ff)

# Smooth interpolation for film-like movement.
# Blender 4.4+/5.0 uses layered Actions; legacy Action.fcurves may not exist.
def iter_action_fcurves(action):
    """Yield F-curves from both legacy and layered Blender Actions."""
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        for fc in legacy:
            yield fc
        return

    seen = set()
    layers = getattr(action, "layers", None)
    slots = list(getattr(action, "slots", []))
    if layers is None:
        return
    for layer in layers:
        for strip in getattr(layer, "strips", []):
            channelbags = getattr(strip, "channelbags", None)
            if channelbags is not None:
                for bag in channelbags:
                    for fc in getattr(bag, "fcurves", []):
                        if fc.as_pointer() not in seen:
                            seen.add(fc.as_pointer())
                            yield fc
            # Blender's layered API exposes channelbag(slot) on keyframe strips.
            getter = getattr(strip, "channelbag", None)
            if callable(getter):
                for slot in slots:
                    try:
                        bag = getter(slot)
                    except (TypeError, RuntimeError, ReferenceError):
                        bag = None
                    if bag is None:
                        continue
                    for fc in getattr(bag, "fcurves", []):
                        ptr = fc.as_pointer()
                        if ptr not in seen:
                            seen.add(ptr)
                            yield fc

for obj in list(bpy.data.objects):
    anim = getattr(obj, "animation_data", None)
    action = getattr(anim, "action", None) if anim else None
    if action is not None:
        for fc in iter_action_fcurves(action):
            for kp in fc.keyframe_points:
                kp.interpolation = "BEZIER"

# Set output and render actual 3D animation frames.
scene.frame_set(1)
print("BLENDER 3D:", EP.get("title"), "|", round(DURATION,1), "sn |", FRAME_END, "kare |", A.width, "x", A.height, flush=True)
os.makedirs(os.path.join(PROJECT,"out"), exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(PROJECT,"out","episode_scene.blend"))
# Kareleri tek Blender sürecinde üret; tamamlanan kareler checkpoint olarak korunur.
tmp_image=os.path.join(FRAMES,"render_tmp.jpg")
rendered=0; reused=0
for frame in range(1,FRAME_END+1):
    dst=os.path.join(FRAMES,f"f{frame-1:05d}.jpg")
    if os.path.exists(dst) and os.path.getsize(dst)>1000:
        reused+=1
        continue
    scene.frame_set(frame)
    if os.path.exists(tmp_image): os.remove(tmp_image)
    bpy.ops.render.render(write_still=True)
    if not os.path.exists(tmp_image):
        raise RuntimeError("Blender kare dosyası oluşturmadı: "+tmp_image)
    os.replace(tmp_image,dst)
    rendered+=1
    if rendered % 30 == 0 or frame == FRAME_END:
        print(f"Blender render: {frame}/{FRAME_END} kare | yeni={rendered} | önbellekten={reused}",flush=True)
print("BLENDER 3D RENDER TAMAMLANDI:",FRAME_END,"kare | yeni",rendered,"| önbellekten",reused,flush=True)
