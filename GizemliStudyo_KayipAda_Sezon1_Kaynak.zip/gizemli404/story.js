// GizemliStüdyo — KIRILMA / Kayıp Ada sezon 1
// Doodle karakterler + derin 3D çevre + hareket odaklı sinematik sahneleme.
const epResponse = await fetch(new URL("./episode.json", import.meta.url));
if (!epResponse.ok) throw new Error("episode.json yüklenemedi");
const EP = await epResponse.json();
export const meta = { fps: 30, tail: 0.65 };

const clamp = (v, a=0, b=1) => Math.max(a, Math.min(b, v));
const mix = (a, b, t) => a + (b - a) * t;
const smooth = (t) => { t = clamp(t, 0, 1); return t*t*(3-2*t); };
const IDs = { Batu:"batu", Nur:"nur", Alperen:"alperen", Kubilay:"kubilay", Merco:"merco" };
const SEEDS = { Batu:11, Nur:17, Alperen:23, Kubilay:31, Merco:41 };
const SPECS = {
  Batu:{skin:"#f4d7bc",shirt:"#48b8c3",jacket:"#287f91",pants:"#263c59",shoes:"#e9a44b",hair:"spiky",hairCol:"#30231f",seed:11,build:"adult"},
  Nur:{skin:"#f7e4d0",shirt:"#e87570",jacket:"#c94f5a",pants:"#65558d",shoes:"#f1c75d",hair:"long",hairCol:"#35231f",seed:17,build:"adult"},
  Alperen:{skin:"#e9c9aa",shirt:"#78986f",jacket:"#4f7557",pants:"#454d5a",shoes:"#40352e",hair:"part",hairCol:"#77736c",glasses:true,seed:23,build:"stout"},
  Kubilay:{skin:"#f2d6bc",shirt:"#8b79bd",jacket:"#61518d",pants:"#39475f",shoes:"#e0b75d",hair:"short",hairCol:"#27252a",hat:"cap",hatCol:"#4f6fb0",hatBand:"#e7c25a",glasses:true,seed:31,build:"adult"},
  Merco:{animal:"dog",fur:"#c98a55",furDark:"#8b5737",muzzle:"#f3dfc7",collar:"#b94350",seed:41,build:"kid"}
};
let R = {};
const actorsByName = {};

function makeTown(E,S,T){
  E.ground(T.cobble("#9b9a91"),170,0.22); S.street({len:120,width:14,z:-4});
  S.row(-48,48,-15,{seed:8}); S.row(-48,48,15,{seed:22,rot:Math.PI});
  S.hills({z:-85,col:"#617c7a"}); S.clouds({n:7,y:28,z:-95,seed:6});
  for(const x of [-18,-10,10,18]){S.tree(x,-2,{type:x%2?"round":"pine",s:1.2});S.lamp(x+1,-2,{on:true});}
  S.building(-26,-20,{w:14,d:11,floors:2,wall:"#d8c2a0",roof:"#7d5263",cols:3});
  S.building(26,-20,{w:14,d:11,floors:2,wall:"#9fc5d0",roof:"#5a6c8c",cols:3});
  S.building(-26,20,{w:14,d:11,floors:2,wall:"#d0b1ce",roof:"#6c5279",cols:3});
  S.building(26,20,{w:14,d:11,floors:2,wall:"#e6d39b",roof:"#62865d",cols:3});
  S.bench(-5,3,Math.PI/2); S.bench(5,3,-Math.PI/2);
}
function buildStation(E,S,T){
  E.ground(T.cobble("#727a83"),120,0.18); S.hills({z:-100,col:"#45586e"}); S.clouds({n:5,y:26,z:-80});
  E.box(42,0.45,7,E.mat("#8b8d92"),[0,0,-3]); E.box(42,0.25,1.1,E.mat("#3c434b"),[0,0.28,-8]);
  for(let x=-19;x<=19;x+=2.4){E.box(0.5,0.12,2.5,E.mat("#6a5144"),[x,0.4,-8]);}
  E.box(0.18,0.18,44,E.mat("#53575c"),[-1.2,0.5,-8],{rot:[0,0,0]}); E.box(0.18,0.18,44,E.mat("#53575c"),[1.2,0.5,-8]);
  E.box(30,0.45,4.5,E.mat("#667786"),[0,0.45,-13]); E.box(28,0.2,1.2,E.mat("#526575"),[0,4.3,-13]);
  for(let x=-12;x<=12;x+=6){E.box(0.35,4.2,0.35,E.mat("#566979"),[x,2.1,-13]); E.box(0.45,0.45,0.45,E.mat("#e4c36c"),[x,4.5,-13]);}
  S.bench(-5,-5,0); S.bench(5,-5,0); S.lamp(-10,-4,{on:true});S.lamp(10,-4,{on:true});
  E.label(T.sign("İSTASYON",{bg:"#243b50",fg:"#f5e7c7",border:"#d7b15a",size:130}),5,0.9,[0,5,-12.2]);
  E.box(5.2,4.6,0.3,E.mat("#26384b"),[0,2.3,-5.8]); E.box(4.3,3.8,0.18,E.mat("#547b91"),[0,2.1,-5.58]); E.box(0.18,3.6,0.12,E.mat("#6dd6e7",{emissive:"#35a6c5",glow:1.1}),[-2.1,2.1,-5.45]); E.box(0.18,3.6,0.12,E.mat("#6dd6e7",{emissive:"#35a6c5",glow:1.1}),[2.1,2.1,-5.45]);
  R.clock=E.group(null,[0,5.4,-17]); E.cyl(1.2,1.2,0.24,E.mat("#d7d1c4"),[0,0,0],{parent:R.clock,rot:[Math.PI/2,0,0]});
  R.clockHand=E.box(0.09,1.0,0.12,E.mat("#333b46"),[0,0.38,0.22],{parent:R.clock});
}
function buildHouse(E,S,T){
  S.room({w:13,d:10,h:4,wall:T.wallpaper("#b9b6ae","#9d9b91"),floor:T.planks("#765d49"),window:true,door:true,night:true});
  // Oyunculuk koridoru merkezde boş bırakılır; masa ve sandalye duvar kenarına alınır.
  S.table(3.65,-2.55,{w:2.25,d:1.05,col:"#624833"}); S.chair(-3.75,-2.45,{col:"#6c5440"});
  S.hangLamp(0,3.15,0,{col:"#d8b879",i:2.2});
  E.box(12.4,0.12,0.12,E.mat("#594536"),[0,0.16,-4.88]);
  E.box(0.12,3.6,0.12,E.mat("#594536"),[-6.35,1.8,-4.8]);
  E.box(0.12,3.6,0.12,E.mat("#594536"),[6.35,1.8,-4.8]);
  // Duvarın altındaki gölge ve pencere ışığı mekâna gerçek hacim verir.
  E.box(12.2,0.08,0.12,E.mat("#b7a38a"),[0,0.28,-4.82]);
  E.box(2.4,0.12,0.12,E.mat("#7b6654"),[0,2.6,-4.8]);
  R.photo=E.group(null,[0,0,0]); E.box(1.4,1.5,0.1,E.mat("#a88454"),[1.5,1.3,-1.0],{parent:R.photo});
  E.plane(1.1,1.2,E.flat("#ffffff",{map:T.painting("portrait")}),[1.5,1.3,-0.93],{parent:R.photo});
}
function buildArchive(E,S,T){
  S.room({w:16,d:13,h:5,wall:T.wallpaper("#6c6672","#5c5365"),floor:T.planks("#4a3e3c"),window:false,door:true});
  for(const x of [-6,-3,3,6])S.shelf(x,-5,{seed:Math.abs(x)+5});
  S.table(0,-1,{w:3.6,d:1.5,col:"#6b4a31"}); S.hangLamp(0,4.5,0,{col:"#e0b65f",i:5});
  R.recorder=E.group(null,[0,0,0]); E.box(1.6,0.55,0.9,E.mat("#3a424a"),[0,1.2,-1],{parent:R.recorder}); E.box(0.7,0.12,0.15,E.mat("#c6b46b"),[0,1.5,-0.52],{parent:R.recorder});
}
function buildTunnel(E,S,T){
  E.ground(T.stone("#5d6167"),100,0.25); E.box(28,0.3,38,E.mat("#4b5057"),[0,0,-8]);
  for(let z=2;z>=-28;z-=5){E.box(0.6,5,0.6,E.mat("#667079"),[-5,2.5,z]);E.box(0.6,5,0.6,E.mat("#667079"),[5,2.5,z]);E.box(11,0.6,0.6,E.mat("#667079"),[0,4.7,z]);}
  for(let z=0;z>=-30;z-=6){E.box(0.3,0.2,11,E.mat("#7b654e"),[0,0.1,z]);E.box(0.15,0.15,38,E.mat("#87949d"),[-1,0.4,-8]);E.box(0.15,0.15,38,E.mat("#87949d"),[1,0.4,-8]);}
  for(let z=-3;z>=-28;z-=7)S.hangLamp(0,4.7,z,{col:"#79c9dc",i:3});
  R.tunnelDoor=E.group(null,[0,0,0]); E.box(5,4.4,0.25,E.mat("#263b4e"),[0,2.2,-9],{parent:R.tunnelDoor}); E.box(4.3,3.8,0.18,E.mat("#50758a"),[0,2.1,-8.82],{parent:R.tunnelDoor});
}
function buildUnderground(E,S,T){
  E.ground(T.stone("#414c5b"),120,0.22); E.box(70,0.5,70,E.mat("#293442"),[0,-0.25,0]);
  for(let x=-18;x<=18;x+=6){E.box(1,14,1,E.mat("#596b7d"),[x,7,-15]);E.box(1,14,1,E.mat("#596b7d"),[x,7,15]);}
  E.box(70,1,2,E.mat("#25394c"),[0,14,0]);
  for(let z=-15;z<=15;z+=7){E.box(40,0.25,0.5,E.mat("#556779"),[0,0.2,z]);}
  for(const x of [-9,9]){E.box(3.6,5,2.2,E.mat("#3b5368"),[x,2.5,-8]);E.box(2.6,2.4,0.15,E.mat("#5ec4d6"),[x,3,-6.8]);S.hangLamp(x,6,-8,{col:"#69d9ec",i:4});}
  R.core=E.group(null,[0,0,0]); E.cyl(1.2,1.2,4.5,E.mat("#4e91c4"),[0,2.4,-7],{parent:R.core}); E.cyl(0.6,0.6,4.8,E.mat("#e8b94f"),[0,2.4,-7],{parent:R.core}); E.sphere(0.7,E.mat("#65d7ec"),[0,4.8,-7],{parent:R.core});
}
function buildControl(E,S,T){
  S.room({w:15,d:12,h:4.8,wall:T.wallpaper("#33404e","#263542"),floor:T.planks("#4c4141"),window:false,door:false});
  S.desk(0,-1.5,{col:"#3b4c5b"});
  for(let x=-4;x<=4;x+=2){E.box(1.5,1.2,0.15,E.mat("#253442"),[x,2.4,-5.4]);E.box(1.25,0.85,0.08,E.mat(x%4?"#5cb8ca":"#e1b15c",{emissive:x%4?"#15586a":"#5a3b0b",glow:0.9}),[x,2.45,-5.28]);}
  R.console=E.group(null,[0,0,0]); E.box(4,0.6,1.1,E.mat("#344957"),[0,0.7,-3],{parent:R.console}); E.box(3,0.2,0.3,E.mat("#65c5d6"),[0,1.1,-2.5],{parent:R.console});
}
function buildTower(E,S,T){
  E.ground(T.cobble("#777c82"),100,0.2); S.hills({z:-80,col:"#526b77"}); S.clouds({n:4,y:27,z:-90});
  E.box(8,18,7,E.mat("#8d837a"),[0,0,-8]); E.cone(5.5,6,E.mat("#394a60"),[0,18,-8]);
  E.box(10,0.6,8,E.mat("#6a625a"),[0,18,-8]); E.box(4,2.8,0.3,E.mat("#5b5149"),[0,9,-4.3]);
  E.box(1,12,1,E.mat("#5d5d60"),[-6,6,0]); E.box(1,12,1,E.mat("#5d5d60"),[6,6,0]); E.box(13,0.5,1,E.mat("#6e6e72"),[0,12,0]);
  R.panel=E.group(null,[0,0,0]); E.box(2.2,2.8,0.3,E.mat("#354b5a"),[0,2,-3],{parent:R.panel}); E.box(1.5,0.3,0.1,E.mat("#e3bd63"),[0,2.7,-2.8],{parent:R.panel});
}
function buildSeam(E,S,T){
  E.ground(T.stone("#353d50"),120,0.25); E.box(60,0.5,60,E.mat("#222c3f"),[0,-0.25,0]);
  for(let i=0;i<16;i++){const x=-18+(i%4)*12,z=-20+Math.floor(i/4)*12;E.box(3,0.35,3,E.mat(i%3?"#4b5c72":"#6a547d"),[x,0.2,z],{rot:[0,(i%4)*0.25,0]});}
  R.portal=E.group(null,[0,0,0]); E.cyl(3.5,3.5,0.45,E.mat("#516e8b"),[0,0,-7],{parent:R.portal,rot:[Math.PI/2,0,0]}); E.cyl(2.7,2.7,0.5,E.mat("#65c9dc"),[0,0,-6.7],{parent:R.portal,rot:[Math.PI/2,0,0]});
  E.sphere(2.3,E.mat("#3d6f95",{emissive:"#2c9ec4",glow:1.3}),[0,2,-7],{parent:R.portal,scale:[0.15,1.2,1.2]});
}

// Her bölüm için ana mekânı tamamlayan, konuya özel derin arka plan katmanları.
// Dekor değil; sahnede anlatılan olayın parçası olan mimari/çevresel öğeler kullanılır.
function buildEpisodeEnvironment(E,S,T){
  const box=(w,h,d,c,pos,parent=null)=>E.box(w,h,d,E.mat(c),pos,{parent});
  const mat=(c,extra={})=>E.mat(c,extra);
  const addRock=(x,y,z,s=1,c="#59656a")=>E.sphere(s,mat(c),[x,y,z],{scale:[1.35,0.72,1.05],seg:14});
  const palm=(x,z,h=9)=>{const g=E.group(null,[x,0,z]);E.cyl(.16,.28,h,mat("#806044"),[0,0,0],{parent:g,seg:9});for(let a=0;a<7;a++){const leaf=E.box(.34,.09,3.8,mat(a%2?"#34784b":"#438b55"),[0,h-.18,0],{parent:g,center:true});leaf.rotation.set(.55,Math.PI*2*a/7,.22*Math.cos(a));leaf.translateZ(1.0);}return g;};
  const treeLine=(count=18)=>{for(let i=0;i<count;i++){const x=-34+i*4,z=-28-(i%4)*3;S.tree(x,z,{type:i%3===0?"pine":"round",s:1.5+(i%3)*.25});}};
  const makeBoat=(x=0,z=-8,damaged=true)=>{
    const g=E.group(null,[x,0,z]);
    // Ahşap gövde, güverte, baş-kıç ve gerçek güverte donanımı.
    E.box(7.2,.75,2.6,mat("#6b3f2b"),[0,.05,0],{parent:g});
    E.box(6.5,.18,2.25,mat("#bd925e"),[0,.48,0],{parent:g});
    E.box(7.5,.18,.16,mat("#4b3027"),[0,.78,1.18],{parent:g});
    E.box(7.5,.18,.16,mat("#4b3027"),[0,.78,-1.18],{parent:g});
    E.cone(1.35,2.4,mat("#70432d"),[0,.35,-2.5],{parent:g,seg:4,rot:[Math.PI/2,0,0]});
    E.cyl(.12,.12,5.6,mat("#523b2b"),[.4,3.0,0],{parent:g,seg:8});
    const sail=E.plane(2.7,3.4,mat("#d9d2bf",{side:E.THREE.DoubleSide}),[1.0,3.1,0],{parent:g});sail.rotation.y=Math.PI/2;
    E.box(1.4,.55,1.0,mat("#5c4537"),[-1.9,.82,0],{parent:g});
    for(let x0=-2.7;x0<=2.7;x0+=.9){E.cyl(.035,.035,.65,mat("#d8c49a"),[x0,.85,.95],{parent:g,seg:6});}
    if(damaged){
      const split=E.box(2.1,.16,.18,mat("#3c2924"),[2.4,.72,.1],{parent:g});split.rotation.z=-.22;
      const plank=E.box(2.4,.12,.25,mat("#8c5b3c"),[-3.0,.65,-.2],{parent:g});plank.rotation.z=.38;
      const torn=E.box(.16,2.1,.14,mat("#e2ddcf"),[1.2,3.0,.05],{parent:g});torn.rotation.z=.3;
    }
    R.boat=g;return g;
  };
  const makeStorm=(seed=1)=>{
    R.stormClouds=[];
    for(let i=0;i<13;i++){const x=-38+i*6.3,y=20+(i%3)*2,z=-55-(i%4)*8;const cl=E.sphere(7+(i%3),mat(i%2?"#35404d":"#273341"),[x,y,z],{scale:[1.9,.62,1.05],seg:12});cl.userData.baseX=x;R.stormClouds.push(cl);}
    R.lightning=new E.THREE.PointLight(0x9fc9ff,0,100,2);R.lightning.position.set(-8,16,-24);E.scene.add(R.lightning);
    // Yağmur çizgileri: sahnenin ön ve arka derinliklerinde, kamera hareketiyle paralaks verir.
    R.rain=[];for(let i=0;i<90;i++){const x=((i*17)%70)-35,y=4+(i*13)%25,z=-48+(i*19)%55;const d=E.box(.025,.8,.025,mat("#9ab5c7",{transparent:true,opacity:.42}),[x,y,z]);d.rotation.z=.16;d.userData.baseX=x;d.userData.baseY=y;R.rain.push(d);}
  };
  const ocean=(color="#15516c")=>{
    R.water=S.water({size:260,y:-.38,col:color,z:-18});
    R.waves=[];for(let i=0;i<22;i++){const x=-35+(i%11)*7,z=-8-Math.floor(i/11)*13;const w=E.sphere(1.7,mat(i%2?"#2d8296":"#4a9eaa",{transparent:true,opacity:.7}),[x,-.18,z],{scale:[2.8,.12,.45],seg:12});w.userData.baseX=x;R.waves.push(w);}
  };
  const beach=(dark=false)=>{
    E.box(90,.25,38,mat(dark?"#71604b":"#b69b70"),[0,-.25,13]);
    for(let i=0;i<26;i++){const x=-42+(i%13)*7,z=-4+Math.floor(i/13)*4;addRock(x,-.05,z,.8+(i%3)*.35,i%2?"#58636a":"#77756d");}
    for(let i=0;i<8;i++)palm(-30+i*8,-2-(i%3)*2,8+(i%3));
    treeLine(17);
  };
  const signalPost=(x,z)=>{const g=E.group(null,[x,0,z]);E.cyl(.13,.18,3.6,mat("#554532"),[0,0,0],{parent:g});E.box(2.0,.65,.16,mat("#7b6041"),[0,3.2,0],{parent:g});E.box(.18,.18,.2,mat("#e2bd62",{emissive:"#e2a93c",glow:1.2}),[0,3.7,0],{parent:g});R.signal=g;return g;};
  const fire=(x,z)=>{const g=E.group(null,[x,0,z]);for(let i=0;i<8;i++){const a=i*Math.PI/4;E.cyl(.12,.16,1.15,mat("#60402c"),[Math.cos(a)*.45,.16,Math.sin(a)*.45],{parent:g,rot:[0,0,Math.PI/2],seg:7});}R.fire=E.cone(.65,1.6,mat("#ff9b36",{emissive:"#ff5b1f",glow:1.3}),[0,1.0,0],{parent:g,seg:9});const glow=new E.THREE.PointLight(0xff8a32,2.2,13,2);glow.position.set(x,1.5,z);E.scene.add(glow);R.fireLight=glow;return g;};
  const ruinHut=(x,z,scale=1)=>{const g=E.group(null,[x,0,z]);E.box(5*scale,.25,4*scale,mat("#6e5239"),[0,-.25,0],{parent:g});for(const sx of [-2,2])for(const sz of [-1.5,1.5])E.cyl(.13,.17,3.4*scale,mat("#634a35"),[sx*scale,0,sz*scale],{parent:g});const roof=E.cone(3.9*scale,2.0*scale,mat("#765b40"),[0,3.4*scale,0],{parent:g,seg:4});roof.rotation.y=Math.PI/4;E.box(1.1*scale,2.1*scale,.12,mat("#302c2a"),[0,0,-2*scale],{parent:g});return g;};

  const scene=EP.scene;
  if(scene==="storm_beach"){
    ocean("#16445d");beach(true);makeBoat(0,-9,true);makeStorm(7);
    // Uzakta görünen ada sırtı ve kırılan dalga setleri.
    S.mountains({z:-86,col:"#344b52",n:8,seed:19});
    for(let i=0;i<7;i++){const crest=E.sphere(2.0,mat("#a9c5c8",{transparent:true,opacity:.58}),[-24+i*8,-.05,-15-(i%3)*8],{scale:[2.4,.14,.45]});crest.userData.baseX=crest.position.x;R.waves.push(crest);}
    // Kıyıya vurmuş sandık, kırık kürek ve metal levha.
    E.box(1.6,1.1,1.2,mat("#7a5636"),[-7,0,3]);E.box(2.6,.12,.2,mat("#9a704b"),[7,0,1]).rotation.z=.25;
    signalPost(10,-4);
  }else if(scene==="camp"){
    E.ground(T.stone("#75634a"),140,.22);S.mountains({z:-100,col:"#354d43",n:7,seed:12});
    for(let i=0;i<32;i++){let x=-38+(i%8)*10,z=-10-Math.floor(i/8)*9;S.tree(x,z,{type:"round",s:1.6+(i%3)*.25});S.bush(x+2,z+2,1.2,"#315b3c");}
    E.box(9,.22,7,mat("#786348"),[0,.02,2]);E.box(5,2.8,.18,mat("#96734b"),[0,0,-2]);
    for(let x of [-2.4,2.4]){const pole=E.cyl(.12,.15,3.4,mat("#684b32"),[x,1.7,-1.5]);pole.rotation.z=x*.04;}
    const tarp=E.box(6,.12,4,mat("#596f63"),[0,3.1,-1.5]);tarp.rotation.x=.12;
    fire(-4,5);signalPost(12,-12);R.shelter=tarp;
  }else if(scene==="jungle"){
    E.ground(T.stone("#3f684b"),160,.25);S.mountains({z:-130,col:"#426b58",n:8,seed:25});
    for(let i=0;i<46;i++){const x=-42+(i%10)*9,z=-9-Math.floor(i/10)*9;S.tree(x,z,{type:i%4===0?"pine":"round",s:1.7+(i%3)*.4});S.bush(x+2,z+1,1.5,i%2?"#2c7047":"#397d4d");}
    // Açık patika, kırık araştırma işaretleri ve yerdeki ayak izleri.
    E.box(7,.08,60,mat("#98764e"),[0,.04,-24]);for(let i=0;i<8;i++){E.sphere(.12,mat("#292e2a"),[(i%2?1:-1)*.6,.09,-5-i*5],{scale:[.45,.05,.8]});}
    for(let x of [-12,12]){E.cyl(.1,.12,5,mat("#806047"),[x,2.5,-18]);E.box(1.4,.8,.12,mat("#9a8057"),[x,4.9,-18]);}
    R.vines=[];for(let i=0;i<10;i++){let v=E.cyl(.045,.06,7,mat("#315d3d"),[-20+i*4,4,-24-(i%3)*5]);v.rotation.z=.35;R.vines.push(v);}
  }else if(scene==="waterfall"){
    E.ground(T.stone("#61705a"),150,.22);S.mountains({z:-110,col:"#526d68",n:8,seed:33});
    for(let i=0;i<9;i++)addRock(-22+i*5.5,1,-24,.9+(i%3)*.4,"#59696a");
    E.box(44,24,4,mat("#586b66"),[0,0,-32]);
    R.falls=[];for(let i=0;i<7;i++){const f=E.box(2.0+(i%3)*.5,19,.18,mat("#8ed6df",{transparent:true,opacity:.76}),[-6+i*2,0,-29]);R.falls.push(f);}
    E.sphere(12,mat("#438b9a",{transparent:true,opacity:.78}),[0,.12,-20],{scale:[2.0,.08,.75]});
    for(let i=0;i<24;i++)S.tree(-36+i*3,-4-(i%5)*5,{type:"round",s:1.25+(i%3)*.2});
    // Şelalenin arkasındaki karanlık geçit.
    E.box(5.2,7,.22,mat("#172d32"),[0,0,-27]);R.caveGlow=E.sphere(.32,mat("#6bd1d7",{emissive:"#268e9d",glow:1.3}),[0,3.2,-25.8]);
  }else if(scene==="settlement"){
    E.ground(T.stone("#88765d"),150,.2);S.mountains({z:-115,col:"#58635d",n:7,seed:44});
    for(let i=0;i<7;i++)ruinHut(-24+i*8,-18-(i%2)*5,.8+(i%3)*.12);
    for(let i=0;i<12;i++){const x=-28+i*5;E.box(3,.14,.16,mat("#684d35"),[x,.9,-5]);E.cyl(.08,.1,1.8,mat("#5b4633"),[x,0,-5]);}
    S.tree(-34,-3,{type:"round",s:2});S.tree(34,-9,{type:"round",s:2});
    E.box(4,.18,2.5,mat("#504b42"),[0,.1,-12]);E.box(1.8,1.4,.12,mat("#b08d55"),[0,1,-10.7]);
    R.radio=E.group(null,[0,0,0]);E.box(1.4,.6,.8,mat("#303d40"),[0,1.0,-11],{parent:R.radio});E.cyl(.04,.04,3,mat("#9b9b88"),[0,1.6,-11],{parent:R.radio});
  }else if(scene==="cave"){
    E.ground(T.stone("#4b555a"),140,.24);E.box(80,28,4,mat("#3b454a"),[0,0,-32]);
    for(let i=0;i<11;i++){const x=-25+i*5;E.sphere(4.5,mat(i%2?"#4b555b":"#596168"),[x,3,-28],{scale:[1.1,1.5,.8]});}
    E.box(12,10,.35,mat("#1c242b"),[0,0,-28]);
    for(let i=0;i<8;i++){const c=E.cone(1.2,5,mat("#626b70"),[-20+i*5,7,-24],{seg:7});c.rotation.z=Math.PI;}
    R.crystals=[];for(let i=0;i<9;i++)R.crystals.push(E.cone(.35,2.3,mat("#65b9c7",{emissive:"#267f95",glow:1.1}),[-16+i*4,.9,-12-(i%3)*4],{seg:5}));
    E.box(2.2,.16,.12,mat("#a78b5a"),[0,.2,-12]);
  }else if(scene==="summit"){
    E.ground(T.stone("#7c807b"),150,.22);S.mountains({z:-120,col:"#657b88",n:10,seed:52});
    for(let i=0;i<8;i++){const x=-30+i*8;E.cone(4+i%3,12+i%4*2,mat("#69777e"),[x,5,-18-(i%3)*5],{seg:6});}
    E.box(50,.35,20,mat("#596a70"),[0,-.1,-14]);
    E.cyl(.22,.35,8,mat("#555e63"),[0,0,-22]);E.box(4,.4,2,mat("#4c565c"),[0,8,-22]);
    R.beacon=E.sphere(.55,mat("#e8bd65",{emissive:"#ffbf4d",glow:1.4}),[0,9,-22]);
    for(let i=0;i<10;i++){const x=-28+i*6;S.tree(x,-2-(i%3)*5,{type:"pine",s:1.1+(i%2)*.3});}
  }else if(scene==="research"){
    E.ground(T.stone("#555f5c"),150,.22);S.mountains({z:-120,col:"#46565b",n:8,seed:66});
    E.box(24,9,14,mat("#707a79"),[0,0,-22]);E.box(25,.55,15,mat("#343e43"),[0,9.2,-22]);
    for(let x=-9;x<=9;x+=6){E.box(4,3,.18,mat("#203a47"),[x,5,-14.85]);E.box(3.5,2.5,.08,mat("#6da2a7",{emissive:"#1d5963",glow:.55}),[x,5,-14.72]);}
    E.box(7,2.5,.4,mat("#29363b"),[0,1.4,-14.5]);E.cyl(.12,.12,11,mat("#7a8582"),[0,9.7,-23]);
    E.cyl(2.2,2.2,.3,mat("#9ba8a4"),[0,20.5,-23],{rot:[Math.PI/2,0,0]});
    for(let i=0;i<8;i++)S.tree(-36+i*10,-3-(i%3)*4,{type:"pine",s:1.25});
    R.console=E.group(null,[0,0,0]);E.box(4,.7,1.1,mat("#34464b"),[0,.9,-8],{parent:R.console});
  }else if(scene==="beach"){
    ocean("#247b8c");beach(false);makeBoat(0,-8,false);S.mountains({z:-95,col:"#58756c",n:8,seed:78});
    R.boat.rotation.y=.16;signalPost(14,-3);
    E.box(2.0,.18,.16,mat("#c5a16b"),[-8,.2,2]);
  }
}

function buildScene(E,S,T){
  const scene=EP.scene||"town";
  if(["storm_beach","camp","jungle","waterfall","settlement","cave","summit","research","beach"].includes(scene)) { /* ada çevresi buildEpisodeEnvironment içinde kuruluyor */ }
  else if(scene==="station")buildStation(E,S,T);
  else if(scene==="empty_house")buildHouse(E,S,T);
  else if(scene==="archive")buildArchive(E,S,T);
  else if(scene==="tunnel")buildTunnel(E,S,T);
  else if(scene==="underground")buildUnderground(E,S,T);
  else if(scene==="control_room")buildControl(E,S,T);
  else if(scene==="clocktower")buildTower(E,S,T);
  else if(scene==="seam")buildSeam(E,S,T);
  else makeTown(E,S,T);
}

export function build(E){
  const {S,T}=E; buildScene(E,S,T); buildEpisodeEnvironment(E,S,T);
  for(const name of Object.keys(SPECS)){actorsByName[name]=E.actor(IDs[name],SPECS[name],{h:name==="Merco"?1.15:2.2});}
  // Sahneye özgü merkez öğeler ve animasyonları.
  R.clockHand ||= null;
  if(EP.scene==="station")R.doorGlow=E.sphere(0.18,E.mat("#70d8ed",{emissive:"#37b6d2",glow:1.3}),[0,2.4,-5.3]);
  if(EP.scene==="empty_house")R.photo=R.photo||E.group(null,[0,0,0]);
}

const gestureFor=(action,idx)=>({
  talk:["present","point","shrug","hold"][idx%4], angry:"facepalm", shrug:"shrug", reach:"reach", walk:"present",run:"cheer",pov_walk:"reach",search:"think",inspect:"chin",open:"reach",pull:"holdR",listen:"whisper",hide:"chin",point:"point",reveal:"present",freeze:"hold",enter:"reach",escape:"cheer",climb:"reach",fall:"up",switch:"holdR",determined:"hip",read:"hold",wait:"hang",turn:"point",save:"reach"
}[action]||"present");
const faceFor=(line,action,text)=>line.face||({angry:"angry",sad:"sad",run:"wow",escape:"scared",freeze:"scared",hide:"nervous",listen:"nervous",reveal:"wow",fall:"wow",determined:"determined",save:"determined",pull:"determined",search:"think",inspect:"think",read:"think"}[action]||(text.includes("? ")||text.endsWith("?")?"think":text.includes("! ")?"wow":"neutral"));
const movementActions=new Set(["walk","run","pov_walk","search","open","pull","enter","escape","climb","fall","hide","switch","save","reach"]);
const propFor=(line,action)=>line.prop||null;
function getActive(E,f){
  const fps=30,frames=Math.max(1,Math.ceil(((E.words.at(-1)?.e)||90)*fps)+24);
  const wframe=n=>{const i=clamp(Number(n)||0,0,E.words.length-1);return E.words[i]?Math.round(E.words[i].s*fps):0;};
  const spans=EP.lines.map(l=>({...l,from:Math.max(0,wframe(l.start_word)-2),to:l.end_word+1<E.words.length?wframe(l.end_word+1)+2:frames}));
  const active=spans.find(l=>f>=l.from&&f<=l.to)||spans[spans.length-1];
  return {active,spans,frames};
}
function actorPlacement(name,line,idx,u,action){
  const speaker=line.speaker, side=(speaker==="Nur"||speaker==="Kubilay")?1:-1;
  const t=smooth(u);
  // Ev ve arşivde masa/sandalye çevresinden geçen güvenli oyuncu koridorları.
  // Düz çizgide mobilyanın içinden yürütmek yerine karakteri açık yan geçişte tut.
  if(EP.scene==="empty_house"){
    const lane=name===speaker?side*4.15:(side*-4.15);
    let z=name===speaker?1.9:-0.8;
    if(name===speaker&&["walk","pov_walk","enter","search","open","pull","save","reach","run","escape"].includes(action)) z=mix(2.25,-1.75,t);
    if(name===speaker&&["inspect","read","switch","reveal"].includes(action)) z=mix(1.25,-0.15,t);
    return [lane,0,z];
  }
  if(EP.scene==="archive"){
    const lane=name===speaker?side*5.5:side*-5.5;
    let z=name===speaker?1.5:-1.0;
    if(name===speaker&&movementActions.has(action))z=mix(2.0,-2.5,t);
    return [lane,0,z];
  }
  let p=name===speaker?[side*1.6,0,1.4]:[side*-1.5,0,-1.8];
  if(name===speaker){
    if(["walk","pov_walk","enter","search","open","pull","save","reach"].includes(action))p=[mix(side*2.4,side*0.3,t),0,mix(2.4,-2.7,t)];
    if(["run","escape"].includes(action))p=[mix(side*2.6,side*-0.5,t),0,mix(3.2,-5.0,t)];
    if(action==="climb")p=[mix(side*2,side*0.4,t),mix(0,1.6,t),mix(1.8,-1.2,t)];
    if(action==="fall")p=[mix(side*1.2,side*0.2,t),Math.sin(t*Math.PI)*0.45, mix(1.2,-1.0,t)];
    if(action==="hide")p=[side*2.6,0,-3.2];
    if(action==="inspect"||action==="read"||action==="switch")p=[mix(side*1.7,0.1,t),0,mix(1.5,-2.2,t)];
  }else if(action==="pull"||action==="save")p=[mix(side*-2.2,side*0.8,t),0,mix(-2.2,-4.1,t)];
  else if(action==="run"||action==="escape")p=[mix(side*-2.2,side*1.2,t),0,mix(-3.0,-5.0,t)];
  // Kalabalık sahnelerde karakterleri tek sıra yan yana dizme; derinlik katmanları kullan.
  if(idx>=2)p=[(idx%2?1:-1)*2.8,0,-4.2-(idx*0.8)];
  // Ev/arşiv dışındaki iç mekânlarda ana geçiş hattı mobilya ve konsollardan uzak tutulur.
  if(["control_room","underground"].includes(EP.scene)&&name===speaker&&movementActions.has(action))p=[side*4.2,0,mix(2.2,-2.8,t)];
  return p;
}
function cameraKeys(E,line,from,to,u,actorPos,action){
  const shot=line.shot||"close", span=Math.max(1,to-from), x=actorPos[0],z=actorPos[2];
  const start=from,mid=Math.round(from+span*0.52),end=to;
  const push=0.65+0.2*Math.sin(u*Math.PI), shake=(action==="run"||action==="escape"||action==="fall")?0.06:0;
  if(shot==="wide"&&["storm_beach","camp","jungle","waterfall","settlement","cave","summit","research","beach"].includes(EP.scene)){
    const isSea=["storm_beach","beach"].includes(EP.scene);
    return [{f:start,pos:[-2.5,9,isSea?27:23],look:[0,2,isSea?-12:-12],fov:44},{f:mid,pos:[1.2,7.5,isSea?24:20],look:[0,2,isSea?-15:-14],fov:42},{f:end,pos:[2.0,6.5,isSea?22:18],look:[0,1.8,isSea?-16:-15],fov:40}];
  }
  if(shot==="pov"){
    const travel=action==="run"||action==="escape"?8.0:["walk","pov_walk","enter","search","open","pull","save","reach","climb"].includes(action)?5.2:["inspect","listen","point","reveal"].includes(action)?1.5:0.65;
    return [
      {f:start,pos:[x*0.42,1.58,5.8],look:[x*0.34,1.55,-2.2],fov:48},
      {f:mid,pos:[x*0.48,1.58,5.8-travel*0.52],look:[x*0.40,1.6,-2.2-travel*0.55],fov:46},
      {f:end,pos:[x*0.54,1.58,5.8-travel],look:[x*0.46,1.65,-2.2-travel],fov:45}
    ];
  }
  if(shot==="insert"){
    const target=(EP.scene==="station"?-6:EP.scene==="tunnel"?-8:EP.scene==="underground"?-7:EP.scene==="seam"?-7:-2.8);
    const near=(EP.scene==="station"||EP.scene==="tunnel"||EP.scene==="underground"||EP.scene==="seam")?1.8:4.8;
    return [{f:start,pos:[0.1,2.3,near],look:[0,1.6,target],fov:34},{f:mid,pos:[0.1,2.0,near-0.8],look:[0,1.5,target],fov:31},{f:end,pos:[0,1.9,near-1.2],look:[0,1.6,target],fov:32}];
  }
  if(shot==="wide")return [{f:start,pos:[0,5.3,14],look:[0,1.4,-1],fov:52},{f:mid,pos:[-1.2,4.6,12],look:[0,1.5,-1],fov:49},{f:end,pos:[1,4.2,11],look:[0,1.6,-1],fov:48}];
  if(shot==="low")return [{f:start,pos:[x+1,0.8,z+6],look:[x,1.6,z-1],fov:37},{f:mid,pos:[x+0.5,1.0,z+4.5],look:[x,1.5,z-1.5],fov:35},{f:end,pos:[x+0.2,1.1,z+4.0],look:[x,1.5,z-1.5],fov:34}];
  if(shot==="tracking")return [{f:start,pos:[x+0.8,2.35,z+6.2],look:[x,1.45,z-0.4],fov:44},{f:mid,pos:[x+0.55,2.2,z+4.8],look:[x,1.45,z-1.0],fov:43},{f:end,pos:[x+0.25,2.15,z+4.0],look:[x,1.5,z-1.6],fov:42}];
  if(shot==="over")return [{f:start,pos:[x-1.55,2.65,z+5.8],look:[x,1.5,z-0.8],fov:45},{f:mid,pos:[x-1.0,2.35,z+4.8],look:[x,1.5,z-1.2],fov:43},{f:end,pos:[x-0.65,2.25,z+4.2],look:[x,1.5,z-1.5],fov:42}];
  if(shot==="medium")return [{f:start,pos:[x+3.4,3.2,z+8.2],look:[x,1.6,z-0.8],fov:48},{f:mid,pos:[x+2.7,2.9,z+7.2],look:[x,1.6,z-0.8],fov:46},{f:end,pos:[x+2.2,2.6,z+6.3],look:[x,1.6,z-0.8],fov:45}];
  const close=shot==="reaction"?33:38;
  return [{f:start,pos:[x+2.4,2.6,z+6],look:[x,1.55,z],fov:close},{f:mid,pos:[x+1.5,2.35,z+5.1],look:[x,1.6,z],fov:close-2},{f:end,pos:[x+1.3,2.25,z+4.7],look:[x,1.6,z],fov:close-1}];
}
export function frame(f,E){
  const {active,spans,frames}=getActive(E,f),line=active||EP.lines[0],lineIndex=spans.indexOf(active),span=Math.max(1,active.to-active.from),u=clamp((f-active.from)/span),sec=f/30;
  const speaker=line.speaker||"Batu",action=line.action||"talk",shot=line.shot||"close",text=(line.text||"").toLocaleLowerCase("tr"),talk=(name)=>speaker===name?E.talk(f,active.from,active.to):0;
  let visible=Array.isArray(line.visible)?line.visible.slice():[speaker];
  if(shot==="pov")visible=visible.filter(n=>n!==(line.pov_actor||speaker));
  if(!visible.length&&shot!=="pov")visible=[speaker];
  visible=visible.slice(0,3);
  const focusName=visible.find(n=>n===speaker)||visible[0]||"Batu",focusId=IDs[focusName]||IDs.Batu;
  const placements={};
  visible.forEach((name,i)=>placements[name]=actorPlacement(name,line,i,u,action));
  const focusPos=placements[focusName]||[0,0,0];
  const actors=[];
  for(const name of visible){
    const id=IDs[name],p=placements[name]||[0,0,0],isSpeaker=name===speaker;
    let act=isSpeaker?action:"wait";
    let legs=movementActions.has(act)?(act==="run"||act==="escape"?"run":"walk"):"stand";
    if(act==="hide")legs="sit";
    let face=isSpeaker?faceFor(line,action,text):(text.includes("tehl")||text.includes("kaybol")?"scared":"think");
    let arms=isSpeaker?gestureFor(action,lineIndex):"think";
    if(!isSpeaker&&line.action==="freeze")arms="hold";
    let prop=isSpeaker?propFor(line,action):null;
    let extra={legs,phase:sec*1.35+lineIndex*0.19,look:isSpeaker?0.12:((lineIndex%2)?-0.12:0),lean:isSpeaker&&movementActions.has(action)?0.16:0,headTilt:isSpeaker?5*Math.sin(sec*1.4):2,roll:action==="fall"?mix(0,0.45,smooth(u)):0};
    if(action==="fall"&&isSpeaker)extra.bob=45*Math.sin(u*Math.PI);
    if(action==="hide"&&isSpeaker)extra.tilt=16;
    if(action==="listen"&&isSpeaker)extra.headTilt=-12;
    if(prop)extra.prop=prop;
    actors.push({id,pos:p,scale:name==="Merco"?0.86:1,roll:action==="fall"&&isSpeaker?mix(0,0.5,smooth(u)):0,st:{blink:E.blink(f,SEEDS[name]),...E.idle(f,SEEDS[name]),face,arms,talk:isSpeaker&&name!=="Merco"?talk(name):0,...extra}});
  }
  let cam=E.camAt(f,cameraKeys(E,line,active.from,active.to,u,focusPos,action),{creep:shot==="pov"?0.08:0.04});
  if(action==="run"||action==="escape"||action==="fall"){
    const k=(1-smooth(u))*0.055;cam.pos[0]+=Math.sin(f*0.29)*k;cam.pos[1]+=Math.cos(f*0.33)*k;
  }
  // Merco antennini yalnızca sahnede göründüğünde konumlandır; ışığı konuşma ve sinyale göre pulse eder.
  if(R.clockHand)R.clockHand.rotation.z=EP.number===1?Math.sin(sec*2.3)*0.3:Math.sin(sec*1.2)*0.1;
  if(R.clock)R.clock.rotation.y=0.03*Math.sin(sec*0.6);
  if(R.doorGlow)R.doorGlow.visible=(action==="reveal"||text.includes("ışık")||text.includes("kapı"))&&Math.sin(sec*5)>0;
  if(R.core)R.core.rotation.y=sec*0.22;
  if(R.portal){R.portal.rotation.z=sec*0.16;R.portal.scale.setScalar(0.96+0.04*Math.sin(sec*3.4));}
  if(R.console)R.console.rotation.y=0.04*Math.sin(sec*0.7);
  if(R.panel)R.panel.rotation.y=0.03*Math.sin(sec*1.5);
  // Çevre animasyonu: deniz dalgaları, hasarlı tekne salınımı, yağmur, ateş ve sinyal ışığı.
  if(R.boat){R.boat.position.y=0.05+Math.sin(sec*1.65)*0.22;R.boat.rotation.z=Math.sin(sec*1.1)*0.055;R.boat.rotation.x=Math.cos(sec*1.35)*0.035;}
  if(R.waves)R.waves.forEach((w,i)=>{w.position.x=w.userData.baseX+Math.sin(sec*0.7+i)*0.8;w.position.y=-0.16+Math.sin(sec*1.7+i*0.8)*0.09;w.scale.z=0.35+0.1*Math.sin(sec*1.4+i);});
  if(R.water&&R.water.material&&R.water.material.map){R.water.material.map.offset.x=sec*0.006;R.water.material.map.offset.y=sec*0.012;}
  if(R.stormClouds)R.stormClouds.forEach((c,i)=>{c.position.x=c.userData.baseX+Math.sin(sec*0.08+i)*0.35;});
  if(R.rain)R.rain.forEach((d,i)=>{d.position.y=1+((d.userData.baseY-1-sec*7.5)%25+25)%25;d.position.x=d.userData.baseX+Math.sin(sec*.5+i)*.35;});
  if(R.lightning)R.lightning.intensity=(Math.sin(sec*2.7)>0.985?8:Math.sin(sec*2.7)>0.965?2:0);
  if(R.fire){const k=1+0.12*Math.sin(sec*8)+0.06*Math.sin(sec*13);R.fire.scale.set(k,k,k);}if(R.fireLight)R.fireLight.intensity=1.8+0.65*Math.sin(sec*9);
  if(R.signal)R.signal.rotation.y=0.03*Math.sin(sec*0.6);
  if(R.radio)R.radio.rotation.y=0.04*Math.sin(sec*1.1);
  if(R.crystals)R.crystals.forEach((c,i)=>c.scale.y=0.85+0.25*Math.sin(sec*2.2+i));
  if(R.vines)R.vines.forEach((v,i)=>v.rotation.z=0.35+0.08*Math.sin(sec*.8+i));
  if(R.beacon)R.beacon.scale.setScalar(0.9+0.2*(0.5+0.5*Math.sin(sec*2.8)));
  if(R.falls)R.falls.forEach((f,i)=>{f.position.y=11+0.16*Math.sin(sec*3+i);});
  const fx=[];
  if(action==="reveal")fx.push({kind:"sparkle",pos:[0,3.1,-2.5],size:0.55,t:u});
  if(action==="run"||action==="escape")fx.push({kind:"dust",pos:[focusPos[0],0.6,focusPos[2]+0.5],size:0.7,t:u});
  if(text.includes("?")&&action==="inspect")fx.push({kind:"question",pos:[focusPos[0]+0.7,3.2,focusPos[2]],size:0.32,t:u});
  if(text.includes("!")&&action==="freeze")fx.push({kind:"exclaim",pos:[focusPos[0]+0.6,3.0,focusPos[2]],size:0.32,t:u});
  const scene=EP.scene||"town";
  const light=({storm_beach:"dramatic",camp:"night",jungle:"day",waterfall:"day",settlement:"dramatic",cave:"dramatic",summit:"day",research:"night",beach:"golden"})[scene]||((scene==="tunnel"||scene==="underground"||scene==="seam"||scene==="control_room")?"dramatic":(scene==="station"||scene==="clocktower")?"night":scene==="empty_house"||scene==="archive"?"interior":"day");
  return {cam,light,dof:{focus:[focusPos[0],1.4,focusPos[2]],amount:shot==="insert"||shot==="close"?2.5:1.5,range:7},actors,fx};
}
