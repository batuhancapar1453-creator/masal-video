# GizemliStüdyo – Kayıp Ada Blender 3D

Bu sürüm, bölüm senaryosundaki konuşmacı, `visible`, `action`, `shot` ve bölüm `kind` alanlarını Blender sahne yönetimine bağlar.

## Animasyon davranışları
- Her replikte yalnızca `visible` listesinde bulunan karakterler görünür; diğerleri render karesinden gizlenir.
- Kamera her replikte görünen karakter grubuna göre kadrajını değiştirir; tek kişilik konuşmalarda tüm ekibi aynı kareye doldurmaz.
- Konuşma ağız hareketleri gerçek ses repliklerinin sürelerine bağlanır.
- `walk`, `carry`, `build`, `collect`, `run`, `point`, `inspect`, `listen`, `reaction` gibi eylemler için vücut, baş, kol ve bacak anahtar kareleri üretilir.
- Senaryo metninde odun/toplama, barınak/çatı/direk ve kamp ateşi anlatılıyorsa bunlara karşılık gelen 3D nesneler sahneye eklenir; barınak parçaları bölüm ilerledikçe birikir.
- Deniz Ocean modifier ile dalgalanır; tekne hareket eder ve palmiye yaprakları rüzgârda sallanır.
- Bölüm türüne göre yağmur/şimşek, orman, şelale, terk edilmiş yerleşke, mağara geçidi veya dağ zirvesi set parçaları eklenir.

## Sınırlar / test durumu
Bu, prosedürel Blender 3D animasyon altyapısıdır; profesyonel karakter rig'i, gelişmiş el-parmak animasyonu, motion capture veya stüdyo seviyesinde Pixar üretimi değildir. Bazı anlatı eylemleri metin anahtar kelimeleri ve `action` alanlarıyla eşleştirilir; yeni eylem türleri için Blender motoruna yeni animasyon şablonları eklenmelidir.

Python sözdizimi ve 10 bölüm JSON yapısı kontrol edilmiştir. Bu çalışma ortamında Blender çalıştırıcısı bulunmadığı için gerçek MP4 renderi ve YouTube yüklemesi test edilmemiştir. İlk GitHub Actions çalıştırması gerçek render uyumluluğunu gösterecektir. Gerçek kaliteyi doğrulamak için ilk bölümün render önizlemesi incelenmelidir.
