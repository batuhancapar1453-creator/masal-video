# GizemliStüdyo – Kayıp Ada / Blender 3D kurulum

1. Depoda `.github/workflows/video.yml` dosyasını açın ve paketteki `02_GitHub_Actions.yml` içeriğiyle değiştirin.
2. `01_KayipAda_Sezon1_Kaynak.zip` dosyasını GitHub deposunun ana dizinine yükleyin.
3. GitHub Secrets içindeki şu üç değer mevcut hâliyle kalmalı: `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_REFRESH_TOKEN`.
4. GitHub → Actions → GizemliStüdyo workflow → Run workflow ile ilk pilotu başlatın.
5. Çalışma bittikten sonra Actions bölümündeki artifact içinden `episode_scene.blend`, MP4 ve önizleme dosyalarını kontrol edin.

## Sezon
1. Son Rota · 2. İlk Gece · 3. Ormandaki İzler · 4. Şelalenin Ardında · 5. Terk Edilmiş Yerleşke · 6. Fırtınadan Sonra · 7. Yeraltındaki Geçit · 8. Dağın Zirvesi · 9. Son Kayıt · 10. Kıyıdaki Tekne

## Önemli
Bu paket gerçek Blender 3D mesh sahneleri ve anahtar kareler üretir. Yine de bu ortamda Blender bulunmadığından gerçek render doğrulaması yapılamadı. İlk GitHub Actions çalıştırması pilot testtir; önizleme kontrol edilmeden profesyonel film kalitesi veya hatasız yayın garantisi verilemez. Render süresi sahneye ve GitHub runner kaynaklarına bağlıdır.
