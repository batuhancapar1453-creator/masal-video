# GizemliStüdyo — KIRILMA: KAYIP ADA / 1. Sezon

Bu kaynak paketi, mevcut `cizgi-short` motorunun mimarisini koruyarak Kayıp Ada hikâyesini 10 bölümlük, sıralı bir sezona dönüştürür.

## Kurulum

1. GitHub deposunda `.github/workflows/video.yml` dosyasını teslim edilen YAML ile değiştirin.
2. `GizemliStudyo_KayipAda_Sezon1_Kaynak.zip` dosyasını deponun kök dizinine yükleyin.
3. Şu GitHub Secrets değerlerini koruyun: `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_REFRESH_TOKEN`.
4. Actions içinden ilk çalıştırmayı elle başlatın. Sonraki yayınlar her gün Türkiye saati 09.00'da sıradaki bölümü seçer.

## Sezon sırası

1. Son Rota
2. İlk Gece
3. Ormandaki İzler
4. Şelalenin Ardında
5. Terk Edilmiş Yerleşke
6. Fırtınadan Sonra
7. Yeraltındaki Geçit
8. Dağın Zirvesi
9. Son Kayıt
10. Kıyıdaki Tekne

Ana karakterler Batu, Nur, Alperen, Kubilay ve konuşmayan/tepki veren küçük köpek Merco'dur. Bölümlerdeki diyaloglar sahne olaylarına göre yazılmıştır; her replik için konuşmacı, görünür karakterler, oyunculuk eylemi ve kamera planı tanımlanır.

## Görsel yönetim

- Karakterler mevcut kitin stilize 2D/3D hibrit çizgi karakter estetiğinde korunur.
- Çevreler Three.js ile 3D olarak sahneye kurulur: deniz, kıyı, hasarlı tekne, fırtına bulutları/yağmur/şimşek, kamp ve ateş, yoğun orman, şelale ve gizli geçit, terk edilmiş yerleşke, mağara, dağ zirvesi, araştırma tesisi ve final teknesi.
- Tekne salınımı, dalga hareketi, yağmur, şimşek, ateş ışığı, şelale ve verici ışıkları kare bazında animasyonlanır.
- Geniş plan, POV, takip, yakın plan, tepki ve nesne planları senaryo satırlarıyla yönetilir.
- Önizleme karelerinde arka planın yeterli görsel çeşitlilikte ve sahnelerin hareketli olduğu otomatik kontrol edilir. Kontrol başarısızsa YouTube yüklemesi yapılmaz.

**Dürüst kalite sınırı:** Bu düzenleme boş fon/eksik set sorununu gidermek ve anlatılan olayları sahneye koymak için gerçek 3D çevre setleri ekler. Karakter çizim stili fotogerçekçi değildir; tek başına Netflix stüdyo prodüksiyonu veya fotogerçekçi uzun metraj kalitesi vaat etmez. Gerçek görüntü kalitesi ilk GitHub önizleme artifact'inde doğrulanmalıdır.

## Ses

- Türkçe Edge Neural sesleri, karakter başına hız/perde/EQ ayrımıyla kullanılır. Alperen ve Kubilay aynı temel erkek TTS sesini farklı ayarlarla kullanır; bunlar ayrı gerçek ses oyuncuları değildir.
- Konuşmalar ayrı ayrı üretilir, WAV biçiminde birleştirilir ve yumuşak geçişler uygulanır.
- Bölüm türüne göre kodla üretilen ortam sesi (fırtına, dalga, kamp gecesi, orman, şelale, mağara, rüzgâr, araştırma tesisi) müzik ve efektlerle karıştırılır.
- Son miks FFmpeg loudness normalizasyonu ve limiter'dan geçirilir.

## Süre ve YouTube biçimi

- Bölüm hedefi 5–8 dakikadır; gerçek ses süresi 300–480 saniye dışında kalırsa yükleme durur.
- Çıktı 1080×1920, 30 FPS, H.264/AAC dikey videodur.
- **Önemli:** 5–8 dakikalık bir video YouTube Shorts olarak sınıflandırılamaz. Dikey olsa bile normal YouTube videosu olur. Shorts için video en fazla 3 dakika olmalıdır. Bu paket 5–8 dakikalık sinematik bölüm hedefini korur.
- Render 540×960 çalışma boyutunda yapılır ve 1080×1920'ye yükseltilir. 5–8 dakika, 30 FPS yaklaşık 9.000–14.400 kare demektir; GitHub runner süresi sahne karmaşıklığına bağlıdır ve önceden garanti edilemez.
- Job sınırı 345 dakikadır; render alt süreci 300 dakika ile sınırlıdır. Önceki çalıştırmadan kalan kareler cache ile devam ettirilebilir.

## Güvenlik ve yayın

- OAuth kontrolü render başlamadan yapılır.
- Önizleme ve arka plan denetimi geçmeden tam render/yükleme başlatılmaz.
- Video çözünürlük, FPS, codec ve gerçek süre kontrollerinden geçmeden yüklenmez.
- Bölüm geçmişi yalnızca başarılı YouTube yüklemesinden sonra GitHub'a commit edilir. Yeni bölüm kimlikleri eski hatalı test kaydından etkilenmeden 1. bölümü yeniden başlatır.
- Gerçek YouTube yükleme testi bu çalışma ortamında yapılamaz; GitHub Secrets ve kanal izinleri ilk Actions çalışmasında doğrulanır.
