#!/usr/bin/env python3
"""Güvenli kontak sayfası: bozuk kareleri atlar, önizlemeyi sınırlı boyutta tutar."""
import sys, os, glob, math
from PIL import Image, ImageDraw, ImageFile

# Eksik JPEG verisini sessizce kabul etme; bozuk kareyi aşağıda yakalayıp atla.
ImageFile.LOAD_TRUNCATED_IMAGES = False

src, out = sys.argv[1], sys.argv[2]
cols = int(sys.argv[3]) if len(sys.argv) > 3 else 6
if cols < 1:
    raise SystemExit("sütun sayısı en az 1 olmalı")
files = sorted(glob.glob(os.path.join(src, "*.jpg")))
if not files:
    raise SystemExit("kare yok")

# Binlerce kareden devasa bir görsel üretmek yerine zaman çizgisine yayılmış
# en fazla 36 kare seç. Böylece önizleme RAM tüketimi kontrol altında kalır.
max_previews = 36
if len(files) > max_previews:
    indices = [round(i * (len(files) - 1) / (max_previews - 1)) for i in range(max_previews)]
    candidates = [files[i] for i in indices]
else:
    candidates = files

W, H = 270, 480
valid = []
for path in candidates:
    try:
        with Image.open(path) as probe:
            probe.verify()
        with Image.open(path) as image:
            image.load()
            frame = image.convert("RGB").resize((W, H), Image.Resampling.LANCZOS)
        valid.append((path, frame))
    except (OSError, ValueError, SyntaxError) as exc:
        print(f"UYARI: Bozuk/eksik kare atlandı: {os.path.basename(path)} ({exc})", flush=True)

if not valid:
    raise SystemExit("önizleme için geçerli JPEG kare bulunamadı")

rows = (len(valid) + cols - 1) // cols
sheet = Image.new("RGB", (cols * W, rows * H), "#111")
draw = ImageDraw.Draw(sheet)
for i, (path, frame) in enumerate(valid):
    x, y = (i % cols) * W, (i // cols) * H
    sheet.paste(frame, (x, y))
    label = os.path.basename(path)
    label = label[:-4] if label.lower().endswith(".jpg") else label
    label = label.lstrip("0") or "0"
    draw.rectangle([x, y, x + 90, y + 22], fill="#000")
    draw.text((x + 4, y + 4), label, fill="#ff0")

os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
sheet.save(out, quality=85, optimize=True)
print(f"-> {out} ({len(valid)} geçerli önizleme / {len(files)} toplam kare)")
