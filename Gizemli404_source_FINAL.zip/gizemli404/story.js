// Gizemli404 — KIRILMA / sezon 1
// Doodle karakterler + derin 3D çevre + hareket odaklı sinematik sahneleme.
const epResponse = await fetch(new URL("./episode.json", import.meta.url));
if (!epResponse.ok) throw new Error("episode.json yüklenemedi");
const EP = await epResponse.json();
export const meta = { fps: 30, tail: 0.65 };

const clamp = (v, a=0, b=1) => Math.max(a, Math.min(b, v));
const mix = (a, b, t) => a + (b - a) * t;
const smooth = (t) => { t = clamp(t, 0, 1); return t*t*(3-2*t); };
const IDs = { Batu:"batu", Nur:"nur", Alperen:"alperen", Kubilay:"kubilay", Merco:"merco" };
const SEEDS = { Batu:11, Nur:17, Alperen:23, Kubilay:31, Merco:41 };
const SPECS = {
  Batu:{skin:"#f4d7bc",shirt:"#48b8c3",jacket:"#287f91",pants:"#263c59",shoes:"#e9a44b",hair:"spiky",hairCol:"#30231f",seed:11,build:"adult"},
  Nur:{skin:"#f7e4d0",shirt:"#e87570",jacket:"#c94f5a",pants:"#65558d",shoes:"#f1c75d",hair:"long",hairCol:"#35231f",seed:17,build:"adult"},
  Alperen:{skin:"#e9c9aa",shirt:"#78986f",jacket:"#4f7557",pants:"#454d5a",shoes:"#40352e",hair:"part",hairCol:"#77736c",glasses:true,seed:23,build:"stout"},
  Kubilay:{skin:"#f2d6bc",shirt:"#8b79bd",jacket:"#61518d",pants:"#39475f",shoes:"#e0b75d",hair:"short",hairCol:"#27252a",hat:"cap",hatCol:"#4f6fb0",hatBand:"#e7c25a",glasses:true,seed:31,build:"adult"},
  Merco:{skin:"#d5f1e8",shirt:"#61c8bd",jacket:"#319b95",pants:"#39515b",shoes:"#cde9e4",hat:"helmet",hatCol:"#65cfc5",glasses:true,seed:41,build:"adult"}
};
let R = {};
const actorsByName = {};

function makeTown(E,S,T){
  E.ground(T.cobble("#9b9a91"),170,0.22); S.street({len:120,width:14,z:-4});
  S.row(-48,48,-15,{seed:8}); S.row(-48,48,15,{seed:22,rot:Math.PI});
  S.hills({z:-85,col:"#617c7a"}); S.clouds({n:7,y:28,z:-95,seed:6});
  for(const x of [-18,-10,10,18]){S.tree(x,-2,{type:x%2?"round":"pine",s:1.2});S.lamp(x+1,-2,{on:true});}
  S.building(-26,-20,{w:14,d:11,floors:2,wall:"#d8c2a0",roof:"#7d5263",cols:3});
  S.building(26,-20,{w:14,d:11,floors:2,wall:"#9fc5d0",roof:"#5a6c8c",cols:3});
  S.building(-26,20,{w:14,d:11,floors:2,wall:"#d0b1ce",roof:"#6c5279",cols:3});
  S.building(26,20,{w:14,d:11,floors:2,wall:"#e6d39b",roof:"#62865d",cols:3});
  S.bench(-5,3,Math.PI/2); S.bench(5,3,-Math.PI/2);
}
function buildStation(E,S,T){
  E.ground(T.cobble("#727a83"),120,0.18); S.hills({z:-100,col:"#45586e"}); S.clouds({n:5,y:26,z:-80});
  E.box(42,0.45,7,E.mat("#8b8d92"),[0,0,-3]); E.box(42,0.25,1.1,E.mat("#3c434b"),[0,0.28,-8]);
  for(let x=-19;x<=19;x+=2.4){E.box(0.5,0.12,2.5,E.mat("#6a5144"),[x,0.4,-8]);}
  E.box(0.18,0.18,44,E.mat("#53575c"),[-1.2,0.5,-8],{rot:[0,0,0]}); E.box(0.18,0.18,44,E.mat("#53575c"),[1.2,0.5,-8]);
  E.box(30,0.45,4.5,E.mat("#667786"),[0,0.45,-13]); E.box(28,0.2,1.2,E.mat("#526575"),[0,4.3,-13]);
  for(let x=-12;x<=12;x+=6){E.box(0.35,4.2,0.35,E.mat("#566979"),[x,2.1,-13]); E.box(0.45,0.45,0.45,E.mat("#e4c36c"),[x,4.5,-13]);}
  S.bench(-5,-5,0); S.bench(5,-5,0); S.lamp(-10,-4,{on:true});S.lamp(10,-4,{on:true});
  E.label(T.sign("İSTASYON",{bg:"#243b50",fg:"#f5e7c7",border:"#d7b15a",size:130}),5,0.9,[0,5,-12.2]);
  E.box(5.2,4.6,0.3,E.mat("#26384b"),[0,2.3,-5.8]); E.box(4.3,3.8,0.18,E.mat("#547b91"),[0,2.1,-5.58]); E.box(0.18,3.6,0.12,E.mat("#6dd6e7",{emissive:"#35a6c5",glow:1.1}),[-2.1,2.1,-5.45]); E.box(0.18,3.6,0.12,E.mat("#6dd6e7",{emissive:"#35a6c5",glow:1.1}),[2.1,2.1,-5.45]);
  R.clock=E.group(null,[0,5.4,-17]); E.cyl(1.2,1.2,0.24,E.mat("#d7d1c4"),[0,0,0],{parent:R.clock,rot:[Math.PI/2,0,0]});
  R.clockHand=E.box(0.09,1.0,0.12,E.mat("#333b46"),[0,0.38,0.22],{parent:R.clock});
}
function buildHouse(E,S,T){
  S.room({w:13,d:10,h:4,wall:T.wallpaper("#b9b6ae","#9d9b91"),floor:T.planks("#765d49"),window:true,door:true,night:true});
  S.table(1.5,-1.2,{w:2.5,d:1.2,col:"#624833"}); S.chair(-1,-2,{col:"#6c5440"}); S.shelf(-4,-3,{seed:3}); S.crate(3,-3,1.1); S.crate(4,-3,0.8);
  E.box(2.4,0.12,0.12,E.mat("#7b6654"),[0,2.6,-4.8]);
  R.photo=E.group(null,[0,0,0]); E.box(1.4,1.5,0.1,E.mat("#a88454"),[1.5,1.3,-1.0],{parent:R.photo});
  E.plane(1.1,1.2,E.flat("#ffffff",{map:T.painting("portrait")}),[1.5,1.3,-0.93],{parent:R.photo});
}
function buildArchive(E,S,T){
  S.room({w:16,d:13,h:5,wall:T.wallpaper("#6c6672","#5c5365"),floor:T.planks("#4a3e3c"),window:false,door:true});
  for(const x of [-6,-3,3,6])S.shelf(x,-5,{seed:Math.abs(x)+5});
  S.table(0,-1,{w:3.6,d:1.5,col:"#6b4a31"}); S.hangLamp(0,4.5,0,{col:"#e0b65f",i:5});
  S.crate(-5,-1,0.9); S.crate(5,-1,0.9);
  R.recorder=E.group(null,[0,0,0]); E.box(1.6,0.55,0.9,E.mat("#3a424a"),[0,1.2,-1],{parent:R.recorder}); E.box(0.7,0.12,0.15,E.mat("#c6b46b"),[0,1.5,-0.52],{parent:R.recorder});
}
function buildTunnel(E,S,T){
  E.ground(T.stone("#5d6167"),100,0.25); E.box(28,0.3,38,E.mat("#4b5057"),[0,0,-8]);
  for(let z=2;z>=-28;z-=5){E.box(0.6,5,0.6,E.mat("#667079"),[-5,2.5,z]);E.box(0.6,5,0.6,E.mat("#667079"),[5,2.5,z]);E.box(11,0.6,0.6,E.mat("#667079"),[0,4.7,z]);}
  for(let z=0;z>=-30;z-=6){E.box(0.3,0.2,11,E.mat("#7b654e"),[0,0.1,z]);E.box(0.15,0.15,38,E.mat("#87949d"),[-1,0.4,-8]);E.box(0.15,0.15,38,E.mat("#87949d"),[1,0.4,-8]);}
  for(let z=-3;z>=-28;z-=7)S.hangLamp(0,4.7,z,{col:"#79c9dc",i:3});
  R.tunnelDoor=E.group(null,[0,0,0]); E.box(5,4.4,0.25,E.mat("#263b4e"),[0,2.2,-9],{parent:R.tunnelDoor}); E.box(4.3,3.8,0.18,E.mat("#50758a"),[0,2.1,-8.82],{parent:R.tunnelDoor});
}
function buildUnderground(E,S,T){
  E.ground(T.stone("#414c5b"),120,0.22); E.box(70,0.5,70,E.mat("#293442"),[0,-0.25,0]);
  for(let x=-18;x<=18;x+=6){E.box(1,14,1,E.mat("#596b7d"),[x,7,-15]);E.box(1,14,1,E.mat("#596b7d"),[x,7,15]);}
  E.box(70,1,2,E.mat("#25394c"),[0,14,0]);
  for(let z=-15;z<=15;z+=7){E.box(40,0.25,0.5,E.mat("#556779"),[0,0.2,z]);}
  for(const x of [-9,9]){E.box(3.6,5,2.2,E.mat("#3b5368"),[x,2.5,-8]);E.box(2.6,2.4,0.15,E.mat("#5ec4d6"),[x,3,-6.8]);S.hangLamp(x,6,-8,{col:"#69d9ec",i:4});}
  R.core=E.group(null,[0,0,0]); E.cyl(1.2,1.2,4.5,E.mat("#4e91c4"),[0,2.4,-7],{parent:R.core}); E.cyl(0.6,0.6,4.8,E.mat("#e8b94f"),[0,2.4,-7],{parent:R.core}); E.sphere(0.7,E.mat("#65d7ec"),[0,4.8,-7],{parent:R.core});
}
function buildControl(E,S,T){
  S.room({w:15,d:12,h:4.8,wall:T.wallpaper("#33404e","#263542"),floor:T.planks("#4c4141"),window:false,door:false});
  S.desk(0,-1.5,{col:"#3b4c5b"});
  for(let x=-4;x<=4;x+=2){E.box(1.5,1.2,0.15,E.mat("#253442"),[x,2.4,-5.4]);E.box(1.25,0.85,0.08,E.mat(x%4?"#5cb8ca":"#e1b15c",{emissive:x%4?"#15586a":"#5a3b0b",glow:0.9}),[x,2.45,-5.28]);}
  S.shelf(-6,-3,{seed:11});S.shelf(6,-3,{seed:14});
  R.console=E.group(null,[0,0,0]); E.box(4,0.6,1.1,E.mat("#344957"),[0,0.7,-3],{parent:R.console}); E.box(3,0.2,0.3,E.mat("#65c5d6"),[0,1.1,-2.5],{parent:R.console});
}
function buildTower(E,S,T){
  E.ground(T.cobble("#777c82"),100,0.2); S.hills({z:-80,col:"#526b77"}); S.clouds({n:4,y:27,z:-90});
  E.box(8,18,7,E.mat("#8d837a"),[0,0,-8]); E.cone(5.5,6,E.mat("#394a60"),[0,18,-8]);
  E.box(10,0.6,8,E.mat("#6a625a"),[0,18,-8]); E.box(4,2.8,0.3,E.mat("#5b5149"),[0,9,-4.3]);
  E.box(1,12,1,E.mat("#5d5d60"),[-6,6,0]); E.box(1,12,1,E.mat("#5d5d60"),[6,6,0]); E.box(13,0.5,1,E.mat("#6e6e72"),[0,12,0]);
  R.panel=E.group(null,[0,0,0]); E.box(2.2,2.8,0.3,E.mat("#354b5a"),[0,2,-3],{parent:R.panel}); E.box(1.5,0.3,0.1,E.mat("#e3bd63"),[0,2.7,-2.8],{parent:R.panel});
}
function buildSeam(E,S,T){
  E.ground(T.stone("#353d50"),120,0.25); E.box(60,0.5,60,E.mat("#222c3f"),[0,-0.25,0]);
  for(let i=0;i<16;i++){const x=-18+(i%4)*12,z=-20+Math.floor(i/4)*12;E.box(3,0.35,3,E.mat(i%3?"#4b5c72":"#6a547d"),[x,0.2,z],{rot:[0,(i%4)*0.25,0]});}
  R.portal=E.group(null,[0,0,0]); E.cyl(3.5,3.5,0.45,E.mat("#516e8b"),[0,0,-7],{parent:R.portal,rot:[Math.PI/2,0,0]}); E.cyl(2.7,2.7,0.5,E.mat("#65c9dc"),[0,0,-6.7],{parent:R.portal,rot:[Math.PI/2,0,0]});
  E.sphere(2.3,E.mat("#3d6f95",{emissive:"#2c9ec4",glow:1.3}),[0,2,-7],{parent:R.portal,scale:[0.15,1.2,1.2]});
}
function buildScene(E,S,T){
  const scene=EP.scene||"town";
  if(scene==="station")buildStation(E,S,T);
  else if(scene==="empty_house")buildHouse(E,S,T);
  else if(scene==="archive")buildArchive(E,S,T);
  else if(scene==="tunnel")buildTunnel(E,S,T);
  else if(scene==="underground")buildUnderground(E,S,T);
  else if(scene==="control_room")buildControl(E,S,T);
  else if(scene==="clocktower")buildTower(E,S,T);
  else if(scene==="seam")buildSeam(E,S,T);
  else makeTown(E,S,T);
}

export function build(E){
  const {S,T}=E; buildScene(E,S,T);
  for(const name of Object.keys(SPECS)){actorsByName[name]=E.actor(IDs[name],SPECS[name],{h:name==="Merco"?1.85:2.2});}
  // Merco'nun hareketli anteni, doodle karakterin tasarımını değiştirmeden robot kimliğini vurgular.
  R.antenna=E.group(null,[0,0,0]); E.cyl(0.04,0.04,0.42,E.mat("#4b6c79"),[0,0,0],{parent:R.antenna}); E.sphere(0.12,E.mat("#73e1db",{emissive:"#38c5d2",glow:1.2}),[0,0.23,0],{parent:R.antenna});
  // Sahneye özgü merkez öğeler ve animasyonları.
  R.clockHand ||= null;
  if(EP.scene==="station")R.doorGlow=E.sphere(0.18,E.mat("#70d8ed",{emissive:"#37b6d2",glow:1.3}),[0,2.4,-5.3]);
  if(EP.scene==="empty_house")R.photo=R.photo||E.group(null,[0,0,0]);
}

const gestureFor=(action,idx)=>({
  talk:["present","point","shrug","hold"][idx%4], angry:"facepalm", shrug:"shrug", reach:"reach", walk:"present",run:"cheer",pov_walk:"reach",search:"think",inspect:"chin",open:"reach",pull:"holdR",listen:"whisper",hide:"chin",point:"point",reveal:"present",freeze:"hold",enter:"reach",escape:"cheer",climb:"reach",fall:"up",switch:"holdR",determined:"hip",read:"hold",wait:"hang",turn:"point",save:"reach"
}[action]||"present");
const faceFor=(line,action,text)=>line.face||({angry:"angry",sad:"sad",run:"wow",escape:"scared",freeze:"scared",hide:"nervous",listen:"nervous",reveal:"wow",fall:"wow",determined:"determined",save:"determined",pull:"determined",search:"think",inspect:"think",read:"think"}[action]||(text.includes("? ")||text.endsWith("?")?"think":text.includes("! ")?"wow":"neutral"));
const movementActions=new Set(["walk","run","pov_walk","search","open","pull","enter","escape","climb","fall","hide","switch","save","reach"]);
const propFor=(line,action)=>line.prop||({open:{kind:"key",hand:"r"},inspect:{kind:"magnifier",hand:"r"},read:{kind:"paper",hand:"r"},switch:{kind:"laptop",hand:"r"},search:{kind:"phone",hand:"r"},pull:{kind:"key",hand:"r"},reach:{kind:"key",hand:"r"},point:null}[action]||null);
function getActive(E,f){
  const fps=30,frames=Math.max(1,Math.ceil(((E.words.at(-1)?.e)||90)*fps)+24);
  const wframe=n=>{const i=clamp(Number(n)||0,0,E.words.length-1);return E.words[i]?Math.round(E.words[i].s*fps):0;};
  const spans=EP.lines.map(l=>({...l,from:Math.max(0,wframe(l.start_word)-2),to:l.end_word+1<E.words.length?wframe(l.end_word+1)+2:frames}));
  const active=spans.find(l=>f>=l.from&&f<=l.to)||spans[spans.length-1];
  return {active,spans,frames};
}
function actorPlacement(name,line,idx,u,action){
  const speaker=line.speaker, side=(speaker==="Nur"||speaker==="Kubilay")?1:-1;
  let p=name===speaker?[side*1.6,0,1.4]:[side*-1.5,0,-1.8];
  const t=smooth(u);
  if(name===speaker){
    if(["walk","pov_walk","enter","search","open","pull","save","reach"].includes(action))p=[mix(side*2.4,side*0.3,t),0,mix(2.4,-2.7,t)];
    if(["run","escape"].includes(action))p=[mix(side*2.6,side*-0.5,t),0,mix(3.2,-5.0,t)];
    if(action==="climb")p=[mix(side*2,side*0.4,t),mix(0,1.6,t),mix(1.8,-1.2,t)];
    if(action==="fall")p=[mix(side*1.2,side*0.2,t),Math.sin(t*Math.PI)*0.45, mix(1.2,-1.0,t)];
    if(action==="hide")p=[side*2.6,0,-3.2];
    if(action==="inspect"||action==="read"||action==="switch")p=[mix(side*1.7,0.1,t),0,mix(1.5,-2.2,t)];
  }else if(action==="pull"||action==="save")p=[mix(side*-2.2,side*0.8,t),0,mix(-2.2,-4.1,t)];
  else if(action==="run"||action==="escape")p=[mix(side*-2.2,side*1.2,t),0,mix(-3.0,-5.0,t)];
  // 3 kişilik sahnelerde biri derin arka planda; düz yan yana dizilim oluşmasın.
  if(idx>=2)p=[(idx%2?1:-1)*2.4,0,-5.0-(idx*0.5)];
  return p;
}
function cameraKeys(E,line,from,to,u,actorPos,action){
  const shot=line.shot||"close", span=Math.max(1,to-from), x=actorPos[0],z=actorPos[2];
  const start=from,mid=Math.round(from+span*0.52),end=to;
  const push=0.65+0.2*Math.sin(u*Math.PI), shake=(action==="run"||action==="escape"||action==="fall")?0.06:0;
  if(shot==="pov"){
    const travel=action==="run"||action==="escape"?8.0:["walk","pov_walk","enter","search","open","pull","save","reach","climb"].includes(action)?5.2:["inspect","listen","point","reveal"].includes(action)?1.5:0.65;
    return [
      {f:start,pos:[-0.2,1.58,5.8],look:[0,1.55,-2.2],fov:48},
      {f:mid,pos:[0.1,1.58,5.8-travel*0.52],look:[0.2,1.6,-2.2-travel*0.55],fov:46},
      {f:end,pos:[0.4,1.58,5.8-travel],look:[0.4,1.65,-2.2-travel],fov:45}
    ];
  }
  if(shot==="insert"){
    const target=(EP.scene==="station"?-6:EP.scene==="tunnel"?-8:EP.scene==="underground"?-7:EP.scene==="seam"?-7:-2.8);
    const near=(EP.scene==="station"||EP.scene==="tunnel"||EP.scene==="underground"||EP.scene==="seam")?1.8:4.8;
    return [{f:start,pos:[0.1,2.3,near],look:[0,1.6,target],fov:34},{f:mid,pos:[0.1,2.0,near-0.8],look:[0,1.5,target],fov:31},{f:end,pos:[0,1.9,near-1.2],look:[0,1.6,target],fov:32}];
  }
  if(shot==="wide")return [{f:start,pos:[0,5.3,14],look:[0,1.4,-1],fov:52},{f:mid,pos:[-1.2,4.6,12],look:[0,1.5,-1],fov:49},{f:end,pos:[1,4.2,11],look:[0,1.6,-1],fov:48}];
  if(shot==="low")return [{f:start,pos:[x+1,0.8,z+6],look:[x,1.6,z-1],fov:37},{f:mid,pos:[x+0.5,1.0,z+4.5],look:[x,1.5,z-1.5],fov:35},{f:end,pos:[x+0.2,1.1,z+4.0],look:[x,1.5,z-1.5],fov:34}];
  if(shot==="tracking")return [{f:start,pos:[x+0.4,2.5,z+7],look:[x,1.5,z],fov:43},{f:mid,pos:[x+0.2,2.3,z+4.8],look:[x,1.5,z-1.2],fov:42},{f:end,pos:[x-0.3,2.4,z+4.2],look:[x,1.5,z-2],fov:41}];
  if(shot==="over")return [{f:start,pos:[x-1.2,2.8,z+6],look:[x,1.5,z-1],fov:44},{f:mid,pos:[x-0.8,2.4,z+5],look:[x,1.5,z-1.5],fov:42},{f:end,pos:[x-0.4,2.4,z+4.4],look:[x,1.5,z-1.5],fov:40}];
  const close=shot==="reaction"?33:38;
  return [{f:start,pos:[x+2.4,2.6,z+6],look:[x,1.55,z],fov:close},{f:mid,pos:[x+1.5,2.35,z+5.1],look:[x,1.6,z],fov:close-2},{f:end,pos:[x+1.3,2.25,z+4.7],look:[x,1.6,z],fov:close-1}];
}
export function frame(f,E){
  const {active,spans,frames}=getActive(E,f),line=active||EP.lines[0],lineIndex=spans.indexOf(active),span=Math.max(1,active.to-active.from),u=clamp((f-active.from)/span),sec=f/30;
  const speaker=line.speaker||"Batu",action=line.action||"talk",shot=line.shot||"close",text=(line.text||"").toLocaleLowerCase("tr"),talk=(name)=>speaker===name?E.talk(f,active.from,active.to):0;
  let visible=Array.isArray(line.visible)?line.visible.slice():[speaker];
  if(shot==="pov")visible=visible.filter(n=>n!==(line.pov_actor||speaker));
  if(!visible.length&&shot!=="pov")visible=[speaker];
  visible=visible.slice(0,3);
  const focusName=visible.find(n=>n===speaker)||visible[0]||"Batu",focusId=IDs[focusName]||IDs.Batu;
  const placements={};
  visible.forEach((name,i)=>placements[name]=actorPlacement(name,line,i,u,action));
  const focusPos=placements[focusName]||[0,0,0];
  const actors=[];
  for(const name of visible){
    const id=IDs[name],p=placements[name]||[0,0,0],isSpeaker=name===speaker;
    let act=isSpeaker?action:"wait";
    let legs=movementActions.has(act)?(act==="run"||act==="escape"?"run":"walk"):"stand";
    if(act==="hide")legs="sit";
    let face=isSpeaker?faceFor(line,action,text):(text.includes("tehl")||text.includes("kaybol")?"scared":"think");
    let arms=isSpeaker?gestureFor(action,lineIndex):"think";
    if(!isSpeaker&&line.action==="freeze")arms="hold";
    let prop=isSpeaker?propFor(line,action):null;
    let extra={legs,phase:sec*1.35+lineIndex*0.19,look:isSpeaker?0.12:((lineIndex%2)?-0.12:0),lean:isSpeaker&&movementActions.has(action)?0.16:0,headTilt:isSpeaker?5*Math.sin(sec*1.4):2,roll:action==="fall"?mix(0,0.45,smooth(u)):0};
    if(action==="fall"&&isSpeaker)extra.bob=45*Math.sin(u*Math.PI);
    if(action==="hide"&&isSpeaker)extra.tilt=16;
    if(action==="listen"&&isSpeaker)extra.headTilt=-12;
    if(prop)extra.prop=prop;
    actors.push({id,pos:p,scale:name==="Merco"?0.86:1,roll:action==="fall"&&isSpeaker?mix(0,0.5,smooth(u)):0,st:{blink:E.blink(f,SEEDS[name]),...E.idle(f,SEEDS[name]),face,arms,talk:isSpeaker?talk(name):0,...extra}});
  }
  let cam=E.camAt(f,cameraKeys(E,line,active.from,active.to,u,focusPos,action),{creep:shot==="pov"?0.08:0.04});
  if(action==="run"||action==="escape"||action==="fall"){
    const k=(1-smooth(u))*0.055;cam.pos[0]+=Math.sin(f*0.29)*k;cam.pos[1]+=Math.cos(f*0.33)*k;
  }
  // Merco antennini yalnızca sahnede göründüğünde konumlandır; ışığı konuşma ve sinyale göre pulse eder.
  const merco=placements.Merco;R.antenna.visible=!!merco;
  if(merco){R.antenna.position.set(merco[0],merco[1]+2.65,merco[2]+0.08);R.antenna.rotation.z=0.08*Math.sin(sec*5);}
  if(R.clockHand)R.clockHand.rotation.z=EP.number===1?Math.sin(sec*2.3)*0.3:Math.sin(sec*1.2)*0.1;
  if(R.clock)R.clock.rotation.y=0.03*Math.sin(sec*0.6);
  if(R.doorGlow)R.doorGlow.visible=(action==="reveal"||text.includes("ışık")||text.includes("kapı"))&&Math.sin(sec*5)>0;
  if(R.core)R.core.rotation.y=sec*0.22;
  if(R.portal){R.portal.rotation.z=sec*0.16;R.portal.scale.setScalar(0.96+0.04*Math.sin(sec*3.4));}
  if(R.console)R.console.rotation.y=0.04*Math.sin(sec*0.7);
  if(R.panel)R.panel.rotation.y=0.03*Math.sin(sec*1.5);
  const fx=[];
  if(action==="reveal")fx.push({kind:"sparkle",pos:[0,3.1,-2.5],size:0.55,t:u});
  if(action==="run"||action==="escape")fx.push({kind:"dust",pos:[focusPos[0],0.6,focusPos[2]+0.5],size:0.7,t:u});
  if(text.includes("?")&&action==="inspect")fx.push({kind:"question",pos:[focusPos[0]+0.7,3.2,focusPos[2]],size:0.32,t:u});
  if(text.includes("!")&&action==="freeze")fx.push({kind:"exclaim",pos:[focusPos[0]+0.6,3.0,focusPos[2]],size:0.32,t:u});
  const scene=EP.scene||"town";
  const light=(scene==="tunnel"||scene==="underground"||scene==="seam"||scene==="control_room")?"dramatic":(scene==="station"||scene==="clocktower")?"night":scene==="empty_house"||scene==="archive"?"interior":(f<frames*0.78?"night":"golden");
  return {cam,light,dof:{focus:[focusPos[0],1.4,focusPos[2]],amount:shot==="insert"||shot==="close"?2.5:1.5,range:7},actors,fx};
}
